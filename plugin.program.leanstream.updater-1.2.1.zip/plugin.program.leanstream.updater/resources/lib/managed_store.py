"""Durable management state and single-writer lease; never stores credentials."""
import contextlib
import json
import os
import re
import uuid

from resources.lib import bundle
from resources.lib import managed_security as security

def safe_path(path):
    path=os.path.abspath(path)
    current=path
    while True:
        if bundle.is_link(current):raise security.Error('Linked management path refused.')
        parent=os.path.dirname(current)
        if parent==current:break
        current=parent
    return path

def atomic_json(path,value):
    safe_path(path);safe_path(os.path.dirname(path))
    raw=security.canonical(value)
    if len(raw)>4*1024*1024:raise security.Error('Management state exceeds safe size.')
    temporary=path+'.tmp-'+uuid.uuid4().hex
    try:
        fd=os.open(temporary,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        with os.fdopen(fd,'wb') as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
        try:
            fd=os.open(os.path.dirname(path),os.O_RDONLY)
            try:os.fsync(fd)
            finally:os.close(fd)
        except OSError:pass  # Directory fsync is not supported on Windows.
    finally:
        if os.path.isfile(temporary) and not bundle.is_link(temporary):os.unlink(temporary)

class Store:
    def __init__(self,data,boot):
        if not isinstance(boot,str) or not re.fullmatch(r'[a-f0-9]{32}',boot):
            raise security.Error('Management boot identity unavailable; restart Kodi.')
        self.root=safe_path(os.path.join(data,'management-v1'))
        os.makedirs(self.root,exist_ok=True);self.boot=boot

    def path(self,name):
        if name not in ('enrollment','state','journal','lock','roots'):
            raise security.Error('Unknown management state file.')
        return safe_path(os.path.join(self.root,name+'.json'))

    def load(self,name,default=None):
        path=self.path(name)
        if not os.path.isfile(path):return default
        with open(path,'rb') as stream:raw=stream.read(4*1024*1024+1)
        if len(raw)>4*1024*1024:raise security.Error('Oversized management state; nothing changed.')
        # State may exceed network metadata bounds, but retains duplicate and
        # non-finite rejection through a bounded parser with a separate limit.
        def pairs(items):
            result={}
            for key,value in items:
                if key in result:raise security.Error('Duplicate local state field.')
                result[key]=value
            return result
        try:
            value=json.loads(raw.decode('utf8'),object_pairs_hook=pairs)
            security.canonical(value)
            return value
        except (ValueError,UnicodeError,RecursionError):
            raise security.Error('Management state damaged; preserve backups and recover.') from None

    def write(self,name,value):
        if name=='journal':
            old=self.load('journal')
            if old and old.get('transaction')!=value.get('transaction'):
                transaction=old.get('transaction')
                if (old.get('state') not in ('complete','restored','cancelled')
                        or not isinstance(transaction,str) or not re.fullmatch(r'[a-f0-9]{32}',transaction)):
                    raise security.Error('Cannot replace unresolved recovery history.')
                history=safe_path(os.path.join(self.root,'history'));os.makedirs(history,exist_ok=True)
                destination=safe_path(os.path.join(history,transaction+'.json'))
                if not os.path.exists(destination):atomic_json(destination,old)
        atomic_json(self.path(name),value)

    def enrollment(self):
        value=self.load('enrollment',{'enabled':False,'device':uuid.uuid4().hex,
                                    'channel':'friends','scopes':[]})
        security.exact(value,('enabled','device','channel','scopes'))
        if (type(value['enabled']) is not bool or not isinstance(value['device'],str)
                or not re.fullmatch(r'[a-f0-9]{32}',value['device'])
                or value['channel'] not in ('owner-test','friends')
                or not isinstance(value['scopes'],list)
                or any(s not in security.SCOPES for s in value['scopes'])
                or len(value['scopes'])!=len(set(value['scopes']))):
            raise security.Error('Enrollment state invalid; no changes allowed.')
        return value

    def enroll(self,channel,scopes):
        value=self.enrollment()
        if channel not in ('owner-test','friends') or not scopes or any(s not in security.SCOPES for s in scopes):
            raise security.Error('Invalid enrollment permissions.')
        value.update(enabled=True,channel=channel,scopes=sorted(set(scopes)))
        self.write('enrollment',value)
        return value

    def revoke(self):
        value=self.enrollment();value['enabled']=False
        self.write('enrollment',value)  # Sequence history and backups survive revocation.

    def water(self,channel):
        state=self.load('state',{'channels':{},'last_time':0})
        security.exact(state,('channels','last_time'))
        if not isinstance(state['channels'],dict) or type(state['last_time']) is not int:
            raise security.Error('Invalid version history.')
        value=state['channels'].get(channel,{'seen_sequence':0,'seen_digest':'','applied_sequence':0})
        security.exact(value,('seen_sequence','seen_digest','applied_sequence'))
        if (any(type(value[k]) is not int or value[k]<0 for k in ('seen_sequence','applied_sequence'))
                or not isinstance(value['seen_digest'],str)):
            raise security.Error('Invalid version history.')
        return dict(value,last_time=state['last_time'])

    def seen(self,channel,sequence,digest,now,applied=False):
        value=self.water(channel)
        if sequence<value['seen_sequence'] or sequence==value['seen_sequence'] and value['seen_digest']!=digest:
            raise security.Error('Version history changed concurrently.')
        value.update(seen_sequence=sequence,seen_digest=digest)
        value.pop('last_time')
        if applied:value['applied_sequence']=max(sequence,value['applied_sequence'])
        state=self.load('state',{'channels':{},'last_time':0})
        state['channels'][channel]=value;state['last_time']=max(now,state['last_time'])
        self.write('state',state)

    def pending(self):
        journal=self.load('journal')
        return journal and journal.get('state') not in ('complete','restored','cancelled')

    @contextlib.contextmanager
    def lock(self):
        # The process-start identity is in the directory name, so power loss
        # cannot leave an empty/part-written owner record with unknown origin.
        path=safe_path(os.path.join(self.root,'lease-'+self.boot))
        if self.leases():raise security.Error('Management lease exists. Restart Kodi and use Recovery if interrupted.')
        try:os.mkdir(path,0o700)
        except FileExistsError:
            raise security.Error('Management lease exists. If interrupted, restart Kodi and use Recovery.') from None
        try:yield
        finally:
            safe_path(path)
            os.rmdir(path)

    def leases(self):
        names=[n for n in os.listdir(self.root) if re.fullmatch(r'lease-[a-f0-9]{32}',n)]
        for name in names:
            path=safe_path(os.path.join(self.root,name))
            if not os.path.isdir(path) or os.listdir(path):raise security.Error('Unexpected lease contents; retain for manual review.')
        return names

    def recover_lease(self):
        for name in self.leases():
            if name=='lease-'+self.boot:
                raise security.Error('Same Kodi session may still own this lease. Restart Kodi normally first.')
            os.rename(safe_path(os.path.join(self.root,name)),
                      safe_path(os.path.join(self.root,'recovered-'+name+'-'+uuid.uuid4().hex)))
