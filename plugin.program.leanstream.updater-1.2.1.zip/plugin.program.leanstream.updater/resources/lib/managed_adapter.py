"""Typed Kodi/filesystem operations. Network, review and trust are separate."""
import ast
import hashlib
import io
import os
import re
import shutil
import sys
import uuid
import zipfile
import xml.etree.ElementTree as ET

from resources.lib import bundle
from resources.lib import managed_security as security
from resources.lib.managed_store import safe_path

def process_identity():
    """Stable for one Kodi process, including independent addon interpreters."""
    if os.name=='nt':
        import ctypes
        from ctypes import wintypes
        times=[wintypes.FILETIME() for _ in range(4)]
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetCurrentProcess.restype=wintypes.HANDLE
        kernel.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
        if not kernel.GetProcessTimes(kernel.GetCurrentProcess(),*[ctypes.byref(t) for t in times]):
            raise security.Error('Cannot establish process ownership; no management changes allowed.')
        started=(times[0].dwHighDateTime<<32)|times[0].dwLowDateTime
    else:
        try:
            with open('/proc/self/stat',encoding='ascii') as stream:
                started=int(stream.read().rsplit(')',1)[1].split()[19])
        except (OSError,ValueError,IndexError):
            raise security.Error('Cannot establish Kodi process ownership; no changes allowed.') from None
    return hashlib.sha256((str(os.getpid())+':'+str(started)).encode('ascii')).hexdigest()[:32]

def same(a,b):return type(a) is type(b) and a==b

def digest_file(path):
    safe_path(path)
    if not os.path.isfile(path):return None
    with open(path,'rb') as stream:return hashlib.sha256(stream.read()).hexdigest()

class Adapter:
    def __init__(self,ui):
        self.ui=ui;self.xbmc=ui.xbmc;self.addons=safe_path(ui.ADDONS)
        self.data=safe_path(os.path.join(ui.DATA,'management-v1'))
        self.keymaps=safe_path(os.path.join(ui.HOME,'userdata','keymaps'))
        self.platform='android' if self.xbmc.getCondVisibility('System.Platform.Android') else 'windows' if os.name=='nt' else 'unsupported'
        match=re.match(r'(\d+)',self.xbmc.getInfoLabel('System.BuildVersion'))
        self.kodi_major=int(match.group(1)) if match else 0
        self.stage=None;self.transaction=None;self.requirements={};self.abis={};self.planned={}
        self.expanded_total=0

    def rpc(self,method,params):
        import json
        value=security.read_json(self.xbmc.executeJSONRPC(json.dumps(
            {'jsonrpc':'2.0','id':5048,'method':method,'params':params})).encode('utf8'),max_size=8*1024*1024)
        if value.get('id')!=5048 or 'error' in value or 'result' not in value:
            raise security.Error('Kodi rejected the requested operation. No account reset is needed.')
        return value['result']

    def assert_idle(self,operations):
        if self.kodi_major!=21 or self.platform not in ('android','windows'):
            raise security.Error('This management core supports Kodi21 on Shield/Windows only.')
        if self.xbmc.Player().isPlaying():raise security.Error('Stop playback and previews before maintenance.')
        self.planned={op['addon_id']:op['version'] for op in operations if op['op']=='package.install'}
        for op in operations:
            if op['op']=='package.install' and op['addon_id'] in (bundle.PLUGIN,bundle.SKIN):
                if self.xbmc.getSkinDir()==bundle.SKIN:
                    raise security.Error('Choose Estuary locally and leave LeanStream before a suite code update. Your personal settings are preserved.')
            if op['op']=='addon.enabled' and op['addon_id']==self.xbmc.getSkinDir():
                raise security.Error('The active skin cannot be disabled.')
        if any(test(self.ui.DATA) for test in (
                self.ui.scrape_setup.interrupted,self.ui.android_playback.interrupted,
                self.ui.trailer_setup.interrupted)):
            raise security.Error('Recover interrupted legacy preference changes before applying a managed job.')
        old=bundle.last_backup(self.ui.DATA)
        if old and old.get('state')=='pending':raise security.Error('Recover interrupted legacy suite code first.')
        old=self.ui.self_update.state(self.ui.DATA)
        if old and old.get('state')=='pending':raise security.Error('Recover interrupted legacy updater code first.')

    def begin(self,transaction):
        if not re.fullmatch(r'[a-f0-9]{32}',transaction):raise security.Error('Invalid transaction identity.')
        self.transaction=transaction
        self.stage=safe_path(os.path.join(self.addons,'.leanstream-managed-'+transaction))
        os.mkdir(self.stage)
        for name in ('payload','before','previous','retired'):os.mkdir(os.path.join(self.stage,name))
        # Retained even after successful jobs: verified code and keymap rollback,
        # not profile credentials. No destructive recursive stage cleanup.

    def resume(self,journal):
        security.exact(journal,('schema','transaction','job','sequence','channel','digest',
                                'state','steps','requires_restart'))
        transaction=journal['transaction']
        if journal['schema']!=1 or not isinstance(transaction,str) or not re.fullmatch(r'[a-f0-9]{32}',transaction):
            raise security.Error('Invalid recovery journal.')
        if not isinstance(journal['steps'],list) or len(journal['steps'])>security.MAX_OPERATIONS:
            raise security.Error('Invalid recovery step count.')
        self.transaction=transaction;self.stage=safe_path(os.path.join(self.addons,'.leanstream-managed-'+transaction))
        if not os.path.isdir(self.stage):raise security.Error('Recovery staging/backup missing. Preserve remaining files.')
        for step in journal['steps']:
            security.operation(step['op'])
            if step.get('state') not in ('prepared','applying','applied','restoring','restored') or type(step.get('skip')) is not bool:
                raise security.Error('Invalid recovery step state.')

    def target(self,addon_id):
        security.addon_id(addon_id)
        path=safe_path(os.path.join(self.addons,addon_id))
        if os.path.exists(path) and not os.path.isdir(path):raise security.Error('Addon target is not a directory.')
        return path

    def area(self,kind,name):
        if kind not in ('payload','before','previous','retired'):raise security.Error('Unknown transaction area.')
        if not self.stage:raise security.Error('Transaction staging not established.')
        security.identifier(name)
        return safe_path(os.path.join(self.stage,kind,name))

    def setting(self,op,value=None,write=False):
        security.setting_id(op['id'],op['op']=='addon.setting')
        proposed=op['value'] if value is None else value
        if op['op']=='kodi.setting':
            rows=self.rpc('Settings.GetSettings',{'level':'expert'}).get('settings',[])
            row=next((r for r in rows if r.get('id')==op['id']),None)
            if not row or row.get('type') not in ('boolean','integer','number','string'):
                raise security.Error('Unsupported/hidden Kodi setting; set it locally instead.')
            typ=row['type']
            current=self.rpc('Settings.GetSettingValue',{'setting':op['id']})['value']
            if write:
                self.type_check(typ,proposed)
                if self.rpc('Settings.SetSettingValue',{'setting':op['id'],'value':proposed}) is not True:
                    raise security.Error('Kodi refused the setting value.')
            else:self.type_check(typ,op['value'])
            return current
        addon=self.ui.xbmcaddon.Addon(op['addon_id'])
        path=addon.getAddonInfo('path')
        raw=self.ui.read_core(os.path.join(path,'resources','settings.xml'),bundle.MAX_DEPENDENCY_XML+1)
        if len(raw)>bundle.MAX_DEPENDENCY_XML:raise security.Error('Addon settings metadata is too large.')
        try:node=ET.fromstring(raw).find('.//setting[@id="'+op['id']+'"]')
        except ET.ParseError:raise security.Error('Addon setting schema unreadable.') from None
        if node is None or node.get('type') not in ('boolean','integer','number','string'):
            raise security.Error('Unsupported addon setting schema; no coercion or profile patching.')
        typ=node.get('type');self.type_check(typ,proposed)
        control=node.find('control')
        if control is not None and control.findtext('hidden')=='true':
            raise security.Error('Hidden addon fields cannot be managed.')
        settings=addon.getSettings()
        suffix={'boolean':'Bool','integer':'Int','number':'Number','string':'String'}[typ]
        getter=getattr(settings,'get'+suffix)
        current=getter(op['id']);self.type_check(typ,current)
        if write:
            # Kodi20+ Settings setters are void (None in Python), unlike the
            # deprecated Addon.setSettingBool APIs. Verify the actual value.
            getattr(settings,'set'+suffix)(op['id'],proposed)
            if not same(getter(op['id']),proposed):
                raise security.Error('Addon rejected the typed setting value.')
        return current

    @staticmethod
    def type_check(typ,value):
        types={'boolean':(bool,),'integer':(int,),'number':(float,int),'string':(str,)}
        security.scalar(value)
        if type(value) not in types[typ]:raise security.Error('Setting type mismatch; no implicit conversion.')

    def enabled(self,addon_id,value=None):
        security.addon_id(addon_id)
        def registered():
            rows=self.rpc('Addons.GetAddons',{'installed':True,'enabled':'all','properties':['enabled']}).get('addons',[])
            return addon_id in {r['addonid'] for r in rows}
        if not registered():
            if value is None or value is False:return False
            if addon_id not in self.planned:raise security.Error('Install the addon first, or include its signed package before enabling it.')
            self.xbmc.executebuiltin('UpdateLocalAddons',True)
            import time
            deadline=time.monotonic()+10
            while not registered():
                if time.monotonic()>deadline:raise security.Error('Kodi addon registration timed out; use Recovery.')
                self.xbmc.sleep(100)
        row=self.rpc('Addons.GetAddonDetails',{'addonid':addon_id,'properties':['enabled','path']})['addon']
        # Built-in/platform modules and external addon locations are not code
        # owned by this updater. Never disable Kodi's bundled crypto or itself.
        path=safe_path(row['path'])
        if os.path.normcase(path.rstrip('/\\'))!=os.path.normcase(self.target(addon_id)):
            raise security.Error('Built-in or externally located addons require local administration.')
        if value is not None:
            if addon_id==self.xbmc.getSkinDir() or addon_id==bundle.SELF_ID:
                raise security.Error('Cannot disable the active skin or updater.')
            result=self.rpc('Addons.SetAddonEnabled',{'addonid':addon_id,'enabled':value})
            if result!='OK':raise security.Error('Kodi refused the addon state change.')
        return row['enabled']

    def package(self,op,raw):
        addon_id=op['addon_id'];target=self.target(addon_id)
        registered=self.rpc('Addons.GetAddons',{'installed':True,'enabled':'all','properties':['enabled']}).get('addons',[])
        if addon_id in {row['addonid'] for row in registered}:
            actual=self.ui.xbmcaddon.Addon(addon_id).getAddonInfo('path')
            actual=self.ui.xbmcvfs.translatePath(actual) if hasattr(self.ui,'xbmcvfs') else actual
            if os.path.normcase(os.path.abspath(actual).rstrip('/\\'))!=os.path.normcase(target):
                raise security.Error('Do not shadow a built-in or externally located addon with a managed package.')
        payload=self.area('payload',addon_id)
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                entries=archive.infolist()
                if not entries or len(entries)>10000 or sum(e.file_size for e in entries)>bundle.MAX_EXPANDED:
                    raise security.Error('Package expanded size/count exceeds limits.')
                self.expanded_total+=sum(e.file_size for e in entries)
                if self.expanded_total>512*1024*1024:raise security.Error('Combined expanded package size exceeds limits.')
                seen=set()
                for entry in entries:
                    name=bundle._safe_member(entry,addon_id)
                    if name in seen:raise security.Error('Duplicate or case-colliding ZIP path.')
                    seen.add(name)
                    if entry.orig_filename.lower().endswith(('.dll','.pyd','.so','.dylib','.exe','.bat','.cmd','.ps1','.vbs','.sh')):
                        raise security.Error('Native binaries/shell scripts must use Kodi/platform installers.')
                    if not entry.is_dir():
                        contents=archive.read(entry)
                        if entry.orig_filename.endswith('.xml') and b'<!DOCTYPE' in contents.upper():
                            raise security.Error('XML document types/entities are not allowed in managed packages.')
                        private_marker=rb'BEG'+rb'IN [A-Z ]*PRIVATE KEY'
                        if re.search(rb'github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|'+private_marker,contents):
                            raise security.Error('Credential-like material found in package.')
                        if entry.orig_filename.endswith('.py'):ast.parse(contents,feature_version=(3,8))
                metadata=archive.read(addon_id+'/addon.xml')
                if len(metadata)>bundle.MAX_DEPENDENCY_XML:raise security.Error('Addon metadata exceeds the safe size.')
                root=ET.fromstring(metadata)
                if root.get('id')!=addon_id or root.get('version')!=op['version']:
                    raise security.Error('Signed package identity/version mismatch.')
                reqs=bundle.declared_requirements(archive.read(addon_id+'/addon.xml'))
                if addon_id==bundle.SKIN:
                    if not any(e.get('point')=='xbmc.gui.skin' for e in root.findall('extension')):
                        raise security.Error('Owned skin extension missing.')
                elif not any(r.id=='xbmc.python' for r in reqs):
                    raise security.Error('Only declared Python addons or the owned skin can be installed.')
                if addon_id==bundle.PLUGIN:bundle.validate_ai(lambda n:archive.read(addon_id+'/'+n))
                if addon_id==bundle.SELF_ID:
                    if not any(r.id=='script.module.pycryptodome' and r.required for r in reqs):
                        raise security.Error('Core upgrade lost its declared crypto dependency.')
                    if not any(n.endswith('/resources/trust-root.json') for n in seen):
                        raise security.Error('Core upgrade missing pinned trust.')
                    new_root=security.read_json(archive.read(addon_id+'/resources/trust-root.json'))
                    security.root_schema(new_root)
                    if new_root!=getattr(self,'trusted_root',None):
                        raise security.Error('Rotate trust with a cross-signed root first; a core package cannot silently reset it.')
                if archive.testzip():raise security.Error('Corrupt package.')
                archive.extractall(self.area('payload',addon_id).rsplit(os.sep,1)[0])
        except (zipfile.BadZipFile,KeyError,ET.ParseError,SyntaxError,UnicodeError):
            raise security.Error('Malformed or incompatible package; nothing installed.') from None
        self.requirements[addon_id]=reqs;self.abis[addon_id]=bundle.addon_abi(root)
        after=bundle.tree_digest(payload)
        before=bundle.tree_digest(target) if os.path.isdir(target) else None
        if before is not None:
            installed=ET.parse(os.path.join(target,'addon.xml')).getroot()
            if installed.get('id')!=addon_id or bundle.ver(installed.get('version',''))>bundle.ver(op['version']):
                raise security.Error('Package would downgrade or replace an unexpected addon.')
            if installed.get('version')==op['version'] and before!=after:
                raise security.Error('Same-version code differs; publish a new package version.')
            backup=self.area('before',addon_id)
            shutil.copytree(target,backup,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.pyo'))
            if bundle.tree_digest(backup)!=before:raise security.Error('Code backup verification failed.')
        return before,after

    def prepare(self,op,raw=None):
        security.operation(op);kind=op['op'];impact=''
        if kind=='package.install':before,after=self.package(op,raw)
        elif kind=='keymap.install':
            if len(raw)>65536 or b'<!DOCTYPE' in raw.upper():raise security.Error('Unsafe keymap XML.')
            try:root=ET.fromstring(raw)
            except ET.ParseError:raise security.Error('Invalid keymap XML.') from None
            if root.tag!='keymap':raise security.Error('Not a Kodi keymap.')
            target=safe_path(os.path.join(self.keymaps,op['name']))
            before=digest_file(target);after=hashlib.sha256(raw).hexdigest()
            with open(self.area('payload',op['name']),'xb') as stream:stream.write(raw)
            if before is not None:
                shutil.copy2(target,self.area('before',op['name']))
                if digest_file(self.area('before',op['name']))!=before:raise security.Error('Keymap backup failed.')
        elif kind=='addon.enabled':
            before=self.enabled(op['addon_id']);after=op['value']
            if after and not os.path.isdir(self.target(op['addon_id'])) and op['addon_id'] not in self.planned:
                raise security.Error('Enabling a missing addon requires its signed package in this job.')
            rows=self.rpc('Addons.GetAddons',{'installed':True,'enabled':True,'properties':['dependencies']}).get('addons',[])
            users=[r['addonid'] for r in rows if any(d['addonid']==op['addon_id'] and not d.get('optional',False)
                                                    for d in r.get('dependencies',[]))]
            if not after and users:impact='Dependent features may stop until re-enabled: '+', '.join(users)
        else:before=self.setting(op);after=op['value']
        matched=op.get('when','any')=='any' or any(same(before,v) for v in op['when'])
        return {'op':op,'before':before,'after':after,'skip':not matched or same(before,after),
                'state':'prepared','impact':impact}

    def validate_prepared(self,steps):
        for addon_id,requirements in self.requirements.items():
            rows=self.ui.requirement_rows(requirements,self.planned,self.abis)
            if any(row['required'] and row['status']!='OK' for row in rows):
                raise security.Error('Required Kodi dependency is missing/incompatible. Install it natively, then review this job again.')

    def current(self,step):
        op=step['op'];kind=op['op']
        if kind=='package.install':
            target=self.target(op['addon_id'])
            return bundle.tree_digest(target) if os.path.isdir(target) else None
        if kind=='keymap.install':return digest_file(safe_path(os.path.join(self.keymaps,op['name'])))
        if kind=='addon.enabled':return self.enabled(op['addon_id'])
        return self.setting(op)

    def precondition(self,step):return same(self.current(step),step['before'])
    def postcondition(self,step):return same(self.current(step),step['after'])

    def apply(self,step):
        op=step['op'];kind=op['op']
        if kind=='package.install':
            target=self.target(op['addon_id']);payload=self.area('payload',op['addon_id'])
            if bundle.tree_digest(payload)!=step['after']:raise security.Error('Staged package changed.')
            if os.path.isdir(target):os.rename(target,self.area('previous',op['addon_id']))
            os.rename(payload,target)
        elif kind=='keymap.install':
            os.makedirs(self.keymaps,exist_ok=True)
            payload=self.area('payload',op['name'])
            if digest_file(payload)!=step['after']:raise security.Error('Staged keymap changed.')
            os.replace(payload,safe_path(os.path.join(self.keymaps,op['name'])))
        elif kind=='addon.enabled':self.enabled(op['addon_id'],step['after'])
        else:self.setting(op,step['after'],write=True)

    def intermediate(self,step):
        # Proven power loss between the two directory renames. A random missing
        # target is not enough: the moved original must still match the backup.
        kind=step['op']['op']
        if self.current(step) is not None:return False
        if kind=='package.install' and step['state']=='applying':
            previous=self.area('previous',step['op']['addon_id'])
            return step['before'] is not None and os.path.isdir(previous) and bundle.tree_digest(previous)==step['before']
        if kind in ('package.install','keymap.install') and step['state']=='restoring':
            name=step['op'].get('addon_id',step['op'].get('name'))
            retired=self.area('retired','changed-'+name)
            ready=self.area('retired','restore-'+name)
            read=bundle.tree_digest if kind=='package.install' else digest_file
            if not os.path.exists(retired) or read(retired)!=step['after']:return False
            return step['before'] is None or os.path.exists(ready) and read(ready)==step['before']
        return False

    def can_restore(self,step):
        if step['skip'] or step['state']=='prepared':return True
        current=self.current(step)
        if step['op']['op'] in ('package.install','keymap.install') and step['before'] is not None and not same(current,step['before']):
            name=step['op'].get('addon_id',step['op'].get('name'));backup=self.area('before',name)
            if not os.path.exists(backup):return False
            read=bundle.tree_digest if step['op']['op']=='package.install' else digest_file
            if read(backup)!=step['before']:return False
        return same(current,step['before']) or same(current,step['after']) or self.intermediate(step)

    def restore(self,step):
        if same(self.current(step),step['before']):return
        op=step['op'];kind=op['op']
        if kind in ('package.install','keymap.install'):
            name=op['addon_id'] if kind=='package.install' else op['name']
            backup=self.area('before',name)
            if step['before'] is not None:
                actual=bundle.tree_digest(backup) if kind=='package.install' else digest_file(backup)
                if actual!=step['before']:raise security.Error('Verified rollback data changed or missing.')
            target=self.target(name) if kind=='package.install' else safe_path(os.path.join(self.keymaps,name))
            restore_path=self.area('retired','restore-'+name)
            if step['before'] is not None:
                if os.path.exists(restore_path):
                    read=bundle.tree_digest if kind=='package.install' else digest_file
                    if read(restore_path)!=step['before']:raise security.Error('Staged rollback changed.')
                elif kind=='package.install':shutil.copytree(backup,restore_path)
                else:shutil.copy2(backup,restore_path)
            if os.path.exists(target):os.rename(target,self.area('retired','changed-'+name))
            if step['before'] is not None:os.rename(restore_path,target)
        elif kind=='addon.enabled':self.enabled(op['addon_id'],step['before'])
        else:self.setting(op,step['before'],write=True)
        if not same(self.current(step),step['before']):raise security.Error('Rollback readback failed.')

    def finish(self,journal):
        if any(s['op']['op']=='package.install' for s in journal['steps']):
            self.xbmc.executebuiltin('UpdateLocalAddons')
        if any(s['op']['op']=='keymap.install' for s in journal['steps']):
            self.xbmc.executebuiltin('Action(reloadkeymaps)')
