"""Versioned signed-job protocol. No Kodi, network or private-key dependencies.

Not a TUF implementation. Pins an operator root, verifies RSA-PSS/SHA256 jobs,
and bounds time, target, sequence and operation schemas before any mutation.
"""
import base64
import hashlib
import json
import math
import re

from resources.lib import bundle

PROTOCOL = 1
DOMAIN = b'LeanStream signed maintenance v1\x00'
ROOT_DOMAIN = b'LeanStream trust root v1\x00'
MAX_METADATA = 128 * 1024
MAX_OPERATIONS = 64
SCOPES = ('packages', 'kodi.settings', 'addon.settings', 'addon.state', 'keymaps')
OP_SCOPE = {'package.install':'packages', 'kodi.setting':'kodi.settings',
            'addon.setting':'addon.settings', 'addon.enabled':'addon.state',
            'keymap.install':'keymaps'}
SENSITIVE = re.compile(r'password|passphrase|token|secret|credential|api[_.-]?key|'
    r'username|login|oauth|authorization|cookie|session|client[_.-]?id|account|'
    r'access[_.-]?key|refresh[_.-]?key|private[_.-]?key|pin(?:code)?$', re.I)
HASH = re.compile(r'[a-f0-9]{64}')
ID = re.compile(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}')

Error = bundle.UpdateError

def canonical(value):
    try:
        return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,
                          allow_nan=False).encode('ascii')
    except (TypeError,ValueError,OverflowError):
        raise Error('Unsupported signed metadata value.') from None

def read_json(raw,max_size=MAX_METADATA):
    if not isinstance(raw,bytes) or not 0 < len(raw) <= max_size:
        raise Error('Metadata size exceeds the safe limit.')
    def unique(pairs):
        value={}
        for key,item in pairs:
            if key in value: raise Error('Duplicate signed metadata field.')
            value[key]=item
        return value
    def bad_constant(value): raise Error('Non-finite signed metadata number.')
    try:
        return json.loads(raw.decode('utf8'),object_pairs_hook=unique,parse_constant=bad_constant)
    except (ValueError,UnicodeError,RecursionError):
        raise Error('Malformed signed metadata.') from None

def exact(value,keys):
    if not isinstance(value,dict) or set(value)!=set(keys):
        raise Error('Unexpected or missing signed metadata fields.')

def text(value,limit=512):
    if (not isinstance(value,str) or not 0 < len(value) <= limit
            or any(ord(c)<32 and c not in '\n\t' for c in value)):
        raise Error('Invalid signed metadata text.')
    return value

def identifier(value):
    if not isinstance(value,str) or not ID.fullmatch(value) or '..' in value:
        raise Error('Invalid maintenance identity.')
    return value

def addon_id(value):
    identifier(value)
    if (not value.startswith(('plugin.','script.','service.','resource.','skin.'))
            or value.startswith('skin.') and value!=bundle.SKIN):
        raise Error('Core modules and external skins are not managed package targets.')
    return value

def setting_id(value,addon=False):
    identifier(value)
    if SENSITIVE.search(value) or (not addon and value.startswith(
            ('services.','network.','masterlock.','profiles.','upnp.'))):
        raise Error('Credential, account or security settings require direct owner action.')
    if not addon and value=='lookandfeel.skin':
        raise Error('Choose the active skin locally; jobs cannot switch it silently.')
    if addon and value.lower().startswith(('trakt.','simkl.','mdblist.','torbox.',
            'realdebrid.','premiumize.','alldebrid.','fanart.','omdb.','tmdb.','scrobble.')):
        raise Error('Service/account configuration is not managed by routine jobs.')
    return value

def scalar(value):
    if type(value) not in (bool,int,float,str): raise Error('Setting value must be scalar.')
    if isinstance(value,str) and (len(value)>512 or '\x00' in value):
        raise Error('Setting string exceeds its safe limit.')
    if type(value) is int and abs(value)>2147483647: raise Error('Setting number out of range.')
    if type(value) is float and (not math.isfinite(value) or abs(value)>1e9):
        raise Error('Setting number out of range.')
    return value

def artifact(value):
    exact(value,('filename','sha256','size'))
    if (not isinstance(value['filename'],str)
            or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,159}\.(?:zip|xml)',value['filename'])
            or '..' in value['filename']): raise Error('Unsafe artifact filename.')
    if not isinstance(value['sha256'],str) or not HASH.fullmatch(value['sha256']):
        raise Error('Invalid artifact hash.')
    if type(value['size']) is not int or not 0 < value['size'] <= bundle.MAX_PACKAGE:
        raise Error('Artifact size out of bounds.')

def operation(op):
    if not isinstance(op,dict) or op.get('op') not in OP_SCOPE:
        raise Error('Unsupported maintenance capability; upgrade the updater first.')
    kind=op['op']
    fields={'package.install':('op','addon_id','version','artifact'),
            'keymap.install':('op','name','artifact'),
            'kodi.setting':('op','id','value','when'),
            'addon.setting':('op','addon_id','id','value','when'),
            'addon.enabled':('op','addon_id','value','when')}
    exact(op,fields[kind])
    if 'addon_id' in op: addon_id(op['addon_id'])
    if kind in ('package.install','keymap.install'):
        artifact(op['artifact'])
        if kind=='package.install':
            text(op['version'],48);bundle.ver(op['version'])
            if not re.fullmatch(r'\d+(?:\.\d+){0,3}',op['version']):raise Error('Invalid package version.')
            if not op['artifact']['filename'].endswith('.zip'):raise Error('Package must be a ZIP.')
        else:
            if not isinstance(op['name'],str) or not re.fullmatch(r'leanstream-[a-z0-9-]{1,64}\.xml',op['name']):
                raise Error('Only named LeanStream keymaps can be managed.')
            if not op['artifact']['filename'].endswith('.xml') or op['artifact']['size']>65536:
                raise Error('Invalid keymap artifact.')
    else:
        if kind!='addon.enabled':setting_id(op['id'],kind=='addon.setting')
        elif type(op['value']) is not bool:raise Error('Addon enabled value must be boolean.')
        scalar(op['value'])
        if op['when']!='any':
            if not isinstance(op['when'],list) or not 1 <= len(op['when']) <= 16:
                raise Error('Invalid conditional migration.')
            for value in op['when']:scalar(value)
    if kind=='addon.enabled' and op['addon_id']==bundle.SELF_ID:
        raise Error('Revoke enrollment instead of disabling the updater in a job.')

def operation_key(op):
    kind=op['op']
    if kind=='package.install':return kind,op['addon_id']
    if kind=='keymap.install':return kind,op['name']
    return kind,op.get('addon_id',''),op.get('id','')

def verify_pss(public,message,signature):
    """Kodi ships the Cryptodome namespace, not Crypto. No handwritten crypto."""
    try:
        try:
            from Cryptodome.Hash import SHA256
            from Cryptodome.PublicKey import RSA
            from Cryptodome.Signature import pss
        except ModuleNotFoundError as error:
            if error.name!='Cryptodome':raise
            from Crypto.Hash import SHA256
            from Crypto.PublicKey import RSA
            from Crypto.Signature import pss
        key=RSA.import_key(public.encode('ascii'))
        if key.has_private() or not 3072 <= key.size_in_bits() <= 4096 or key.e!=65537:
            return False
        pss.new(key,salt_bytes=32).verify(SHA256.new(message),signature)
        return True
    except (ValueError,TypeError,IndexError,UnicodeError):return False
    except ImportError:raise Error('Kodi cryptographic verifier unavailable. No changes allowed.') from None

def root_schema(root):
    exact(root,('schema','version','expires','keys','threshold'))
    if (type(root['schema']) is not int or root['schema']!=1
            or type(root['version']) is not int or not 1 <= root['version'] <= 2147483647
            or type(root['expires']) is not int or root['expires']<1704067200
            or type(root['threshold']) is not int or not 1 <= root['threshold'] <= 3
            or not isinstance(root['keys'],dict) or not root['threshold'] <= len(root['keys']) <= 4):
        raise Error('Invalid trust root.')
    for keyid,public in root['keys'].items():
        if not isinstance(keyid,str) or not HASH.fullmatch(keyid):raise Error('Invalid root key identity.')
        text(public,2048)
        if (not public.startswith('-----BEGIN PUBLIC KEY-----\n')
                or hashlib.sha256(public.encode('ascii')).hexdigest()!=keyid):
            raise Error('Root key fingerprint mismatch.')

def signed(raw,root,now,domain=DOMAIN,verify=verify_pss,check_expiry=True):
    root_schema(root)
    if type(now) is not int or now<1704067200 or check_expiry and now>=root['expires']:
        raise Error('Clock or trust root expired. Check time or install an authenticated root update.')
    envelope=read_json(raw);exact(envelope,('signed','signatures'))
    signatures=envelope['signatures']
    if not isinstance(signatures,list) or not 1 <= len(signatures) <= 8:
        raise Error('Missing or excessive signatures.')
    message=domain+canonical(envelope['signed']);valid=set();seen=set()
    for item in signatures:
        exact(item,('keyid','sig'));keyid=item['keyid']
        if not isinstance(keyid,str) or not HASH.fullmatch(keyid) or keyid in seen:
            raise Error('Invalid or duplicate signature identity.')
        seen.add(keyid)
        try:
            if not isinstance(item['sig'],str) or len(item['sig'])>1024:raise ValueError()
            signature=base64.b64decode(item['sig'],validate=True)
        except (ValueError,TypeError):raise Error('Invalid signature encoding.') from None
        if keyid in root['keys'] and verify(root['keys'][keyid],message,signature):valid.add(keyid)
    if len(valid)<root['threshold']:raise Error('Signature verification failed. Nothing changed.')
    return envelope['signed']

def validate_job(payload,enrollment,platform,kodi_major,now,state):
    exact(payload,('schema','kind','id','sequence','issued','expires','minimum_updater',
                   'title','notes','target','operations'))
    if type(payload['schema']) is not int or payload['schema']!=PROTOCOL or payload['kind']!='maintenance':
        raise Error('Unsupported management protocol.')
    identifier(payload['id']);text(payload['title'],120);text(payload['notes'],2048)
    for name in ('sequence','issued','expires'):
        if type(payload[name]) is not int or not 1 <= payload[name] <= 9007199254740991:
            raise Error('Invalid signed version or timestamp.')
    if (payload['issued']>now+300 or payload['expires']<=now
            or not 0 < payload['expires']-payload['issued'] <= 30*86400):
        raise Error('Job expired or issued in the future. No changes allowed.')
    text(payload['minimum_updater'],48)
    if bundle.ver(payload['minimum_updater'])>bundle.ver(bundle.VERSION):
        raise Error('This job needs a newer authenticated updater bootstrap.')
    target=payload['target'];exact(target,('kodi_major','platforms','channel','devices'))
    if (type(target['kodi_major']) is not int or target['kodi_major']!=21
            or not isinstance(target['platforms'],list) or not target['platforms']
            or len(target['platforms'])!=len(set(target['platforms']))
            or any(p not in ('android','windows') for p in target['platforms'])
            or target['channel'] not in ('owner-test','friends')
            or not isinstance(target['devices'],list) or len(target['devices'])>128
            or any(not isinstance(d,str) or not re.fullmatch(r'[a-f0-9]{32}',d) for d in target['devices'])):
        raise Error('Invalid job target.')
    if (not enrollment.get('enabled') or enrollment.get('channel')!=target['channel']
            or kodi_major!=target['kodi_major'] or platform not in target['platforms']
            or target['devices'] and enrollment.get('device') not in target['devices']):
        raise Error('This device is not enrolled for this job target.')
    ops=payload['operations']
    if not isinstance(ops,list) or not 1 <= len(ops) <= MAX_OPERATIONS:
        raise Error('Invalid job operation count.')
    keys=set();artifacts={}
    for op in ops:
        operation(op)
        if OP_SCOPE[op['op']] not in enrollment.get('scopes',[]):
            raise Error('Job exceeds the device owner\'s enrolled permissions.')
        key=operation_key(op)
        if key in keys:raise Error('Duplicate maintenance target.')
        keys.add(key)
        if 'artifact' in op:
            item=op['artifact'];name=item['filename']
            if name in artifacts and artifacts[name]!=item:raise Error('Artifact identity collision.')
            artifacts[name]=item
    if sum(item['size'] for item in artifacts.values())>128*1024*1024:
        raise Error('Combined artifact download exceeds the memory budget.')
    if sum(op['op']=='package.install' for op in ops)>16:
        raise Error('Too many code packages in one transaction.')
    # A core replacement happens last; the running interpreter must not mix
    # old and new modules during remaining setting/package operations.
    core=[i for i,op in enumerate(ops) if op['op']=='package.install' and op['addon_id']==bundle.SELF_ID]
    if core and core!=[len(ops)-1]:raise Error('Updater replacement must be the final operation.')
    digest=hashlib.sha256(canonical(payload)).hexdigest()
    sequence=payload['sequence'];seen=state.get('seen_sequence',0)
    if sequence<seen or sequence<=state.get('applied_sequence',0):raise Error('Older or already applied job rejected.')
    if sequence==seen and state.get('seen_digest')!=digest:raise Error('Same sequence has different signed content.')
    if now+300<state.get('last_time',0):raise Error('Device clock moved backwards; no changes allowed.')
    return digest,artifacts

def rotate_root(raw,old,now,verify=verify_pss,historical=False):
    candidate=signed(raw,old,now,ROOT_DOMAIN,verify,check_expiry=False)
    root_schema(candidate)
    if candidate['version']!=old['version']+1 or not historical and candidate['expires']<=now:
        raise Error('Root rotation must advance exactly one version and remain unexpired.')
    # Both the old authorization and the new root's possession threshold must
    # verify the identical root envelope. Rotation never needs a new core.
    signed(raw,candidate,now,ROOT_DOMAIN,verify,check_expiry=not historical)
    return candidate
