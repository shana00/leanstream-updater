LEANSTREAM SIGNED UPDATER 1.2.1

EXISTING UPDATE UPDATER BUTTON
From issued updater1.1.2 through1.1.10: choose Update updater, restart normally,
then choose Update updater once more to finish the one-time1.1.11 bridge to1.2.1.
The public updater-latest.json points to the old-compatible bridge, never
directly to a core whose crypto dependency old validators reject. The bridge
pins this core's exact hash/version/public trust and checks Kodi's installed
crypto dependency. It imports no undeclared crypto, installs no PC binaries,
and has no startup presets. No uninstall, clear-data, manual ZIP or token reset.

Verify the ZIP SHA256 and signing-root fingerprint through an authenticated
message from the owner. The existing HTTPS/hash-only bridge delivery is the
initial trust boundary, not a retrospectively signed first hop; a key
taken from the same untrusted ZIP is not independent proof of its authenticity.

MANAGEMENT
Enroll THIS Kodi, choose the Friends or Owner-test channel and permitted scopes.
Every job must have valid RSA-PSS/SHA256 signatures, target/version/expiry/
sequence checks and explicit review. Revoke blocks future jobs. Devices are not
silently enrolled, controlled or identified to a central telemetry service.

Supported: pure-Python addon packages, owned LeanStream skin, signed core
upgrades, supported typed non-security Kodi/non-account addon settings, installed
addon states with dependency-impact review, and named LeanStream keymaps.
Kodi21 Shield/Windows only. Not Android root or a live remote-admin session.
Core/network/security/account/hidden settings and native binaries are refused.
Missing native dependencies must be installed through Kodi separately.
External skins, credentials, watch history and cloud-library actions are excluded.

CHECK SIGNED CHANNEL
Uses the device's existing private repository read token and pinned trust root.
Only fixed GitHub API paths are allowed; redirects never receive a token.
No unsigned legacy feeds or public self-update bypass. Signed cross-root
rotation needs both old and new key thresholds and advances one root version.
Jobs expire within30days; rollback/replay history survives revocation and restore.

UPDATE UPDATER AFTER MIGRATION
The familiar button remains. It reads a separate fixed public signed-core feed,
without reading or sending the private token. Only one updater-code operation
is accepted; suite/settings operations are refused on this public route. The
device must permit package maintenance and review the signed plan. Core and
content share monotonic sequence history per channel: when issuing a future
core job, republish the cumulative content with a newer sequence afterward so
late adopters can still apply it. Revoke and local Recovery remain available.

LOCAL SIGNED JOB
Choose latest.json on a USB/file source; put its signed, hash-pinned artifacts
beside it. Local and online jobs use the identical verifier and transaction code.

RECOVERY
All artifacts and required dependencies are checked before the first mutation.
Reviewed values are rechecked. Original code/keymaps and non-sensitive setting
values are retained with durable per-step intents and readback. Recovery is
local-only and available after revocation; it refuses newer choices or damaged
backups. An interrupted lease requires a normal Kodi restart before recovery.
Do not delete .leanstream-managed-* folders: they contain rollback evidence.
No automatic recursive cleanup of committed backups occurs.

Stop playback/previews first. Select Estuary locally and leave LeanStream for
suite code changes. No silent active-skin, Surface-OFF or ten-second scraping
presets. Startup only notifies about pending recovery; no network or auto jobs.
Code/keymap jobs request a normal restart. Do not force-stop during maintenance.

SETUP CHECK / LEGACY RECOVERY
Existing setup inventory and GitHub-access check are read-only. Existing legacy
backup restores remain behind their separate confirmations; no old presets or
unsigned release actions are offered. A managed job must be resolved first.

LIMITS
Signed packages are trusted executable code, not sandboxed. Review the operator
and package provenance. Cryptographic checks protect distribution, not a rooted/
compromised local device or stolen signing key. Native third-party addon
behavior after enablement is not a promise of zero network traffic.
