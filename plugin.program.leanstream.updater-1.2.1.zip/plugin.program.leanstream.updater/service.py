"""Startup recovery notice only. No network, automatic jobs or legacy presets."""
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

addon=xbmcaddon.Addon('plugin.program.leanstream.updater')
data=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if os.path.isdir(os.path.join(data,'management-v1')):
    try:
        from resources.lib.managed_store import Store
        from resources.lib.managed_adapter import process_identity
        store=Store(data,process_identity())
        if store.pending() or store.leases():
            xbmcgui.Dialog().notification('LeanStream maintenance',
                'Interrupted job: open updater Recovery. No automatic changes applied.',time=8000)
    except Exception:
        xbmc.log('[LeanStream Updater] Recovery state needs local review; no automatic changes applied.',xbmc.LOGWARNING)
