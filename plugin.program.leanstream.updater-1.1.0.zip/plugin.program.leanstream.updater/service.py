# -*- coding: utf-8 -*-
"""Finish only a queued, approved skin selection; never downloads or installs."""
from resources.lib.updater import finish_skin_setup

finish_skin_setup(startup=True)
