# -*- coding: utf-8 -*-
from resources.lib.updater import main

main()
