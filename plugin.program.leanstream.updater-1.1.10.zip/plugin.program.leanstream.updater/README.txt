LEANSTREAM PRIVATE UPDATER 1.1.10

SETUP CHECK (NO CHANGES)
Available from updater menu or the suite Accounts > Setup check button.
Checks the add-on/skin roots, recursive Kodi dependencies and built-in interfaces,
bundled AI integrity/settings, provider metadata presence and saved service
configuration. Only presence/enablement is reported: no credential values,
usernames, fragments, fingerprints or exception details. No network requests,
logins, synchronization, installs, enablement or settings writes. A saved key is
NOT proof of valid access, remaining quota, rating availability or playback.
MDBList extra ratings use its key separately from the watch/list enabled switch.
Playback services are alternatives, not a requirement to connect every account.
Missing optional modules are not required failures. Built-in Kodi interfaces
are not separate add-ons to download. No Windows binaries are copied to Android.

The Accounts entry requires updater1.1.8 or newer, enabled and registered. It
invokes a fixed read-only action, never the suite installer or setup presets.
Malformed or extra query arguments are refused without echoing their contents.

COMPACT CHECKLIST AND OPTIONAL REPORT SHARING
Six user-facing rows separate required components, trailers, ratings, playback,
AI and providers. Checkmarks mean the stated metadata/configuration was found,
NOT online validation. Technical details hold the full prerequisite/service
inventory. No existing settings, accounts, providers or presets are changed.
Download on phone (QR) starts an explicit temporary private-LAN HTTP listener,
on one RFC1918 IPv4 interface/ephemeral port, maximum five minutes/eight downloads.
The QR is generated entirely on-device using the bundled MIT Nayuki encoder.
No external QR service, public upload, email sender or analytics is used.
The phone must use the same trusted Wi-Fi. HTTP is not encrypted. Anyone with
the QR can download while the QR window is open; closing stops sharing.
The QR downloads the COMPLETE sanitized report, not only the six-row summary.
Save report is a fallback: select a folder to write a unique .txt file.
Neither export includes raw kodi.log, account values, keys/tokens, settings dumps,
private URLs, watch history or source/provider metadata contents. Share that
file yourself through your chosen chat/email application. Dependencies appear
in Technical details and exports; optional missing modules are not blockers.
No firewall, router, system security or account settings are changed for sharing.

ONE-TIME AUTOMATIC PC SCRAPING PRESET (SEPARATE FROM CHECKER)
After a verified completed paired-suite install, the next normal startup applies
only12 typed non-account scrape preferences, without another preset prompt:
10s timeout, tier threshold0, preemptive source limit15, remaining9 values matching
the recorded PC policy. Cloud/direct/adaptive early exits stay enabled and can
stop before15; neither cached nor counted means playback-tested. A shorter10s
timeout can exclude slow providers. This does not fix unavailable provider links.
Strict backup precedes setters; readback, failure rollback and guarded Restore PC
scraping preferences are separate from code rollback. Newer choices/schema/version
changes are not overwritten. No paired-suite receipt means no startup preference
reads. Trailer-preset consent is not required. Any existing scraping setup record
(complete, declined, restored or failed) is preserved, not automatically reapplied.
The manual menu remains available with confirmation. Busy playback, unknown
dialogs, shutdown or interrupted transactions block changes; startup retries are
bounded. Known LeanStream Home browsing alone is not a blocker. Only scraping
values change; all Android/YouTube/display/HDR/decoder presets remain optional.
Existing accounts/provider packages are never transplanted. Native acceptance of
this new scraping preset remains separate from isolated tests.

Android playback details now use a scrollable report before a short confirmation,
so the ALL-Kodi-video/HDR warning can be read in full. Decline still makes no setters.

ANDROID PLAYBACK PRESET (OPTIONAL, REVERSIBLE)
Apply Android playback preset - 1080p trailers changes exactly three values:
Kodi videoplayer.usemediacodec=true, videoplayer.usemediacodecsurface=false;
YouTube kodion.mpd.quality.selection=4 (maximum 1080p, lower options retained).
The two decoder switches affect ALL Kodi video. Inline H264/EGL worked in the
local Shield samples; HDR/Dolby Vision output correctness remains unverified.
No display, HDR, refresh rate, codec feature list or account settings are copied.
Windows/non-Android is a no-op. Existing tested suite/YouTube/DASH are required.

Each changed value and the global-decoder/HDR warning require explicit approval.
A strict three-value backup precedes setters; native readback verifies success.
Restore Android playback preferences is separate from suite/updater code restore.
Interrupted state blocks other changes until restored. Newer user quality choices
and changed YouTube schema/version are not overwritten by restore. No boot-time
enforcement. An existing verified paired-install/trailer receipt allows one
startup offer; no receipt means no startup preference reads. Existing suite users
may use the manual menu without reinstalling the private application or skin.
The scraping-only automatic migration above can run after this updater upgrade
when an existing verified suite receipt is present. Android playback still needs
its own explicit approval and is never applied by the scraping migration.

Local isolated tests are not native updater/Shield runtime acceptance. This
candidate is not a repair for the independent Stop/return hang or HDR pipeline.

CHECK GITHUB ACCESS (NO CHANGES)
Manual menu check of this device's existing github_token setting: account,
private repository and exact Shield test feed. Shows HTTP status, safe account
name, expiry when GitHub reports it, quota and endpoint permission requirements.
These requirements are NOT the token's complete privileges. Missing expiry is
not proof that a token expired. Invalid/revoked credentials, insufficient access,
rate limits, hidden/missing resources and network failures are reported separately.
Downloads now distinguish HTTP401/403/429 and direct you to this safe report.

At most three GET requests, eight-second socket timeouts, bounded response sizes,
cancellation and no automatic retries. Redirects are blocked; authorization is
never forwarded. Only typed/allowlisted metadata is displayed, never raw bodies,
headers, exceptions, token values/fragments or fingerprints. No diagnostic file,
credential change, account reset or install. Safe to send a report screenshot;
never send the token value. This is manual only, not a startup/service probe.
The diagnostic is available even while an interrupted setup needs restoration;
it does not clear or bypass the setup guards. Restart after updating the updater.

Local tests do not establish native Shield acceptance or fix its unknown token.
The public update contains updater code only; suite, skin, AI and settings stay.
GitHub reference: https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api

SAFE TRAILER PREFERENCES
The verified paired suite queues a receipt-bound request, without reading or
changing YouTube preferences before a normal Kodi restart. The owner then sees
the exact differences and can approve eleven non-secret playback, cache and
timeout preferences. Already-matching values need no setters. Declining is not
repeated automatically. No request means no preference reads at startup.

Only these eleven preferences are read, backed up and changed. Tokens, API keys,
accounts, cookies, history, proxy, SSL, DRM, codec and security settings are never
copied. The installed YouTube schema, suite receipt, full code/model hashes,
registered versions and required dependencies must verify before any setter.
The preference snapshot is saved first; every setter is read back. A failed apply
attempt restores the original allowlisted values, or leaves an explicit recovery
state if restoration fails. Interrupted preference work blocks further code updates.
Restore trailer preferences is separate from code-only suite/updater restoration
and refuses changed schemas/YouTube versions or newer user preference values.

The candidate does not apply settings on this PC or any Shield. Native Kodi 21
setter/dialog behavior, normal restart, playback and cold/warm response time must
be accepted on the device. Matching PC preferences does not guarantee PC speed.

DEPENDENCY COMPATIBILITY REPAIR
Kodi checks each requested minimum against the provided version AND each requested
compiled interface against the provided backwards-compatible ABI. Both checks are
now preserved throughout dependency expansion, duplicates and verified planned
packages. A compiled interface1.1.9 with declaredminimum1.1.7 can accept provided
version1.1.8 when its provided ABI is compatible; do not recommend a Kodi upgrade
from the former false TOO OLD warning alone. Actual device metadata is still needed.

Missing minversion follows Kodi's version fallback, including canonical0.0.0.
Unknown/malformed metadata, incompatible ABI and genuinely old required components
remain blocking. Unreadable XML is not treated as an empty ready dependency list.
Reports include updater/Kodi versions, requested interface, provided ABI and the
requesting add-on. All declarations survive merging; graph/XML limits prevent
unbounded checks. Non-portable numeric components above2147483647 fail closed.
Public release/package validation remains strict and separate from dependency
version suffix/epoch comparison; no unknown version is guessed safe.

SUITE PREPARATION
Kodi built-in xbmc.* and kodi.binary.* interfaces are checked from the application
VFS addon.xml metadata, not the normal add-on JSON-RPC listing. They are never
downloaded as separate add-ons. Missing/mismatched/unreadable/old core metadata
remains blocking; versions are not guessed from the Kodi major version.

Only a verified paired add-on + skin + AI installation can prepare prerequisites.
All package identities, checksums, declarations and AI files are validated first.
After owner confirmation, required missing add-ons are requested through native
InstallAddon and disabled approved modules through EnableAddon. Kodi handles its
existing repository policy, platform binary packages, dependency resolution,
menu locks, dialogs and confirmation. No repository, unknown-source or security
settings are changed. Accounts/providers/DRM setup are never automated.

Available declared optional modules may also be requested after confirmation.
Unavailable optional modules stay optional and do not block suite installation.
Every completed action and the final required tree are rechecked before replacing
private suite files. A declined/failed required action prevents suite replacement.
Completed Kodi prerequisite changes may remain if later cancelled or failed;
they are not part of the updater's private code-only rollback.

Kodi 21 InstallAddon does not upgrade an already-installed old add-on. Old or
unknown required versions remain blockers: no uninstalls, arbitrary binary ZIPs,
global add-on updates or false success. Native modal dialogs wait for Kodi/user
completion, not a hard wall-clock timeout. At most32 requested native actions.
The read-only prerequisite menu never installs anything or reads private tokens.

UPDATER SELF-UPGRADE
Update updater uses the fixed public HTTPS updater-only feed and requires explicit
confirmation, verified size/SHA256/ZIP/code checks and a separate code backup.
No private token is read. Restore updater backup is separate from suite rollback.
Exit and reopen Kodi normally after self-upgrade or restore. No background updates.
The issued 1.1.2/1.1.3 updaters can receive this future version through Update updater
after it is tested and published. This local candidate is not a published release.

PRIVATE SUITE
Exactly plugin.video.leanstream + skin.leanstream and verified Potion 4M int8 files
are required by the paired manifest. Missing test feed has no legacy fallback.
The approved default-skin request runs only after a normal restart and verified
complete installation. Kodi's native Keep this skin confirmation is not bypassed.
Existing skin remains for recovery. Updater installation alone never changes skin.
Experimental AI switches remain unchanged; package defaults are not device settings.

SAFETY AND ACCEPTANCE
Keep existing updater settings; do not uninstall or clear Kodi/account data.
No credential transfer, telemetry, provider cleanup, remote access, external-skin
edits, model enablement or account/security changes. Dependency-version suffix
checks from1.1.1 and self-upgrade/recovery guards from1.1.2 are retained.
Local isolated/package checks do not prove actual Shield/native dialog behavior.
The actual PC XML graph and a photo-version replay are audited; replay retains
PC declarations/ABI and is not a substitute for a new report on the actual Shield.
Android VFS metadata, native install/enable dialogs, repository availability,
registration/restart and the default-skin prompt require device acceptance.

If a power interruption leaves the updater unavailable, reinstall its bootstrap
ZIP without uninstall/settings reset, then use Restore updater backup. Code-only
suite backups cover the private add-on and skin, not native prerequisite add-ons.

Kodi source: https://shana00.github.io/leanstream-updater/
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/interfaces/builtins/AddonBuiltins.cpp
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/interfaces/json-rpc/AddonsOperations.cpp
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/addons/addoninfo/AddonInfo.cpp
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/addons/addoninfo/AddonInfo.h
