# -*- coding: utf-8 -*-
import sys
from resources.lib.updater import entrypoint

entrypoint(sys.argv[2] if len(sys.argv) > 2 else "")
