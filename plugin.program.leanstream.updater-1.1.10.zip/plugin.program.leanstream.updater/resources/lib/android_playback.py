"""Explicit reversible Kodi21 Android preset, not a profile or boot enforcement.

Two native Kodi booleans and the YouTube DASH cap only. Startup needs the existing
verified paired-install/trailer receipt. An updater upgrade alone changes nothing.
"""
import os
import re
import uuid
import xml.etree.ElementTree as ET
from resources.lib import bundle, trailer_setup

RECORD = 'android-playback-preset.json'
CODEC = 'videoplayer.usemediacodec'
SURFACE = 'videoplayer.usemediacodecsurface'
QUALITY = 'kodion.mpd.quality.selection'
VALUES = {CODEC: True, SURFACE: False, QUALITY: 4}
ACTIVE = ('applying', 'restore_pending')
STATES = ACTIVE + ('complete', 'failed', 'restored', 'declined')


def _path(data):
    path = os.path.join(data, RECORD)
    if (os.path.basename(os.path.abspath(data)) != bundle.SELF_ID
            or any(bundle.is_link(x) for x in (data, os.path.dirname(os.path.abspath(data)), path))):
        raise bundle.UpdateError('Android playback backup path is unsafe; nothing changed.')
    return path


def _values(values):
    if (not isinstance(values, dict) or set(values) != set(VALUES)
            or any(type(values[k]) is not type(v) for k, v in VALUES.items())
            or not 0 <= values[QUALITY] <= 8):
        raise bundle.UpdateError('Android playback backup values are invalid.')
    return values


def read(data):
    path = _path(data)
    if not os.path.isfile(path):
        return None
    with open(path, 'rb') as stream:
        raw = stream.read(65537)
    if len(raw) > 65536:
        raise bundle.UpdateError('Android playback backup is too large.')
    info = bundle.read_json(raw)
    expected = {'schema', 'state', 'transaction', 'request_transaction', 'before',
                'desired', 'youtube_version', 'rules_digest'}
    if (not isinstance(info, dict) or set(info) != expected
            or type(info.get('schema')) is not int or info['schema'] != 1
            or info.get('state') not in STATES
            or not isinstance(info.get('transaction'), str)
            or not re.fullmatch(r'[a-f0-9]{32}', info['transaction'])
            or (info.get('request_transaction') is not None and
                (not isinstance(info['request_transaction'], str) or
                 not re.fullmatch(r'[a-f0-9]{32}', info['request_transaction'])))
            or not isinstance(info.get('rules_digest'), str)
            or not re.fullmatch(r'[a-f0-9]{64}', info['rules_digest'])):
        raise bundle.UpdateError('Android playback backup record is invalid.')
    _values(info['before']); _values(info['desired'])
    if info['desired'] != VALUES:
        raise bundle.UpdateError('Unexpected Android playback preset in backup.')
    bundle.dependency_compare(info['youtube_version'], '7.0.0')
    return info


def _save(data, info):
    path = _path(data)
    os.makedirs(data, exist_ok=True)
    bundle._write_json(path, info)


def interrupted(data):
    info = read(data)
    return bool(info and info['state'] in ACTIVE)


def _android(ui, startup=False):
    if ui.xbmc.getCondVisibility('System.Platform.Android'):
        return True
    if not startup:
        ui.DIALOG.ok('Android playback preset', 'This preset is Android-only. Windows and other platforms are unchanged.')
    return False


def _idle(ui):
    trailer_setup._idle(ui)
    if trailer_setup.interrupted(ui.DATA):
        raise bundle.UpdateError('Restore interrupted trailer preferences before Android playback setup.')


def _suite(ui):
    for addon_id, minimum in ((bundle.PLUGIN, '1.0.23.22'), (bundle.SKIN, '0.3.2')):
        folder = bundle._target(ui.ADDONS, addon_id)
        root = ET.parse(os.path.join(folder, 'addon.xml')).getroot()
        registered = ui.lookup(addon_id)
        if (root.tag != 'addon' or root.get('id') != addon_id or not registered
                or root.get('version') != registered[0]
                or bundle.dependency_compare(registered[0], minimum) < 0
                or (addon_id == bundle.PLUGIN and registered[1] is not True)):
            raise bundle.UpdateError('Install/register the tested LeanStream suite and restart Kodi before this preset.')
    if any(row['required'] and row['status'] != 'OK'
           for row in ui.requirement_rows(list(bundle.TRAILER_REQUIREMENTS))):
        raise bundle.UpdateError('Trailer dependencies must be verified and enabled before this preset.')


def _context(ui, restoring=False):
    addon, rules, digest, version = trailer_setup._rules(ui)
    if 4 not in rules[QUALITY][3]:
        raise bundle.UpdateError('This YouTube version does not expose the tested 1080p cap.')
    if not restoring and (addon.getSettingBool('kodion.video.quality.isa') is not True
            or addon.getSettingBool('kodion.mpd.videos') is not True):
        raise bundle.UpdateError('Finish the verified trailer/InputStream preset first; DASH must be enabled.')
    return addon, rules, digest, version


def _snapshot(ui, addon, rules):
    values = {}
    for setting in (CODEC, SURFACE):
        result = ui.rpc('Settings.GetSettingValue', {'setting': setting})
        if not isinstance(result, dict) or type(result.get('value')) is not bool:
            raise bundle.UpdateError('Native Android decoder setting is unavailable; nothing changed.')
        values[setting] = result['value']
    values[QUALITY] = addon.getSettingInt(QUALITY)
    _values(values)
    if values[QUALITY] not in rules[QUALITY][3]:
        raise bundle.UpdateError('Current trailer quality is not supported by the installed schema.')
    return values


def _write(ui, addon, rules, values):
    _values(values)
    if values[QUALITY] not in rules[QUALITY][3]:
        raise bundle.UpdateError('Saved trailer quality is unsupported; restore stopped.')
    current = _snapshot(ui, addon, rules)
    order = (CODEC, SURFACE, QUALITY) if values[CODEC] else (SURFACE, CODEC, QUALITY)
    for name in order:
        if current[name] == values[name]:
            continue
        if ui.xbmc.Player().isPlaying() or ui.xbmc.Monitor().abortRequested():
            raise bundle.UpdateError('Playback or shutdown began; finish preference restore when idle.')
        accepted = (addon.setSettingInt(name, values[name]) if name == QUALITY else
                    ui.rpc('Settings.SetSettingValue', {'setting': name, 'value': values[name]}))
        if accepted is not True:
            raise bundle.UpdateError('Kodi rejected an Android playback preference.')
    if _snapshot(ui, addon, rules) != values:
        raise bundle.UpdateError('Android playback preference readback failed.')


def _request(ui, startup):
    if not startup:
        return None
    request = trailer_setup.read_request(ui.DATA)
    if not request or request['state'] != 'complete':
        return False
    trailer_setup._pair(ui, request)
    return request


def apply(ui, startup=False):
    if not _android(ui, startup):
        return False
    previous = read(ui.DATA)
    if startup and previous and previous['state'] not in ACTIVE:
        return False  # No boot enforcement or repeat after any decision.
    request = _request(ui, startup)
    if request is False:
        return False
    _idle(ui)
    with bundle.update_lock(ui.DATA):
        if interrupted(ui.DATA):
            raise bundle.UpdateError('Use Restore Android playback preferences before another setup.')
        _suite(ui)
        addon, rules, digest, version = _context(ui)
        before = _snapshot(ui, addon, rules)
        if before == VALUES:
            if startup and previous is None:
                _save(ui.DATA, dict(schema=1, state='complete', transaction=uuid.uuid4().hex,
                      request_transaction=request['transaction'], before=before, desired=dict(VALUES),
                      youtube_version=version, rules_digest=digest))
            if not startup:
                ui.DIALOG.ok('Android playback preset', 'Already using MediaCodec ON, Surface OFF and a 1080p trailer cap. Nothing changed.')
            return True
        previous = read(ui.DATA)
        if previous and previous['state'] not in ('restored', 'declined', 'failed'):
            raise bundle.UpdateError('An unrestored Android preference backup exists. Restore it before replacing newer choices.')
        info = dict(schema=1, state='declined', transaction=uuid.uuid4().hex,
                    request_transaction=request['transaction'] if request else None,
                    before=before, desired=dict(VALUES), youtube_version=version, rules_digest=digest)
        changes = '\n'.join('{}: {} -> {}'.format(k, before[k], v) for k, v in VALUES.items() if before[k] != v)
        ui.DIALOG.textviewer('Android playback - changes and limits', changes +
                '\n\nMediaCodec ON / Surface OFF, YouTube maximum 1080p (lower resolutions remain available). '
                'The decoder switches affect ALL Kodi video, not only trailers. '
                'This fixes the tested Shield inline black-picture path; HDR/Dolby Vision output is NOT verified. '
                'Only these three values change. A restore backup is saved. Accounts, codec lists and display/HDR settings stay untouched.')
        if not ui.DIALOG.yesno('Apply Android playback preset?',
                'MediaCodec ON / Surface OFF; trailer cap 1080p.\n'
                'Affects ALL Kodi video. HDR/Dolby Vision output is NOT verified.\n'
                'Save with a restore backup?'):
            _save(ui.DATA, info)
            return False
        _idle(ui); _suite(ui)
        addon2, rules2, digest2, version2 = _context(ui)
        if digest2 != digest or version2 != version or _snapshot(ui, addon2, rules2) != before:
            raise bundle.UpdateError('Settings or YouTube changed while confirming; nothing overwritten.')
        info['state'] = 'applying'
        _save(ui.DATA, info)
        try:
            _write(ui, addon2, rules2, VALUES)
            info['state'] = 'complete'; _save(ui.DATA, info)
            return True
        except Exception:
            try:
                _write(ui, addon2, rules2, before)
                info['state'] = 'failed'; _save(ui.DATA, info)
            except Exception:
                info['state'] = 'restore_pending'; _save(ui.DATA, info)
                raise bundle.UpdateError('Android playback setup interrupted. Use Restore Android playback preferences when idle. Accounts unchanged.') from None
            raise bundle.UpdateError('Android playback setup failed; the original three values were restored.') from None


def restore(ui):
    if not _android(ui):
        return False
    _idle(ui)
    with bundle.update_lock(ui.DATA):
        info = read(ui.DATA)
        if not info or info['state'] in ('restored', 'declined'):
            ui.DIALOG.ok('Restore Android playback preferences', 'No unrestored Android playback backup is available.')
            return False
        addon, rules, digest, version = _context(ui, restoring=True)
        if digest != info['rules_digest'] or version != info['youtube_version']:
            raise bundle.UpdateError('YouTube version/schema changed; preference restore stopped safely.')
        current = _snapshot(ui, addon, rules)
        if any(current[k] not in (info['before'][k], info['desired'][k]) for k in VALUES):
            raise bundle.UpdateError('Newer playback choices exist; restore will not overwrite them.')
        if not ui.DIALOG.yesno('Restore Android playback preferences?',
                'Restore ONLY the two decoder switches and YouTube quality cap saved before setup? '
                'Accounts, display/HDR preferences and suite code remain untouched.'):
            return False
        _idle(ui)
        addon2, rules2, digest2, version2 = _context(ui, restoring=True)
        if digest2 != digest or version2 != version or _snapshot(ui, addon2, rules2) != current:
            raise bundle.UpdateError('Settings or schema changed while confirming restore; nothing overwritten.')
        info['state'] = 'restore_pending'; _save(ui.DATA, info)
        _write(ui, addon2, rules2, info['before'])
        info['state'] = 'restored'; _save(ui.DATA, info)
        return True
