"""Once-only suite scrape policy. Exact allowlist, never accounts or providers."""
import hashlib
import json
import os
import re
import uuid
import xml.etree.ElementTree as ET
from resources.lib import bundle, trailer_setup, android_playback

RECORD = 'pc-scraping-preferences.json'
VALUES = {'general.timeout': 10, 'general.tierThreshold': 0, 'scraping.allTierSweep': False,
          'preem.enabled': True, 'preem.limit': 15, 'preem.type': 0, 'preem.movieres': 3,
          'preem.tvres': 3, 'preem.waitfor.cloudfiles': False, 'preem.cloudfiles': True,
          'preem.adaptiveSources': True, 'preem.directSources': True}
ACTIVE = ('applying', 'restore_pending')


def _path(data):
    path = os.path.join(data, RECORD)
    if (os.path.basename(os.path.abspath(data)) != bundle.SELF_ID or any(bundle.is_link(x)
            for x in (data, os.path.dirname(os.path.abspath(data)), path))):
        raise bundle.UpdateError('Scraping preference backup path is unsafe.')
    return path


def _values(values):
    if (not isinstance(values, dict) or set(values) != set(VALUES)
            or any(type(values[k]) is not type(v) for k, v in VALUES.items())
            or any(type(v) is int and not 0 <= v <= 1000000 for v in values.values())):
        raise bundle.UpdateError('Scraping preference allowlist/type mismatch.')
    return values


def read(data):
    path = _path(data)
    if not os.path.isfile(path): return None
    with open(path, 'rb') as stream: raw = stream.read(65537)
    if len(raw) > 65536: raise bundle.UpdateError('Scraping backup is too large.')
    info = bundle.read_json(raw)
    if (not isinstance(info, dict) or set(info) != {'schema', 'transaction', 'state', 'before',
                'desired', 'addon_version', 'rules_digest'} or type(info.get('schema')) is not int
            or info['schema'] != 1 or info.get('state') not in ACTIVE + ('complete', 'failed', 'restored', 'declined')
            or not isinstance(info.get('transaction'), str) or not re.fullmatch(r'[a-f0-9]{32}', info['transaction'])
            or not isinstance(info.get('rules_digest'), str) or not re.fullmatch(r'[a-f0-9]{64}', info['rules_digest'])):
        raise bundle.UpdateError('Invalid scraping backup record.')
    _values(info['before']); _values(info['desired'])
    if info['desired'] != VALUES: raise bundle.UpdateError('Unexpected scraping preset.')
    bundle.ver(info['addon_version'])
    return info


def _save(data, info):
    path = _path(data); os.makedirs(data, exist_ok=True); bundle._write_json(path, info)


def interrupted(data):
    info = read(data)
    return bool(info and info['state'] in ACTIVE)


def _idle(ui, automatic=False):
    trailer_setup._idle(ui, allow_home=automatic)
    if trailer_setup.interrupted(ui.DATA) or android_playback.interrupted(ui.DATA):
        raise bundle.UpdateError('Restore interrupted playback/trailer preferences before scraping setup.')


def _rules(ui):
    registered = ui.lookup(bundle.PLUGIN)
    if not registered or registered[1] is not True or bundle.ver(registered[0]) < bundle.ver('1.0.23.22'):
        raise bundle.UpdateError('A registered enabled tested LeanStream suite is required.')
    addon = ui.xbmcaddon.Addon(bundle.PLUGIN)
    if addon.getAddonInfo('version') != registered[0]:
        raise bundle.UpdateError('LeanStream registration changed; restart before setup.')
    raw = ui.read_core(os.path.join(addon.getAddonInfo('path'), 'resources', 'settings.xml'), 1048577)
    if len(raw) > 1048576 or b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise bundle.UpdateError('LeanStream settings schema is unsafe or too large.')
    root = ET.fromstring(raw)
    if root.tag != 'settings': raise bundle.UpdateError('LeanStream settings schema is unavailable.')
    rules = {}
    for name, desired in VALUES.items():
        nodes = root.findall(".//setting[@id='" + name + "']")
        expected = 'boolean' if type(desired) is bool else 'integer'
        if len(nodes) != 1 or nodes[0].get('type') != expected:
            raise bundle.UpdateError('Scraping setting IDs/types differ; no preset applied.')
        node = nodes[0]
        minimum, maximum = int(node.findtext('constraints/minimum', '0')), int(node.findtext('constraints/maximum', '1000000'))
        options = [int(x.text) for x in node.findall('constraints/options/option')]
        if not 0 <= minimum <= maximum <= 1000000 or any(not minimum <= x <= maximum for x in options):
            raise bundle.UpdateError('Unsupported scraping preference range.')
        rules[name] = [minimum, maximum, sorted(options)]
    _check(VALUES, rules)
    digest = hashlib.sha256(json.dumps(rules, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return addon, rules, digest, registered[0]


def _check(values, rules):
    _values(values)
    for name, value in values.items():
        low, high, options = rules[name]
        if type(value) is int and (not low <= value <= high or options and value not in options):
            raise bundle.UpdateError('Scraping preference unsupported by the installed schema.')


def _read(addon, rules):
    values = {k: addon.getSettingBool(k) if type(v) is bool else addon.getSettingInt(k) for k, v in VALUES.items()}
    _check(values, rules); return values


def _write(ui, addon, rules, values, automatic=False):
    _check(values, rules); current = _read(addon, rules)
    for name, value in values.items():
        if current[name] == value: continue
        _idle(ui, automatic)
        setter = addon.setSettingBool if type(value) is bool else addon.setSettingInt
        if setter(name, value) is not True: raise bundle.UpdateError('Kodi rejected a scraping preference.')
    if _read(addon, rules) != values: raise bundle.UpdateError('Scraping preference readback failed.')


def automatic_pending(data):
    # Any terminal record (including declined/restored/failed) preserves the
    # previous choice and backup. Never enforce a preset on every boot/update.
    if read(data) is not None: return False
    request = trailer_setup.read_request(data)
    return bool(request and request['state'] in ('pending', 'complete', 'declined'))


def apply(ui, startup=False):
    previous = read(ui.DATA)
    if startup:
        if previous and previous['state'] not in ACTIVE: return False
        request = trailer_setup.read_request(ui.DATA)
        if not request or request['state'] == 'cancelled': return False
        _idle(ui, automatic=True)
        # Bind to a real completed suite transaction, not trailer-preset consent.
        trailer_setup._pair(ui, request)
    _idle(ui, automatic=startup)
    with bundle.update_lock(ui.DATA):
        if interrupted(ui.DATA): raise bundle.UpdateError('Use Restore PC scraping preferences first.')
        previous = read(ui.DATA)
        if startup:
            if previous is not None: return False
            if trailer_setup.read_request(ui.DATA) != request:
                raise bundle.UpdateError('Suite setup receipt changed; scraping preferences unchanged.')
        addon, rules, digest, version = _rules(ui)
        before = _read(addon, rules)
        if before == VALUES:
            if startup and previous is None:
                _save(ui.DATA, dict(schema=1, state='complete', transaction=uuid.uuid4().hex,
                      before=before, desired=dict(VALUES), addon_version=version, rules_digest=digest))
            if not startup: ui.DIALOG.ok('PC scraping preset', 'Already matches the PC scraping preset. Nothing changed.')
            return True
        if previous and previous['state'] not in ('restored', 'declined', 'failed'):
            raise bundle.UpdateError('Restore the prior scraping backup before replacing newer choices.')
        info = dict(schema=1, state='declined', transaction=uuid.uuid4().hex, before=before,
                    desired=dict(VALUES), addon_version=version, rules_digest=digest)
        changes = '\n'.join('{}: {} -> {}'.format(k, before[k], v) for k, v in VALUES.items() if before[k] != v)
        if not startup:
            ui.DIALOG.textviewer('PC scraping - changes and limits', changes + '\n\n'
            'Match the owner PC:15 qualifying cached torrent sources, all tiers eligible (Tier Skip Threshold0), '
            '10-second scrape timeout, SD-and-up resolution counted. Existing cloud/direct/adaptive early-stop rules remain ON; '
            'one such result can stop before15. These are stop conditions, not a guarantee of15 playable links. '
            'The timeout is shorter than30 seconds and can limit slow providers. Cached does not mean playback verified. '
            'Only12 allowlisted scraping preferences can change. Accounts, credentials, provider packages and playback settings stay untouched. '
                'A preference-only restore backup is saved.')
            if not ui.DIALOG.yesno('Match PC scraping settings?',
                    '15 sources; tier skip OFF; timeout10s.\nCloud/direct/adaptive results can still stop early.\nSave with a restore backup?'):
                _save(ui.DATA, info); return False
        _idle(ui, automatic=startup)
        addon2, rules2, digest2, version2 = _rules(ui)
        if digest2 != digest or version2 != version or _read(addon2, rules2) != before:
            raise bundle.UpdateError('Scraping settings/schema changed while confirming; nothing overwritten.')
        info['state'] = 'applying'; _save(ui.DATA, info)
        try:
            _write(ui, addon2, rules2, VALUES, automatic=startup)
            info['state'] = 'complete'; _save(ui.DATA, info); return True
        except Exception:
            try:
                _write(ui, addon2, rules2, before, automatic=startup)
                info['state'] = 'failed'; _save(ui.DATA, info)
            except Exception:
                info['state'] = 'restore_pending'; _save(ui.DATA, info)
                raise bundle.UpdateError('Scraping setup interrupted. Use Restore PC scraping preferences when idle. Accounts unchanged.') from None
            raise bundle.UpdateError('Scraping setup failed; original allowed values were restored.') from None


def restore(ui):
    _idle(ui)
    with bundle.update_lock(ui.DATA):
        info = read(ui.DATA)
        if not info or info['state'] in ('restored', 'declined'):
            ui.DIALOG.ok('Restore PC scraping preferences', 'No unrestored scraping backup is available.'); return False
        addon, rules, digest, version = _rules(ui)
        if digest != info['rules_digest'] or version != info['addon_version']:
            raise bundle.UpdateError('LeanStream version/schema changed; restore stopped safely.')
        current = _read(addon, rules)
        if any(current[k] not in (info['before'][k], info['desired'][k]) for k in VALUES):
            raise bundle.UpdateError('Newer scraping choices exist; restore will not overwrite them.')
        if not ui.DIALOG.yesno('Restore PC scraping preferences?',
                'Restore the12 scraping values saved before setup?\nAccounts and playback preferences stay untouched.'):
            return False
        _idle(ui)
        addon2, rules2, digest2, version2 = _rules(ui)
        if digest2 != digest or version2 != version or _read(addon2, rules2) != current:
            raise bundle.UpdateError('Scraping settings/schema changed while confirming restore.')
        info['state'] = 'restore_pending'; _save(ui.DATA, info)
        _write(ui, addon2, rules2, info['before'])
        info['state'] = 'restored'; _save(ui.DATA, info); return True
