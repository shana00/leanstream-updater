"""One-shot, owner-approved default-skin setup after a complete bundle update."""
import os
import re
import xml.etree.ElementTree as ET

from resources.lib import bundle

NAME = "skin-setup.json"


def read_request(data):
    path = os.path.join(data, NAME)
    if not os.path.isfile(path):
        return None
    if bundle.is_link(data) or bundle.is_link(path):
        raise bundle.UpdateError("Skin setup record is linked; nothing changed.")
    with open(path, "rb") as stream:
        request = bundle.read_json(stream.read(65537))
    if (not isinstance(request, dict) or type(request.get("schema")) is not int or request.get("schema") != 1
            or request.get("skin") != bundle.SKIN
            or request.get("state") not in ("pending", "applying", "complete", "failed", "cancelled")
            or not re.fullmatch(r"[a-f0-9]{64}", request.get("skin_digest", ""))
            or not re.fullmatch(r"skin\.[A-Za-z0-9_.-]{1,100}", request.get("previous_skin", ""))):
        raise bundle.UpdateError("Skin setup record is invalid; nothing changed.")
    bundle.ver(request.get("skin_version", ""))
    bundle.ver(request.get("plugin_version", ""))
    return request


def save(data, request):
    os.makedirs(data, exist_ok=True)
    if bundle.is_link(data) or bundle.is_link(os.path.join(data, NAME)):
        raise bundle.UpdateError("Skin setup target is linked; nothing changed.")
    bundle._write_json(os.path.join(data, NAME), request)


def queue(addons, data, packages, previous_skin):
    versions = {x["addon_id"]: x["version"] for x in packages}
    if set(versions) != {bundle.PLUGIN, bundle.SKIN}:
        raise bundle.UpdateError("Default skin needs a complete add-on and skin release.")
    request = {"schema": 1, "state": "pending", "skin": bundle.SKIN,
               "skin_version": versions[bundle.SKIN], "plugin_version": versions[bundle.PLUGIN],
               "skin_digest": bundle.tree_digest(bundle._target(addons, bundle.SKIN)),
               "previous_skin": previous_skin}
    if not re.fullmatch(r"skin\.[A-Za-z0-9_.-]{1,100}", previous_skin):
        raise bundle.UpdateError("Previous skin identity is unavailable; use Kodi Interface settings.")
    with bundle.update_lock(data):
        save(data, request)


def cancel(data):
    with bundle.update_lock(data):
        request = read_request(data)
        if request:
            request["state"] = "cancelled"
            save(data, request)


def apply(ui, startup=False):
    """No downloads, account reads or forced confirmation; Kodi owns skin reload."""
    request = read_request(ui.DATA)
    if not request or request["state"] in ("complete", "cancelled"):
        if not startup:
            ui.DIALOG.ok("LeanStream default skin", "No full-bundle skin setup is pending. "
                         "Install the paired test release and restart Kodi first.")
        return False
    # Never retry a declined/failed/abruptly interrupted switch at every startup.
    if startup and request["state"] != "pending":
        return False
    if not startup and not ui.DIALOG.yesno("Use LeanStream as the default skin?",
            "Only the skin selection will change. Choose Yes in Kodi's Keep this skin prompt. "
            "Accounts and credentials remain yours; the previous skin stays installed."):
        return False
    monitor = ui.xbmc.Monitor()
    for _ in range(40):
        if monitor.abortRequested():
            return False
        if (not ui.xbmc.Player().isPlaying()
                and not ui.xbmc.getCondVisibility("System.HasModalDialog")
                and ui.lookup(bundle.SKIN) and ui.lookup(bundle.PLUGIN)):
            break
        if monitor.waitForAbort(0.5):
            return False
    else:
        # Leave pending; a later explicit invocation can finish after registration.
        return False
    with bundle.update_lock(ui.DATA):
        request = read_request(ui.DATA)
        record = bundle.last_backup(ui.DATA)
        if not request or request["state"] in ("complete", "cancelled"):
            return False
        if (not record or record["state"] != "complete"
                or {x["id"] for x in record["components"]} != {bundle.PLUGIN, bundle.SKIN}):
            raise bundle.UpdateError("Complete paired installation not verified; skin unchanged.")
        match = re.match(r"(\d+)", ui.xbmc.getInfoLabel("System.BuildVersion"))
        if not match or int(match.group(1)) != 21:
            raise bundle.UpdateError("Default-skin setup requires Kodi 21.")
        for addon_id, version in ((bundle.PLUGIN, request["plugin_version"]),
                                  (bundle.SKIN, request["skin_version"])):
            folder = bundle._target(ui.ADDONS, addon_id)
            root = ET.parse(os.path.join(folder, "addon.xml")).getroot()
            registered = ui.lookup(addon_id)
            if root.get("id") != addon_id or root.get("version") != version or registered[0] != version:
                raise bundle.UpdateError("Installed and registered release versions differ; restart Kodi.")
        if bundle.tree_digest(bundle._target(ui.ADDONS, bundle.SKIN)) != request["skin_digest"]:
            raise bundle.UpdateError("Installed skin files changed; default-skin setup stopped.")
        bundle.validate_ai(lambda name: _read_code(ui.ADDONS, name))
        if not ui.lookup(bundle.PLUGIN)[1]:
            raise bundle.UpdateError("Enable LeanStream in My add-ons before choosing its skin.")
        request["state"] = "applying"
        save(ui.DATA, request)
        try:
            if not ui.lookup(bundle.SKIN)[1]:
                if ui.rpc("Addons.SetAddonEnabled", {"addonid": bundle.SKIN, "enabled": True}) != "OK":
                    raise bundle.UpdateError("Kodi could not enable LeanStream skin; use My add-ons.")
                if not ui.lookup(bundle.SKIN) or not ui.lookup(bundle.SKIN)[1]:
                    raise bundle.UpdateError("Skin enablement was not confirmed; nothing selected.")
            if ui.xbmc.getSkinDir() != bundle.SKIN:
                ui.DIALOG.notification("LeanStream setup", "Choose Yes when Kodi asks to keep the skin.")
                if ui.rpc("Settings.SetSettingValue", {"setting": "lookandfeel.skin", "value": bundle.SKIN}) is not True:
                    raise bundle.UpdateError("Kodi rejected skin selection; use Interface / Skin.")
                # Kodi's native 10-second Keep confirmation is not bypassed. Wait
                # beyond its timeout and verify both active and saved skin values.
                for _ in range(26):
                    if monitor.waitForAbort(0.5):
                        return False
            selected = ui.rpc("Settings.GetSettingValue", {"setting": "lookandfeel.skin"})
            if (ui.xbmc.getSkinDir() != bundle.SKIN or not isinstance(selected, dict)
                    or selected.get("value") != bundle.SKIN):
                raise bundle.UpdateError("Skin was not kept. Previous/default skin remains available; "
                                         "retry Finish default-skin setup when ready.")
            request["state"] = "complete"
            save(ui.DATA, request)
            return True
        except Exception:
            request["state"] = "failed"
            save(ui.DATA, request)
            raise


def _read_code(addons, name):
    folder = bundle._target(addons, bundle.PLUGIN)
    with open(os.path.join(folder, *name.split("/")), "rb") as stream:
        return stream.read(bundle.MAX_PACKAGE + 1)
