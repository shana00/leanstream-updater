"""Explicit, short-lived LAN download of one sanitized in-memory report.

No public upload, external QR service, directory serving, request logging or
credential handling. Plain HTTP is NOT encrypted; use a trusted private Wi-Fi.
"""
import hmac
from http.server import BaseHTTPRequestHandler, HTTPServer
import ipaddress
import secrets
import struct
import threading
import time
import zlib
from resources.lib.qrcodegen import QrCode

NETWORKS = tuple(ipaddress.ip_network(n) for n in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16'))
MAX_REPORT = 256 * 1024


def private_ip(value):
    try:
        addr = ipaddress.IPv4Address(value)
        return any(addr in net for net in NETWORKS)
    except (ValueError, TypeError):
        return False


def qr_png(url):
    """Lossless grayscale PNG, integer scaling and four-module quiet zone."""
    qr = QrCode.encode_text(url, QrCode.Ecc.MEDIUM)
    scale, border = 8, 4
    size = (qr.get_size() + border * 2) * scale
    scan = bytearray()
    for y in range(-border, qr.get_size() + border):
        row = b'\x00' + bytes(0 if qr.get_module(x, y) else 255
            for x in range(-border, qr.get_size() + border) for _ in range(scale))
        scan.extend(row * scale)
    def chunk(name, data):
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', zlib.crc32(name + data) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', size, size, 8, 0, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(bytes(scan), 9)) + chunk(b'IEND', b'')


class _Server(HTTPServer):
    allow_reuse_address = False
    def handle_error(self, request, client_address):
        pass  # Disconnects must not dump traceback/request context to kodi.log.
    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(1.0)
        return connection, address


class _Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'
    server_version = 'LeanStream'
    sys_version = ''

    def log_message(self, *args):
        pass

    def send_error(self, code, message=None, explain=None):
        # Do not echo paths, headers, exceptions or the transient download token.
        self.send_response(code)
        self.send_header('Content-Length', '0')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Connection', 'close')
        self.end_headers()

    def _serve(self, head=False):
        share = self.server.share
        if not private_ip(self.client_address[0]) and not share._loopback_test:
            return self.send_error(403)
        if len(self.headers.get_all('Host', [])) != 1 or self.headers.get('Host') != share.host:
            return self.send_error(403)
        if not hmac.compare_digest(self.path.encode('utf-8'), share.path.encode('ascii')):
            return self.send_error(404)
        if not share.active or time.monotonic() >= share.deadline or share.downloads >= 8:
            return self.send_error(410)
        body = share.body
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Disposition', 'attachment; filename="LeanStream-setup-report.txt"')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store, max-age=0')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Connection', 'close')
        self.end_headers()
        if not head:
            share.downloads += 1
            self.wfile.write(body)

    def do_GET(self): self._serve()
    def do_HEAD(self): self._serve(True)
    def do_POST(self): self.send_error(405)
    def do_PUT(self): self.send_error(405)
    def do_DELETE(self): self.send_error(405)
    def do_OPTIONS(self): self.send_error(405)


class Share:
    def __init__(self, ip, report, *, _loopback_test=False, ttl=300):
        if not (private_ip(ip) or (_loopback_test and ip == '127.0.0.1')):
            raise ValueError('A private Wi-Fi IPv4 address is required')
        if not isinstance(report, str) or not report or len(report.encode('utf-8')) > MAX_REPORT:
            raise ValueError('Report size is not supported')
        self._loopback_test = _loopback_test
        self.body = report.encode('utf-8')
        self.deadline = time.monotonic() + min(300, max(0.1, ttl))
        self.path = '/' + secrets.token_urlsafe(24) + '/report.txt'
        self.active, self.downloads = True, 0
        self.server = _Server((ip, 0), _Handler)
        self.server.share = self
        self.host = '{}:{}'.format(ip, self.server.server_port)
        self.url = 'http://' + self.host + self.path
        self.server.timeout = 0.25
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        try:
            while self.active and time.monotonic() < self.deadline and self.downloads < 8:
                try:
                    self.server.handle_request()
                except (OSError, ValueError):
                    break
        finally:
            self.active = False
            self.server.server_close()
            self.body = b''

    def close(self):
        self.active = False
        self.thread.join(timeout=2)
        self.server.server_close()
        self.body = b''
        self.url = self.path = ''
