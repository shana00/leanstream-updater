"""Owner-confirmed trailer preferences; exact allowlist, no profile/auth export.

Requests are queued only after a verified paired suite install. Preference
snapshots are separate from suite code rollback and survive a declined request.
All Kodi APIs come from ui for isolated testing; no downloads/native installs.
"""
import hashlib
import json
import os
import re
import xml.etree.ElementTree as ET

from resources.lib import bundle, self_update

YOUTUBE = 'plugin.video.youtube'
REQUEST = 'trailer-setup-request.json'
BACKUP = 'trailer-preferences-backup.json'
VALUES = {
    'kodion.video.quality.isa': True,
    'kodion.mpd.videos': True,
    'kodion.mpd.stream.select': 3,
    'kodion.mpd.quality.selection': 4,
    'kodion.video.stream.select': 2,
    'kodion.video.quality.ask': False,
    'kodion.video.quality': 3,
    'kodion.cache.size': 50,
    'requests.cache.size': 20,
    'requests.timeout.connect': 9,
    'requests.timeout.read': 27,
}
ACTIVE = ('applying', 'restore_pending')


def _path(data, name):
    if (name not in (REQUEST, BACKUP) or os.path.basename(os.path.abspath(data)) != bundle.SELF_ID
            or bundle.is_link(data) or bundle.is_link(os.path.dirname(os.path.abspath(data)))
            or bundle.is_link(os.path.join(data, name))):
        raise bundle.UpdateError('Trailer setup path is unsafe; preferences unchanged.')
    return os.path.join(data, name)


def _values(values):
    if not isinstance(values, dict) or set(values) != set(VALUES):
        raise bundle.UpdateError('Trailer preference allowlist mismatch; nothing changed.')
    for name, value in values.items():
        if type(value) is not type(VALUES[name]) or (type(value) is int and not 0 <= value <= 1000000):
            raise bundle.UpdateError('Trailer preference type or range is invalid.')
    return values


def _load(data, name):
    path = _path(data, name)
    if not os.path.isfile(path):
        return None
    with open(path, 'rb') as stream:
        raw = stream.read(65537)
    if len(raw) > 65536:
        raise bundle.UpdateError('Trailer setup record is too large.')
    info = bundle.read_json(raw)
    if (not isinstance(info, dict) or type(info.get('schema')) is not int or info['schema'] != 1
            or not isinstance(info.get('transaction'), str)
            or not re.fullmatch(r'[a-f0-9]{32}', info['transaction'])):
        raise bundle.UpdateError('Trailer setup record is invalid.')
    return info


def read_request(data):
    info = _load(data, REQUEST)
    if info is None:
        return None
    if (set(info) != {'schema', 'state', 'transaction', 'versions', 'digests'}
            or info.get('state') not in ('pending', 'complete', 'declined', 'cancelled')
            or not isinstance(info.get('versions'), dict) or not isinstance(info.get('digests'), dict)
            or set(info['versions']) != {bundle.PLUGIN, bundle.SKIN}
            or set(info['digests']) != {bundle.PLUGIN, bundle.SKIN}):
        raise bundle.UpdateError('Trailer setup request is invalid.')
    for addon_id in info['versions']:
        bundle.ver(info['versions'][addon_id])
        digest = info['digests'][addon_id]
        if not isinstance(digest, str) or not re.fullmatch(r'[a-f0-9]{64}', digest):
            raise bundle.UpdateError('Trailer setup digest is invalid.')
    return info


def read_backup(data):
    info = _load(data, BACKUP)
    if info is None:
        return None
    if (set(info) != {'schema', 'state', 'transaction', 'before', 'desired', 'youtube_version', 'rules_digest'}
            or info.get('state') not in ('applying', 'complete', 'failed', 'restore_pending', 'restored')
            or not isinstance(info.get('rules_digest'), str)
            or not re.fullmatch(r'[a-f0-9]{64}', info['rules_digest'])):
        raise bundle.UpdateError('Trailer preference backup is invalid.')
    _values(info.get('before')); _values(info.get('desired'))
    if info['desired'] != VALUES:
        raise bundle.UpdateError('Trailer preference backup contains an unexpected preset.')
    bundle.dependency_compare(info.get('youtube_version'), '7.0.0')
    return info


def _save(data, name, info):
    path = _path(data, name)
    os.makedirs(data, exist_ok=True)
    bundle._write_json(path, info)


def interrupted(data):
    info = read_backup(data)
    return bool(info and info['state'] in ACTIVE)


def _idle(ui, allow_home=False):
    if (ui.SELF.getAddonInfo('version') != bundle.VERSION
            or not re.match(r'^21(?:\D|$)', ui.xbmc.getInfoLabel('System.BuildVersion'))):
        raise bundle.UpdateError('Restart Kodi21 with the current updater before trailer setup.')
    # Automatic scraping setup may run behind the known browsing-only Home.
    # All other dialogs, including scrapers/source selection, remain blockers.
    home_only = (allow_home and ui.xbmc.getCondVisibility('System.HasModalDialog')
                 and ui.xbmcgui.getCurrentWindowDialogId() == 13000
                 and ui.xbmc.getInfoLabel('Window(10000).Property(LeanStream.HomeEntry.Window)') == '13000')
    if ui.xbmc.Player().isPlaying() or (ui.xbmc.getCondVisibility('System.HasModalDialog') and not home_only):
        raise bundle.UpdateError('Stop playback and close other dialogs before trailer setup.')
    if ui.xbmc.Monitor().abortRequested():
        raise bundle.UpdateError('Kodi is stopping; trailer preferences unchanged.')
    record = bundle.last_backup(ui.DATA)
    self_record = self_update.state(ui.DATA)
    if ((record and record.get('state') not in ('complete', 'failed', 'restored'))
            or (self_record and self_record.get('state') == 'pending')):
        raise bundle.UpdateError('Restore the interrupted code update before trailer setup.')


def _pair(ui, request):
    record = bundle.last_backup(ui.DATA)
    if (not record or record.get('state') != 'complete' or record['transaction'] != request['transaction']
            or {x['id'] for x in record['components']} != {bundle.PLUGIN, bundle.SKIN}):
        raise bundle.UpdateError('Matching complete paired suite installation is required for trailer setup.')
    for addon_id, version in request['versions'].items():
        folder = bundle._target(ui.ADDONS, addon_id)
        root = ET.parse(os.path.join(folder, 'addon.xml')).getroot()
        registered = ui.lookup(addon_id)
        if (root.get('id') != addon_id or root.get('version') != version
                or not registered or registered[0] != version
                or (addon_id == bundle.PLUGIN and registered[1] is not True)
                or bundle.tree_digest(folder) != request['digests'][addon_id]):
            raise bundle.UpdateError('Suite identity/registration/files changed; trailer setup stopped.')
    def read(name):
        path = os.path.join(bundle._target(ui.ADDONS, bundle.PLUGIN), *name.split('/'))
        with open(path, 'rb') as stream:
            return stream.read(bundle.MAX_PACKAGE + 1)
    bundle.validate_ai(read)
    if any(row['required'] and row['status'] != 'OK'
           for row in ui.requirement_rows(list(bundle.TRAILER_REQUIREMENTS))):
        raise bundle.UpdateError('Trailer dependencies are not verified and enabled; preferences unchanged.')


def queue(ui, packages):
    """No YouTube settings reads/writes; only bind a request to installed code."""
    versions = {x['addon_id']: x['version'] for x in packages}
    if set(versions) != {bundle.PLUGIN, bundle.SKIN}:
        raise bundle.UpdateError('Trailer preset requires the paired suite.')
    with bundle.update_lock(ui.DATA):
        if interrupted(ui.DATA):
            raise bundle.UpdateError('Restore interrupted trailer preferences before another setup.')
        record = bundle.last_backup(ui.DATA)
        if (not record or record.get('state') != 'complete'
                or {x['id'] for x in record['components']} != set(versions)):
            raise bundle.UpdateError('Completed paired suite receipt unavailable.')
        request = dict(schema=1, state='pending', transaction=record['transaction'], versions=versions,
                       digests={x: bundle.tree_digest(bundle._target(ui.ADDONS, x)) for x in versions})
        _save(ui.DATA, REQUEST, request)
    return request


def cancel(data):
    with bundle.update_lock(data):
        request = read_request(data)
        if request and request['state'] == 'pending':
            request['state'] = 'cancelled'; _save(data, REQUEST, request)


def _rules(ui):
    registered = ui.lookup(YOUTUBE)
    if not registered or registered[1] is not True or bundle.dependency_compare(registered[0], '7.0.0') < 0:
        raise bundle.UpdateError('Compatible enabled YouTube add-on is required for trailer preferences.')
    addon = ui.xbmcaddon.Addon(YOUTUBE)
    if addon.getAddonInfo('version') != registered[0]:
        raise bundle.UpdateError('YouTube registration changed; restart Kodi before trailer setup.')
    raw = ui.read_core(os.path.join(addon.getAddonInfo('path'), 'resources', 'settings.xml'), 1048577)
    if len(raw) > 1048576 or b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise bundle.UpdateError('YouTube settings schema is unsafe or too large.')
    root = ET.fromstring(raw)
    if root.tag != 'settings':
        raise bundle.UpdateError('YouTube settings schema unavailable.')
    rules = {}
    for name, desired in VALUES.items():
        nodes = root.findall(".//setting[@id='" + name + "']")
        expected = 'boolean' if type(desired) is bool else 'integer'
        if len(nodes) != 1 or nodes[0].get('type') != expected:
            raise bundle.UpdateError('YouTube setting IDs/types differ; no preset was applied.')
        node = nodes[0]
        options = [int(x.text) for x in node.findall('constraints/options/option')] if expected == 'integer' else []
        minimum = int(node.findtext('constraints/minimum', '0')) if expected == 'integer' else 0
        maximum = int(node.findtext('constraints/maximum', '1000000')) if expected == 'integer' else 1
        if not 0 <= minimum <= maximum <= 1000000 or (options and any(not minimum <= x <= maximum for x in options)):
            raise bundle.UpdateError('YouTube setting range is invalid.')
        rules[name] = [expected, minimum, maximum, sorted(options)]
    _check(VALUES, rules)
    digest = hashlib.sha256(json.dumps(rules, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return addon, rules, digest, registered[0]


def _check(values, rules):
    _values(values)
    for name, value in values.items():
        if type(value) is int:
            _, minimum, maximum, options = rules[name]
            if not minimum <= value <= maximum or (options and value not in options):
                raise bundle.UpdateError('Trailer preference is unsupported by this YouTube version.')


def _read(addon, rules):
    values = {name: (addon.getSettingBool(name) if type(desired) is bool else addon.getSettingInt(name))
              for name, desired in VALUES.items()}
    _check(values, rules)
    return values


def _write(addon, values, rules, ui=None):
    _check(values, rules)
    current = _read(addon, rules)
    for name, value in values.items():
        if current[name] == value:
            continue
        if ui is not None and ui.xbmc.Monitor().abortRequested():
            raise bundle.UpdateError('Kodi stopped during trailer setup; use preference restore if interrupted.')
        setter = addon.setSettingBool if type(value) is bool else addon.setSettingInt
        if setter(name, value) is not True:
            raise bundle.UpdateError('Kodi rejected a trailer preference; original values will be restored.')
    if _read(addon, rules) != values:
        raise bundle.UpdateError('Trailer preference readback failed.')


def apply(ui, startup=False):
    request = read_request(ui.DATA)
    if not request or request['state'] != 'pending':
        if not startup:
            ui.DIALOG.ok('LeanStream trailer setup', 'No pending trailer preset. Install the paired suite and restart Kodi first.')
        return False
    _idle(ui)
    with bundle.update_lock(ui.DATA):
        request = read_request(ui.DATA)
        if not request or request['state'] != 'pending':
            return False
        if interrupted(ui.DATA):
            raise bundle.UpdateError('Restore interrupted trailer preferences first.')
        _pair(ui, request)
        addon, rules, rules_digest, version = _rules(ui)
        before = _read(addon, rules)
        changes = ['{}: {} -> {}'.format(name, before[name], desired)
                   for name, desired in VALUES.items() if before[name] != desired]
        if not changes:
            request['state'] = 'complete'; _save(ui.DATA, REQUEST, request)
            if not startup: ui.DIALOG.ok('Trailer preferences', 'Already match the PC preset. Nothing changed.')
            return True
        if not ui.DIALOG.yesno('Apply LeanStream trailer preferences?', '\n'.join(changes)
                + '\n\nOnly these playback/cache/timeout preferences change. Logins/API keys, network/security and '
                  'age policies stay untouched. A preference-only restore is saved. PC-equivalent speed is not guaranteed.'):
            request['state'] = 'declined'; _save(ui.DATA, REQUEST, request)
            return False
        _idle(ui); _pair(ui, request)
        current_addon, current_rules, current_digest, current_version = _rules(ui)
        if current_digest != rules_digest or current_version != version:
            raise bundle.UpdateError('YouTube version/schema changed while confirming; no preset was applied.')
        addon, rules = current_addon, current_rules
        if _read(addon, rules) != before:
            raise bundle.UpdateError('YouTube preferences changed while confirming; no preset was applied.')
        backup = dict(schema=1, state='applying', transaction=request['transaction'], before=before,
                      desired=dict(VALUES), youtube_version=version, rules_digest=rules_digest)
        _save(ui.DATA, BACKUP, backup)  # Persist old values BEFORE any setting setter.
        try:
            _write(addon, VALUES, rules, ui)
            backup['state'] = 'complete'; _save(ui.DATA, BACKUP, backup)
            request['state'] = 'complete'; _save(ui.DATA, REQUEST, request)
            return True
        except Exception:
            try:
                _write(addon, before, rules)
                backup['state'] = 'failed'; _save(ui.DATA, BACKUP, backup)
                request['state'] = 'cancelled'; _save(ui.DATA, REQUEST, request)
            except Exception:
                backup['state'] = 'restore_pending'; _save(ui.DATA, BACKUP, backup)
                raise bundle.UpdateError('Trailer preference setup interrupted; use Restore trailer preferences. Accounts unchanged.') from None
            raise bundle.UpdateError('Trailer preference setup failed; original allowed values restored. Suite code remains installed.') from None


def restore(ui):
    _idle(ui)
    with bundle.update_lock(ui.DATA):
        backup = read_backup(ui.DATA)
        if not backup or backup['state'] == 'restored':
            ui.DIALOG.ok('Restore trailer preferences', 'No unrestored trailer preference backup is available.')
            return False
        addon, rules, digest, version = _rules(ui)
        if version != backup['youtube_version'] or digest != backup['rules_digest']:
            raise bundle.UpdateError('YouTube version/schema changed; preference restore stopped safely.')
        current = _read(addon, rules); _check(backup['before'], rules)
        if any(current[name] not in (backup['before'][name], backup['desired'][name]) for name in VALUES):
            raise bundle.UpdateError('Preferences changed since setup; review YouTube settings instead of overwriting newer choices.')
        if not ui.DIALOG.yesno('Restore trailer preferences?', 'Restore only the eleven approved playback/cache/timeout values? '
                'Accounts, API keys, network/security settings and suite code are not restored or changed.'):
            return False
        _idle(ui)
        current_addon, current_rules, current_digest, current_version = _rules(ui)
        if current_digest != digest or current_version != version:
            raise bundle.UpdateError('YouTube version/schema changed while confirming; restore stopped.')
        addon, rules = current_addon, current_rules
        if _read(addon, rules) != current:
            raise bundle.UpdateError('Preferences changed while confirming; restore stopped.')
        backup['state'] = 'restore_pending'; _save(ui.DATA, BACKUP, backup)
        _write(addon, backup['before'], rules, ui)
        backup['state'] = 'restored'; _save(ui.DATA, BACKUP, backup)
        request = read_request(ui.DATA)
        if request and request['state'] == 'pending':
            request['state'] = 'cancelled'; _save(ui.DATA, REQUEST, request)
        return True
