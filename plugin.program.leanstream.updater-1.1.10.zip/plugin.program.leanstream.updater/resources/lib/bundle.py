"""Kodi-independent validation and bounded, two-component file transactions."""
import contextlib
from collections import namedtuple
import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
import uuid
import zipfile
import xml.etree.ElementTree as ET

PLUGIN = "plugin.video.leanstream"
SKIN = "skin.leanstream"
SELF_ID = "plugin.program.leanstream.updater"
REPO = "shana00/leanstream-private"
VERSION = "1.1.10"
MAX_DEPENDENCY_XML = 1024 * 1024
MAX_DEPENDENCY_EDGES = 4096
MAX_DEPENDENCY_IDS = 128
Requirement = namedtuple("Requirement", "id minimum required version source")
MAX_PACKAGE = 64 * 1024 * 1024
MAX_EXPANDED = 256 * 1024 * 1024
MODEL = "resources/models/potion-base-4M-int8/"
AI_CODE = (
    "resources/lib/modules/static_embeddings.py",
    "resources/lib/modules/semantic_similarity.py",
    "resources/lib/modules/personalized_similarity.py",
    "resources/lib/modules/semantic_candidate_cache.py",
    "resources/lib/modules/semantic_candidate_hydrator.py",
)
TRAILER_REQUIREMENTS = (
    ("plugin.video.youtube", "7.0.0", True),
    ("inputstream.adaptive", "21.0.0", True),
)


class UpdateError(RuntimeError):
    """A credential-free error safe to show on the TV."""


def ver(value):
    match = re.fullmatch(r"(\d+(?:\.\d+){0,3})(?:[a-zA-Z][a-zA-Z0-9.-]*)?", str(value))
    if not match:
        raise UpdateError("Unrecognised add-on version.")
    parts = [int(x) for x in match.group(1).split(".")]
    return tuple(parts + [0] * (4 - len(parts)))


def _dependency_parts(value):
    """Validate Kodi dependency metadata without relaxing release validation."""
    if not isinstance(value, str) or not 0 < len(value) <= 128:
        raise UpdateError("Unrecognised dependency version.")
    match = re.fullmatch(r"(?:(\d+):)?([A-Za-z0-9.+_@~]+)(?:-([A-Za-z0-9.+_@~]+))?", value)
    if not match:
        raise UpdateError("Unrecognised dependency version.")
    # Kodi's strtol uses a platform-dependent C long. Do not silently compare
    # overflow values differently on Windows and Android: fail closed instead.
    if any(int(x) > 2147483647 for x in re.findall(r"[0-9]+", value)):
        raise UpdateError("Dependency version contains a non-portable numeric component.")
    return int(match.group(1) or "0"), match.group(2).lower(), (match.group(3) or "").lower()


def _component_compare(left, right):
    """Kodi ordering: numeric runs, ASCII non-digits, tilde before release."""
    a, b = 0, 0
    while a < len(left) and b < len(right):
        char_a, char_b = left[a], right[b]
        digit_a, digit_b = char_a.isdigit(), char_b.isdigit()
        if not digit_a or not digit_b:
            if char_a == char_b:
                a += 1; b += 1
                continue
            if char_a == "~": return -1
            if char_b == "~": return 1
            if digit_a != digit_b: return -1 if digit_a else 1
            return -1 if char_a < char_b else 1
        end_a, end_b = a, b
        while end_a < len(left) and left[end_a].isdigit(): end_a += 1
        while end_b < len(right) and right[end_b].isdigit(): end_b += 1
        number_a, number_b = int(left[a:end_a]), int(right[b:end_b])
        if number_a != number_b: return -1 if number_a < number_b else 1
        a, b = end_a, end_b
    if a == len(left) and b == len(right): return 0
    if a < len(left): return -1 if left[a] == "~" else 1
    return 1 if right[b] == "~" else -1


def dependency_compare(left, right):
    """Match Kodi 21 AddonVersion ordering, including +matrix/-revision/~beta.

    Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/addons/AddonVersion.cpp
    This comparator is scoped to dependencies; manifests/packages keep ver().
    """
    a, b = _dependency_parts(left), _dependency_parts(right)
    if a[0] != b[0]: return -1 if a[0] < b[0] else 1
    return _component_compare(a[1], b[1]) or _component_compare(a[2], b[2])


def read_json(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise UpdateError("Duplicate JSON field.")
            result[key] = value
        return result
    try:
        return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=unique)
    except (ValueError, UnicodeError):
        raise UpdateError("Invalid update metadata.") from None


def manifest(raw, paired):
    info = read_json(raw)
    if not isinstance(info, dict) or info.get("repo", REPO) != REPO:
        raise UpdateError("Unexpected update repository.")
    if type(info.get("schema", 1)) is not int:
        raise UpdateError("Invalid manifest schema.")
    if paired:
        if (info.get("schema") != 2 or info.get("kodi_major") != 21
                or info.get("repo") != REPO or info.get("ai_model") is not True):
            raise UpdateError("Test release must include Kodi 21 add-on, skin and AI model.")
        if ver(info.get("minimum_updater", "999")) > ver(VERSION):
            raise UpdateError("This release needs a newer updater ZIP.")
        packages = info.get("packages")
        expected = {PLUGIN, SKIN}
    else:
        if info.get("schema", 1) != 1:
            raise UpdateError("Unexpected legacy manifest schema.")
        packages = [info]
        expected = {PLUGIN}
    if not isinstance(packages, list) or len(packages) != len(expected):
        raise UpdateError("Incomplete release package list.")
    found = set()
    for item in packages:
        if not isinstance(item, dict) or item.get("addon_id") not in expected:
            raise UpdateError("Release contains an unapproved add-on.")
        addon_id = item["addon_id"]
        if addon_id in found:
            raise UpdateError("Duplicate release component.")
        found.add(addon_id)
        version = item.get("version", "")
        if not isinstance(version, str) or not re.fullmatch(r"\d+(?:\.\d+){0,3}", version):
            raise UpdateError("Invalid release version.")
        filename = item.get("filename", "")
        pattern = re.escape(addon_id + "-" + version) + r"(?:-[A-Za-z0-9_-]+)?\.zip"
        if not isinstance(filename, str) or not re.fullmatch(pattern, filename):
            raise UpdateError("Unsafe or mismatched package filename.")
        digest = item.get("sha256", "")
        if not isinstance(digest, str) or not re.fullmatch(r"[a-fA-F0-9]{64}", digest):
            raise UpdateError("Invalid package checksum.")
        size = item.get("size")
        if type(size) is not int or not 0 < size <= MAX_PACKAGE:
            raise UpdateError("Invalid package size.")
    return sorted(packages, key=lambda x: x["addon_id"] != PLUGIN)


def verify_bytes(raw, item):
    if len(raw) != item["size"]:
        raise UpdateError("Package size mismatch; nothing installed.")
    if hashlib.sha256(raw).hexdigest() != item["sha256"].lower():
        raise UpdateError("Package SHA-256 mismatch; nothing installed.")


def _safe_member(entry, addon_id):
    # ZipInfo normalises backslashes on Windows and truncates NULs. Validate
    # the original archive name, not its potentially sanitised interpretation.
    name = entry.orig_filename
    parts = name.rstrip("/").split("/")
    bad = {"userdata", "addon_data", "__pycache__", ".git", ".svn"}
    if (not parts or parts[0] != addon_id or "\\" in name
            or any(not x or x in (".", "..") or ":" in x or any(ord(c) < 32 for c in x)
                   or x.endswith((" ", ".")) or x.lower() in bad for x in parts)
            or any(x.lower().startswith("skin.") or x.lower() == "script.skinshortcuts" for x in parts[1:])
            or any(re.fullmatch(r"(?i)(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?", x) for x in parts)
            or entry.flag_bits & 1):
        raise UpdateError("Unsafe package path or encrypted ZIP.")
    mode = entry.external_attr >> 16
    kind = stat.S_IFMT(mode)
    if kind not in (0, stat.S_IFDIR, stat.S_IFREG):
        raise UpdateError("Package contains a link or special file.")
    if name.lower().endswith((".pyc", ".pyo", ".db", ".sqlite", ".log", ".dat")):
        raise UpdateError("Package contains runtime or compiled data.")
    if len(parts) == 1 and not entry.is_dir():
        raise UpdateError("Package root must be a directory.")
    return name.rstrip("/").casefold()


def validate_ai(read):
    config = read_json(read(MODEL + "config.json"))
    if (not isinstance(config, dict) or config.get("format") != "leanstream-static-embeddings-v1"
            or config.get("source_model") != "potion-base-4M" or config.get("dtype") != "int8"
            or type(config.get("rows")) is not int or type(config.get("dimensions")) is not int
            or not 0 < config["rows"] <= 100000 or not 0 < config["dimensions"] <= 4096):
        raise UpdateError("Bundled AI configuration is invalid.")
    if not isinstance(config.get("files"), dict):
        raise UpdateError("Bundled AI file metadata is invalid.")
    for filename in ("vocab.json", "embeddings.i8"):
        raw = read(MODEL + filename)
        metadata = config.get("files", {}).get(filename, {})
        if (not isinstance(metadata, dict) or metadata.get("bytes") != len(raw)
                or metadata.get("sha256") != hashlib.sha256(raw).hexdigest()):
            raise UpdateError("Bundled AI model checksum or size mismatch.")
    vocab = read_json(read(MODEL + "vocab.json"))
    if (not isinstance(vocab, list) or len(vocab) != config["rows"]
            or any(not isinstance(x, str) for x in vocab) or len(set(vocab)) != len(vocab)
            or len(read(MODEL + "embeddings.i8")) != config["rows"] * config["dimensions"]):
        raise UpdateError("Bundled AI vocabulary or matrix shape is invalid.")
    read(MODEL + "LICENSE.txt")
    for filename in AI_CODE:
        read(filename)
    return "Potion 4M int8: verified model and AI engine files"


def requirement(item):
    """Preserve every min/version/source constraint, including suite-only roots."""
    if isinstance(item, Requirement):
        result = item
    elif isinstance(item, (tuple, list)) and len(item) == 3:
        result = Requirement(item[0], item[1], item[2], item[1], "suite")
    else:
        raise UpdateError("Invalid dependency declaration shape.")
    if (not isinstance(result.id, str) or not 0 < len(result.id) <= 128
            or not re.fullmatch(r"[a-zA-Z0-9_.-]+", result.id)
            or type(result.required) is not bool):
        raise UpdateError("Invalid dependency identity or optional flag.")
    if not isinstance(result.source, str) or not re.fullmatch(r"[a-zA-Z0-9_.-]{1,128}", result.source):
        raise UpdateError("Invalid dependency provenance.")
    return result


def declared_requirements(raw):
    if len(raw) > MAX_DEPENDENCY_XML:
        raise UpdateError("Dependency XML exceeds the safe size limit.")
    root = ET.fromstring(raw)
    if root.tag != "addon":
        raise UpdateError("Dependency metadata is not an add-on.")
    imports = root.findall("requires/import")
    if len(imports) > MAX_DEPENDENCY_IDS:
        raise UpdateError("Too many imports in dependency metadata.")
    result = []
    for child in imports:
        version = child.get("version") or "0.0.0"
        minimum = child.get("minversion")
        # Kodi DependencyInfo uses version when minversion is empty(), which
        # includes absent/empty and the canonical 0.0.0 (possibly zero epoch).
        try:
            empty_minimum = minimum in (None, "") or _dependency_parts(minimum) == (0, "0.0.0", "")
        except UpdateError:
            empty_minimum = False  # Keep malformed data visible and blocking.
        if empty_minimum:
            minimum = version
        optional = child.get("optional", "false").lower()
        if optional not in ("false", "true", "0", "1"):
            raise UpdateError("Unreadable dependency optional flag.")
        result.append(requirement(Requirement(child.get("addon", ""), minimum,
            optional not in ("true", "1"), version, root.get("id") or "unknown")))
    return result


def addon_abi(root):
    """Kodi's provided compatibility floor, not the requested compile version."""
    version = root.get("version", "")
    _dependency_parts(version)
    entries = root.findall("backwards-compatibility")
    if len(entries) > 1:
        raise UpdateError("Duplicate compatibility metadata.")
    abi = (entries[0].get("abi") or "0.0.0") if entries else "0.0.0"
    if dependency_compare(abi, version) > 0:
        raise UpdateError("Provided compatibility floor exceeds its version.")
    return abi


def package_abi(path, item):
    with zipfile.ZipFile(path) as archive:
        raw = archive.read(item["addon_id"] + "/addon.xml")
        if len(raw) > MAX_DEPENDENCY_XML:
            raise UpdateError("Package dependency metadata exceeds safe size.")
        root = ET.fromstring(raw)
        if root.get("id") != item["addon_id"] or root.get("version") != item["version"]:
            raise UpdateError("Planned compatibility metadata identity mismatch.")
        return addon_abi(root)


def validate_package(path, item, require_ai=False):
    addon_id = item["addon_id"]
    if addon_id not in (PLUGIN, SKIN):
        raise UpdateError("Unapproved package target.")
    try:
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            if len(entries) > 10000 or sum(x.file_size for x in entries) > MAX_EXPANDED:
                raise UpdateError("Package is too large after extraction.")
            seen = set()
            for entry in entries:
                name = _safe_member(entry, addon_id)
                if name in seen:
                    raise UpdateError("Package has duplicate or case-colliding paths.")
                seen.add(name)
            if archive.testzip():
                raise UpdateError("Corrupt ZIP; nothing installed.")
            root = ET.fromstring(archive.read(addon_id + "/addon.xml"))
            if root.get("id") != addon_id or root.get("version") != item["version"]:
                raise UpdateError("Package identity/version mismatch.")
            extension = "xbmc.gui.skin" if addon_id == SKIN else "xbmc.python.pluginsource"
            if not any(x.get("point") == extension for x in root.findall("extension")):
                raise UpdateError("Wrong add-on extension type.")
            if require_ai and addon_id == PLUGIN:
                validate_ai(lambda name: archive.read(addon_id + "/" + name))
            return declared_requirements(archive.read(addon_id + "/addon.xml"))
    except (zipfile.BadZipFile, KeyError, ET.ParseError, OSError):
        raise UpdateError("Unreadable or incomplete package; nothing installed.") from None


def requirement_report(requirements, lookup, planned=None, planned_abis=None):
    """Kodi MeetsVersion: min<=provided version AND request>=provided ABI.

    Each declaration is retained; merging a highest minimum alone loses ABI
    constraints. Lookup must supply (version, enabled, compatibility floor).
    Unknown metadata never silently becomes ABI zero. No installation or accounts.
    """
    merged = {}
    count = 0
    for raw in requirements:
        item = requirement(raw)
        count += 1
        if count > MAX_DEPENDENCY_EDGES:
            raise UpdateError("Too many dependency declarations.")
        merged.setdefault(item.id, []).append(item)
        if len(merged) > MAX_DEPENDENCY_IDS:
            raise UpdateError("Too many dependency identities.")
    rows = []
    for addon_id, constraints in sorted(merged.items()):
        required = any(x.required for x in constraints)
        minimum, requested, invalid = constraints[0].minimum, constraints[0].version, False
        for item in constraints:
            try:
                _dependency_parts(item.minimum); _dependency_parts(item.version)
                if not invalid:
                    if dependency_compare(item.minimum, minimum) > 0: minimum = item.minimum
                    if dependency_compare(item.version, requested) < 0: requested = item.version
            except UpdateError:
                if not invalid: minimum, requested = item.minimum, item.version
                invalid = True
        if planned and addon_id in planned:
            installed, enabled = planned[addon_id], True
            abi = (planned_abis or {}).get(addon_id)
            origin = "in this release"
        else:
            result = lookup(addon_id)
            installed, enabled, abi = None, False, None
            if result:
                if isinstance(result, (tuple, list)) and len(result) in (2, 3):
                    installed, enabled = result[:2]
                    if len(result) == 3: abi = result[2]
                else:
                    raise UpdateError("Unexpected dependency lookup metadata.")
            origin = "installed"
        status = "OK"
        if invalid:
            status = "UNKNOWN REQUIREMENT VERSION"
        elif installed is None:
            status = "MISSING"
        else:
            try:
                _dependency_parts(installed)
            except UpdateError:
                status = "UNKNOWN VERSION"
            if status == "OK":
                try:
                    _dependency_parts(abi)
                    if dependency_compare(abi, installed) > 0:
                        raise UpdateError("Invalid installed ABI range.")
                except UpdateError:
                    status = "UNKNOWN COMPATIBILITY METADATA"
            if status == "OK":
                if any(dependency_compare(x.minimum, installed) > 0 for x in constraints):
                    status = "TOO OLD"
                elif any(dependency_compare(x.version, abi) < 0 for x in constraints):
                    status = "INCOMPATIBLE ABI"
                elif type(enabled) is not bool:
                    status = "UNKNOWN ENABLED STATE"
                elif not enabled:
                    status = "DISABLED"
        rows.append({"id": addon_id, "minimum": minimum, "requested": requested,
            "version": installed, "abi": abi, "required": required, "status": status,
            "origin": origin, "constraints": [x._asdict() for x in constraints],
            "sources": sorted({x.source for x in constraints})})
    return rows


def is_link(path):
    """Reject Android symlinks and Windows junction/reparse-point targets."""
    if os.path.islink(path):
        return True
    try:
        return bool(getattr(os.lstat(path), "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    except FileNotFoundError:
        return False


def tree_digest(folder):
    digest = hashlib.sha256()
    if not os.path.isdir(folder) or is_link(folder):
        raise UpdateError("Code folder missing or linked.")
    for root, dirs, files in os.walk(folder):
        dirs[:] = sorted(x for x in dirs if x != "__pycache__")
        if any(is_link(os.path.join(root, x)) for x in dirs):
            raise UpdateError("Code folder contains a link.")
        for name in sorted(files):
            if name.endswith((".pyc", ".pyo")):
                continue
            path = os.path.join(root, name)
            if is_link(path):
                raise UpdateError("Code folder contains a link.")
            relative = os.path.relpath(path, folder).replace(os.sep, "/").encode("utf-8")
            digest.update(relative + b"\x00")
            file_hash = hashlib.sha256()
            with open(path, "rb") as stream:
                for chunk in iter(lambda: stream.read(65536), b""):
                    file_hash.update(chunk)
            digest.update(file_hash.digest())
    return digest.hexdigest()


def _write_json(path, info):
    with open(path + ".tmp", "w", encoding="utf-8") as stream:
        json.dump(info, stream, sort_keys=True)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(path + ".tmp", path)


def _target(root, addon_id):
    if addon_id not in (PLUGIN, SKIN):
        raise UpdateError("Unapproved installation target.")
    root = os.path.abspath(root)
    target = os.path.join(root, addon_id)
    if is_link(root) or is_link(target) or (os.path.exists(target) and not os.path.isdir(target)):
        raise UpdateError("Installation target is linked or not a directory.")
    return target


@contextlib.contextmanager
def update_lock(data):
    os.makedirs(data, exist_ok=True)
    with open(os.path.join(data, "update.lock"), "a+b") as stream:
        stream.seek(0, os.SEEK_END)
        if not stream.tell():
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise UpdateError("Another updater operation is still running.") from None
        try:
            yield
        finally:
            if os.name == "nt":
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def last_backup(data):
    path = os.path.join(data, "last-backup.json")
    if not os.path.isfile(path):
        return None
    with open(path, "rb") as stream:
        info = read_json(stream.read(65537))
    if (not isinstance(info, dict) or not re.fullmatch(r"[a-f0-9]{32}", info.get("transaction", ""))
            or not isinstance(info.get("components"), list) or not 1 <= len(info["components"]) <= 2):
        raise UpdateError("Invalid backup record.")
    ids = []
    for item in info["components"]:
        if (not isinstance(item, dict) or item.get("id") not in (PLUGIN, SKIN)
                or type(item.get("existed")) is not bool
                or not re.fullmatch(r"[a-f0-9]{64}", item.get("digest", ""))):
            raise UpdateError("Invalid backup component.")
        ids.append(item["id"])
    if len(set(ids)) != len(ids):
        raise UpdateError("Duplicate backup target.")
    return info


def _replace_all(addon_root, payload, items, stage):
    """Atomic directory renames, with an in-process rollback on any failed move."""
    moved = []
    previous = os.path.join(stage, "previous")
    os.mkdir(previous)
    try:
        for item in items:
            addon_id = item["id"]
            target = _target(addon_root, addon_id)
            old = os.path.join(previous, addon_id)
            moved.append((target, old, os.path.exists(target)))
            if os.path.exists(target):
                os.rename(target, old)
            if item["existed"]:
                os.rename(os.path.join(payload, addon_id), target)
    except Exception:
        failed = False
        for target, old, existed in reversed(moved):
            try:
                if os.path.isdir(old):
                    if os.path.isdir(target):
                        shutil.rmtree(target)
                    os.rename(old, target)
                elif not existed and os.path.isdir(target):
                    shutil.rmtree(target)
            except OSError:
                failed = True
        if failed:
            raise UpdateError("Update interrupted; restore the saved backup before using LeanStream.") from None
        raise UpdateError("Update failed; original add-on and skin files restored.") from None


def install(addon_root, data, packages, paths, paired=False):
    """No userdata copying; never changes active skin, settings, or authorizations."""
    for item in packages:
        validate_package(paths[item["addon_id"]], item, require_ai=paired)
        with open(paths[item["addon_id"]], "rb") as stream:
            verify_bytes(stream.read(MAX_PACKAGE + 1), item)
    os.makedirs(addon_root, exist_ok=True)
    with update_lock(data):
        previous_record = last_backup(data)
        if previous_record and previous_record.get("state") == "pending":
            raise UpdateError("An interrupted update needs backup restoration first.")
        stage = tempfile.mkdtemp(prefix=".leanstream-updater-", dir=addon_root)
        payload = os.path.join(stage, "payload")
        os.mkdir(payload)
        transaction = uuid.uuid4().hex
        backup = os.path.join(data, "backups", transaction)
        items = []
        try:
            for item in packages:
                addon_id = item["addon_id"]
                target = _target(addon_root, addon_id)
                if os.path.isdir(target):
                    old_xml = ET.parse(os.path.join(target, "addon.xml")).getroot()
                    if old_xml.get("id") != addon_id or ver(old_xml.get("version", "")) > ver(item["version"]):
                        raise UpdateError("Update would downgrade or overwrite an unexpected add-on.")
                with zipfile.ZipFile(paths[addon_id]) as archive:
                    archive.extractall(payload)
                if os.path.isdir(target) and ver(old_xml.get("version")) == ver(item["version"]):
                    if tree_digest(target) != tree_digest(os.path.join(payload, addon_id)):
                        raise UpdateError("Same-version package has different files; publish a new version.")
                existed = os.path.isdir(target)
                digest = tree_digest(target) if existed else hashlib.sha256(b"").hexdigest()
                if existed:
                    saved = os.path.join(backup, addon_id)
                    shutil.copytree(target, saved)
                    if tree_digest(saved) != digest:
                        raise UpdateError("Backup verification failed; nothing installed.")
                items.append({"id": addon_id, "existed": existed, "digest": digest})
            record = {"transaction": transaction, "components": items, "state": "pending"}
            _write_json(os.path.join(data, "last-backup.json"), record)
            _replace_all(addon_root, payload,
                         [{"id": x["addon_id"], "existed": True} for x in packages], stage)
            record["state"] = "complete"
            _write_json(os.path.join(data, "last-backup.json"), record)
            return record
        finally:
            # Original copies also remain in verified backups. On a failed rollback
            # preserve 'previous' for manual recovery instead of recursively deleting it.
            record = last_backup(data)
            if not record or record.get("state") != "pending":
                shutil.rmtree(stage)


def restore(addon_root, data):
    with update_lock(data):
        record = last_backup(data)
        if not record:
            raise UpdateError("No updater 1.1 backup is available.")
        backup = os.path.join(data, "backups", record["transaction"])
        stage = tempfile.mkdtemp(prefix=".leanstream-restore-", dir=addon_root)
        payload = os.path.join(stage, "payload")
        os.mkdir(payload)
        try:
            for item in record["components"]:
                _target(addon_root, item["id"])
                if item["existed"]:
                    source = os.path.join(backup, item["id"])
                    if tree_digest(source) != item["digest"]:
                        raise UpdateError("Saved backup is incomplete or changed; nothing restored.")
                    shutil.copytree(source, os.path.join(payload, item["id"]))
                    if tree_digest(os.path.join(payload, item["id"])) != item["digest"]:
                        raise UpdateError("Restoration staging verification failed; nothing restored.")
            record["state"] = "pending"
            _write_json(os.path.join(data, "last-backup.json"), record)
            _replace_all(addon_root, payload, record["components"], stage)
            record["state"] = "restored"
            _write_json(os.path.join(data, "last-backup.json"), record)
        finally:
            if last_backup(data).get("state") == "restored":
                shutil.rmtree(stage)
