"""Manual read-only GitHub diagnostic. Never returns raw secrets or exceptions."""
import datetime
import json
import re
import urllib.error
import urllib.request

from resources.lib import bundle

ORIGIN = "https://api.github.com"
REPOSITORY = "/repos/" + bundle.REPO
ENDPOINTS = (("Account", "/user"), ("Repository", REPOSITORY),
             ("Shield test feed", REPOSITORY + "/contents/updates/shield-test/latest.json?ref=main"))
MAX_BODY = 65536
MAX_ERROR = 4096
TIMEOUT = 8


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward the authorization header to another URL.


class Cancelled(Exception):
    pass


def _integer(value, maximum):
    if isinstance(value, str) and re.fullmatch(r"[0-9]{1,10}", value):
        number = int(value)
        if number <= maximum:
            return number
    return None


def safe_headers(headers):
    """Only typed/allowlisted values, never an arbitrary upstream header."""
    headers = headers or {}
    result = {}
    expiry = headers.get("GitHub-Authentication-Token-Expiration", "")
    if isinstance(expiry, str) and re.fullmatch(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d UTC", expiry):
        try:
            parsed = datetime.datetime.strptime(expiry, "%Y-%m-%d %H:%M:%S UTC")
            result["expiry"] = parsed.strftime("%Y-%m-%d %H:%M:%S UTC")
        except ValueError:
            pass
    for key, name, maximum in (("X-RateLimit-Remaining", "remaining", 1000000),
                               ("X-RateLimit-Reset", "reset", 4102444800),
                               ("Retry-After", "retry", 604800)):
        number = _integer(headers.get(key), maximum)
        if number is not None:
            result[name] = number
    permission = headers.get("X-Accepted-GitHub-Permissions", "")
    if permission in ("contents=read", "metadata=read"):
        result["endpoint_requirement"] = permission
    return result


def http_failure(error):
    result = dict(status=error.code, kind="http", **safe_headers(error.headers))
    message = ""
    try:
        raw = error.read(MAX_ERROR + 1)
        if len(raw) <= MAX_ERROR:
            payload = json.loads(raw)
            if isinstance(payload, dict) and isinstance(payload.get("message"), str):
                message = payload["message"].lower()
    except Exception:
        pass  # Raw bodies, headers and exception strings are never displayed/logged.
    finally:
        error.close()
    if error.code == 401:
        result["kind"] = "credentials"
    elif error.code == 429 or (error.code == 403 and
            (result.get("remaining") == 0 or "rate limit" in message or "retry" in result)):
        result["kind"] = "rate"
    elif error.code == 403:
        result["kind"] = "permissions" if "resource not accessible" in message else "forbidden"
    elif error.code == 404:
        result["kind"] = "invisible"
    elif error.code in (301, 302, 303, 307, 308):
        result["kind"] = "redirect"
    elif 500 <= error.code < 600:
        result["kind"] = "server"
    return result


def describe(row):
    messages = {
        "ok": "OK", "credentials": "saved token rejected (incorrect, expired or revoked)",
        "rate": "rate-limited; stop retrying for now", "permissions": "insufficient token permissions",
        "forbidden": "access forbidden (permissions or GitHub policy; exact cause unconfirmed)",
        "invisible": "not found or not visible to this token",
        "redirect": "redirect blocked; token was not forwarded",
        "server": "GitHub service error; retry later", "http": "GitHub request rejected",
        "network": "network, TLS or timeout failure; authentication could not be confirmed",
        "payload": "unexpected or oversized response; access not confirmed",
    }
    prefix = "HTTP {} - ".format(row["status"]) if isinstance(row.get("status"), int) else ""
    text = prefix + messages.get(row["kind"], "check stopped safely")
    if row["kind"] == "rate":
        if "retry" in row:
            text += "; wait at least {} seconds".format(row["retry"])
        if row.get("remaining") == 0 and "reset" in row:
            stamp = datetime.datetime.fromtimestamp(row["reset"], datetime.timezone.utc)
            text += "; quota resets " + stamp.strftime("%Y-%m-%d %H:%M:%S UTC")
        if "retry" not in row and not (row.get("remaining") == 0 and "reset" in row):
            text += "; wait at least one minute before a manual retry"
    return text


def _read(stream, limit, cancelled):
    chunks, size = [], 0
    while size <= limit:
        if cancelled():
            raise Cancelled()
        chunk = stream.read(min(8192, limit + 1 - size))
        if not chunk:
            return b"".join(chunks)
        chunks.append(chunk)
        size += len(chunk)
    return None


def check(token, opener=None, cancelled=lambda: False, progress=lambda index, label: None):
    report = {"rows": [], "outcome": "stopped"}
    token = token.strip() if isinstance(token, str) else ""
    if not token:
        report["outcome"] = "missing"
        return report
    if not re.fullmatch(r"[A-Za-z0-9_]{20,512}", token):
        report["outcome"] = "format"
        return report
    opener = opener or urllib.request.build_opener(NoRedirect())
    for index, (label, path) in enumerate(ENDPOINTS):
        if cancelled():
            report["outcome"] = "cancelled"
            return report
        progress(index, label)
        request = urllib.request.Request(ORIGIN + path, method="GET", headers={
            "Accept": "application/vnd.github.raw+json" if index == 2 else "application/vnd.github+json",
            "Authorization": "Bearer " + token,
            "User-Agent": "LeanStream-Shield-Updater/" + bundle.VERSION,
            "X-GitHub-Api-Version": "2026-03-10",
        })
        row = {"label": label, "kind": "payload"}
        try:
            with opener.open(request, timeout=TIMEOUT) as response:
                row.update(status=response.getcode(), **safe_headers(response.headers))
                raw = _read(response, MAX_BODY, cancelled)
                if raw is not None and row["status"] == 200:
                    payload = json.loads(raw)
                    if index == 0 and isinstance(payload, dict):
                        login = payload.get("login")
                        if isinstance(login, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9-]{0,38}", login):
                            row.update(kind="ok", login=login)
                    elif index == 1 and isinstance(payload, dict):
                        if payload.get("full_name") == bundle.REPO and payload.get("private") is True:
                            row["kind"] = "ok"
                    elif index == 2:
                        bundle.manifest(raw, paired=True)
                        row["kind"] = "ok"
        except urllib.error.HTTPError as error:
            row.update(http_failure(error))
        except Cancelled:
            report["outcome"] = "cancelled"
            return report
        except (urllib.error.URLError, TimeoutError, OSError):
            row["kind"] = "network"
        except Exception:
            pass  # Invalid JSON/manifest/unexpected exception: safe payload failure.
        report["rows"].append(row)
        if row["kind"] != "ok":
            return report  # No automatic retry or further credential requests after failure.
    report["outcome"] = "ok"
    return report


def render(report):
    lines = ["Updater " + bundle.VERSION, "Target repository: " + bundle.REPO, ""]
    outcome = report["outcome"]
    if outcome == "missing":
        lines.append("No saved GitHub token is configured. Nothing changed.")
    elif outcome == "format":
        lines.append("Saved token format is invalid (spaces/control characters or unsupported format). "
                     "Check it privately in Updater settings; do not send its value.")
    elif outcome == "cancelled":
        lines.append("Cancelled. Nothing changed.")
    for row in report["rows"]:
        lines.append(row["label"] + ": " + describe(row))
        if "login" in row:
            lines.append("  Authenticated GitHub account: " + row["login"])
        if "expiry" in row:
            lines.append("  Token expiry reported by GitHub: " + row["expiry"])
        if "remaining" in row:
            lines.append("  API requests remaining: " + str(row["remaining"]))
        if "endpoint_requirement" in row:
            lines.append("  Endpoint requires: " + row["endpoint_requirement"])
    if not any("expiry" in row for row in report["rows"]):
        lines.append("Token expiry: not reported by GitHub (not proof of expiry or validity).")
    if outcome == "ok":
        lines.append("\nPASS: this device's saved token can read the private suite feed. "
                     "Package download and installation were not tested.")
    elif outcome == "stopped":
        lines.append("\nStopped at the first failed check; later checks were not attempted.")
    lines.append("\nEndpoint requirements are not a complete list of the token's privileges. "
                 "Use GitHub token settings to review repository selection and full permissions.")
    lines.append("Read-only: at most three GitHub GETs. No token value, raw response or private URL is "
                 "shown or logged. No installs, settings, credentials, accounts or access permissions changed. "
                 "You may send a screenshot of this report; never send the token itself.")
    return "\n".join(lines)
