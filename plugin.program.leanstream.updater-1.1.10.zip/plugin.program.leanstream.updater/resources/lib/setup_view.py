"""Compact native checklist; technical detail and opt-in private LAN export."""
import os
import tempfile
import threading
import uuid
from resources.lib import report_share


def save_report(ui, text):
    folder = ui.DIALOG.browseSingle(3, 'Save sanitized setup report in folder', 'files')
    if not folder:
        return False
    # Unique basename: never overwrite another file, settings or existing log.
    name = 'LeanStream-setup-' + uuid.uuid4().hex + '.txt'
    path = folder.rstrip('/\\') + '/' + name
    try:
        if ui.xbmcvfs.exists(path):
            raise OSError('Destination exists')
        target = ui.xbmcvfs.File(path, 'w')
        try:
            if not target.write(text):
                raise OSError('Write failed')
        finally:
            target.close()
    except Exception:
        ui.DIALOG.ok('Report not saved', 'Could not save the report in that folder. Choose another folder. No account values are included.')
        return False
    ui.DIALOG.ok('Report saved', 'Saved ' + name + ' in your selected folder. You can share this sanitized text file with support.')
    return True


def show(ui, snapshot):
    import xbmcgui
    import xbmc
    # A suite route can be activated again while its first report is still open.
    # Keep one report owner across Kodi Python invokers; transient UI state only.
    home = xbmcgui.Window(10000)
    property_name = 'LeanStream.SetupReport.Owner'
    if home.getProperty(property_name):
        return
    owner = uuid.uuid4().hex
    home.setProperty(property_name, owner)

    class Dashboard(xbmcgui.WindowXMLDialog):
        def onInit(self):
            for index, (ok, title, detail) in enumerate(snapshot['summary']):
                self.getControl(100 + index).setLabel(title)
                self.getControl(120 + index).setVisible(ok)
                self.getControl(110 + index).setLabel(detail)
            if not getattr(self, 'initialized', False):
                self.setFocusId(201)
                self.initialized = True

        def onAction(self, action):
            if action.getId() in (9, 10, 92): self.close()

        def onClick(self, control):
            if control == 204: self.close()
            elif control == 202:
                ui.DIALOG.textviewer('Technical details - sanitized full report', snapshot['full'])
            elif control == 203:
                save_report(ui, snapshot['full'])
            elif control == 201:
                self.share()

        def share(self):
            share, image_path, directory = None, None, None
            try:
                ip = xbmc.getIPAddress()
                if not report_share.private_ip(ip):
                    ui.DIALOG.ok('Wi-Fi download unavailable', 'Kodi needs a private local IPv4 address. Connect your phone to the same Wi-Fi, or use Save report. No network settings were changed.')
                    return
                share = report_share.Share(ip, snapshot['full'])
                directory = tempfile.mkdtemp(prefix='leanstream-report-', dir=ui.xbmcvfs.translatePath('special://temp/'))
                image_path = os.path.join(directory, 'qr.png')
                with open(image_path, 'xb') as stream:
                    stream.write(report_share.qr_png(share.url))
                class Phone(xbmcgui.WindowXMLDialog):
                    def onInit(self):
                        self.getControl(300).setImage(image_path)
                        self.setFocusId(301)
                        self.timer = threading.Thread(target=self.expire, daemon=True)
                        self.timer.start()
                    def expire(self):
                        monitor = xbmc.Monitor()
                        while share.active and not monitor.waitForAbort(0.5):
                            pass
                        self.close()
                    def onClick(self, control):
                        if control == 301: self.close()
                    def onAction(self, action):
                        if action.getId() in (9, 10, 92): self.close()
                phone = Phone('LeanStreamReportPhone.xml', ui.SELF.getAddonInfo('path'), 'Default', '1080i')
                phone.doModal()
                del phone
            except Exception:
                ui.DIALOG.ok('Wi-Fi download unavailable', 'The temporary download could not start. Use Save report instead. No firewall, account or network settings were changed.')
            finally:
                if share: share.close()
                if image_path and os.path.isfile(image_path): os.remove(image_path)
                if directory and os.path.isdir(directory): os.rmdir(directory)

    try:
        view = Dashboard('LeanStreamSetup.xml', ui.SELF.getAddonInfo('path'), 'Default', '1080i')
        view.doModal()
        del view
    finally:
        if home.getProperty(property_name) == owner:
            home.clearProperty(property_name)
