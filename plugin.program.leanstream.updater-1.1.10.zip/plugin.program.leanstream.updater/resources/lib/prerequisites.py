"""Kodi core metadata and narrowly scoped suite prerequisite planning.

No platform binaries, downloads, account settings or installation code here.
Native actions are performed only by the approved paired installer in updater.py.
"""
import re
import xml.etree.ElementTree as ET

from resources.lib import bundle

MAX_XML = 1024 * 1024
MAX_ACTIONS = 32


def core_id(addon_id):
    return bool(re.fullmatch(r"(?:xbmc\.[a-z0-9_.-]+|kodi\.binary\.[a-z0-9_.-]+|kodi\.resource)", addon_id))


def core_metadata(addon_id, read):
    """Read only Kodi's application-owned VFS metadata, never profile overrides."""
    if not core_id(addon_id):
        return None
    try:
        raw = read("special://xbmc/addons/" + addon_id + "/addon.xml", MAX_XML + 1)
        if len(raw) > MAX_XML:
            return None
        root = ET.fromstring(raw)
        if root.tag != "addon" or root.get("id") != addon_id:
            return None
        bundle.dependency_compare(root.get("version", ""), "0")
        return root
    except (OSError, RuntimeError, ET.ParseError, bundle.UpdateError, TypeError, ValueError):
        return None


def mark_core(rows):
    for row in rows:
        if core_id(row["id"]):
            row["origin"] = "Kodi built-in metadata"
            if row["status"] == "MISSING":
                row["status"] = "KODI CORE UNVERIFIED"
    return rows


def installable_id(addon_id):
    # Never install/enable a skin, repository, service, private suite or updater
    # as a prerequisite. Only the suite's declared modules and two trailer roots.
    return bool(re.fullmatch(r"script\.module\.[a-z0-9_.-]+", addon_id)) or addon_id in (
        "plugin.video.youtube", "inputstream.adaptive")


def plan(rows, available, attempted=(), planned=None):
    """Return native actions and hard blockers; optional unavailable items skip.

    InstallAddon in Kodi 21 does NOT update an already installed old version.
    Never silently claim it does, uninstall it, or trigger global add-on updates.
    """
    actions, blocked = [], []
    for row in rows:
        if row["status"] == "OK":
            continue
        allowed = installable_id(row["id"]) and not (planned and row["id"] in planned)
        can_act = allowed and row["status"] in ("MISSING", "DISABLED") and row["id"] not in attempted
        if row["required"]:
            if can_act:
                actions.append(row)
            else:
                blocked.append(row)
        elif can_act and (row["status"] == "DISABLED" or row["id"] in available):
            actions.append(row)
    return actions, blocked
