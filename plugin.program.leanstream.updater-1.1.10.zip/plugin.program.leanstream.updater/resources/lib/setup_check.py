"""Manual configuration inventory. No network, setters, logins, sync or install.

Credential values stay in Kodi memory for presence tests only. The report has no
values, usernames, hashes, fragments, URLs with tokens, or exception details.
Presence is explicitly NOT live validation of credentials, quota or playback.
"""
import os
import stat
from resources.lib import bundle

SERVICES = (
    ('MDBList', 'mdblist.enabled', 'mdblist.apikey', 'ratings/watch lists'),
    ('Trakt', 'trakt.enabled', 'trakt.auth', 'optional watch/history'),
    ('Simkl', 'simkl.enabled', 'simkl.auth', 'optional watch/history'),
    ('TorBox', 'torbox.enabled', 'torbox.token', 'playback'),
    ('Premiumize', 'premiumize.enabled', 'premiumize.token', 'playback'),
    ('Debrid-Link', 'debridlink.enabled', 'debridlink.token', 'playback'),
    ('Offcloud', 'offcloud.enabled', 'offcloud.apikey', 'playback'),
    ('Real-Debrid', None, 'rd.auth', 'legacy playback'),
    ('AllDebrid', None, 'alldebrid.apikey', 'legacy playback'),
)


def _presence(addon, name):
    try:
        value = addon.getSettingString(name)
        result = bool(value.strip()) if isinstance(value, str) else None
        value = None
        return result
    except Exception:
        return None


def _enabled(addon, name):
    if name is None: return None
    try:
        value = addon.getSettingBool(name)
        return value if type(value) is bool else None
    except Exception:
        return None


def _provider_packages(ui):
    # Inspect directory-entry presence only, never read provider files/databases.
    parent = os.path.dirname(os.path.abspath(ui.DATA))
    if os.path.basename(os.path.abspath(ui.DATA)) != bundle.SELF_ID or bundle.is_link(parent):
        return 'UNKNOWN (profile location not verified)'
    path = os.path.join(parent, bundle.PLUGIN, 'providerMeta')
    if bundle.is_link(path) or bundle.is_link(os.path.dirname(path)):
        return 'UNKNOWN (linked provider metadata)'
    if not os.path.isdir(path): return 'No installed package metadata found; check LeanStream provider setup'
    try:
        with os.scandir(path) as entries:
            packages = set()
            for index, entry in enumerate(entries):
                if index >= 256:
                    return 'Metadata scan limit reached; check LeanStream provider setup'
                if entry.is_file(follow_symlinks=False) and entry.name.lower().endswith('.json'):
                    packages.add(entry.name[:-5])  # Legacy flat metadata.
                elif entry.is_dir(follow_symlinks=False):
                    # Current installer uses providerMeta/<package>/meta.json.
                    # Stat the fixed filename only; never read metadata contents.
                    meta = os.path.join(entry.path, 'meta.json')
                    try:
                        if stat.S_ISREG(os.stat(meta, follow_symlinks=False).st_mode):
                            packages.add(entry.name)
                    except FileNotFoundError:
                        pass
        return '{} package metadata record(s); enablement/function NOT tested'.format(len(packages))
    except OSError:
        return 'UNKNOWN (provider metadata not readable)'


def collect(ui):
    # Include roots explicitly: absent suite XML is not an empty, healthy suite.
    requirements = [(bundle.PLUGIN, '1.0.23.21', True), (bundle.SKIN, '0.3.1', True)]
    requirements += ui.dependency_xml(bundle.PLUGIN) + ui.dependency_xml(bundle.SKIN) + list(bundle.TRAILER_REQUIREMENTS)
    rows = ui.requirement_rows(requirements)
    required = [x for x in rows if x['required'] and x['status'] != 'OK']
    services = {}
    result = ['LeanStream setup check - READ ONLY', 'Updater: ' + bundle.VERSION,
              'Installed components and account CONFIGURATION only; no live service/credential/playback test.',
              '', 'Required add-ons/interfaces needing attention: {}'.format(len(required))]
    if required:
        result.extend('{}: {}'.format(x['id'], x['status']) for x in required)
        result.append('The suite installer can request supported missing add-ons from Kodi repositories. '
                      'Built-in Kodi interfaces are part of Kodi itself, not separate downloads. '
                      'Old/unknown versions need review; do not copy Windows binaries to Android.')
    else:
        result.append('Required dependency metadata is compatible. This is NOT a playback test.')
    result += ['', 'Online service configuration (NOT add-ons to install):',
               'MDBList key: needed for extra rating sources. Watch/history services are optional.',
               'Playback services are alternatives: you do NOT need an account with every provider.']
    registered = ui.lookup(bundle.PLUGIN)
    if not registered:
        result.append('LeanStream is not installed/registered; service configuration could not be inspected.')
    else:
        try:
            addon = ui.xbmcaddon.Addon(bundle.PLUGIN)
        except Exception:
            addon = None
        if addon is None:
            result.append('Service configuration UNKNOWN; restart Kodi and retry.')
        else:
            for name, enabled_key, credential_key, purpose in SERVICES:
                present, enabled = _presence(addon, credential_key), _enabled(addon, enabled_key)
                services[name] = (present, enabled)
                presence = 'CONFIGURED - credential present, NOT verified' if present is True else (
                    'NOT CONFIGURED' if present is False else 'UNKNOWN - could not inspect')
                toggle = ('; enabled' if enabled is True else '; turned off' if enabled is False else
                          '; enablement unknown' if enabled_key else '')
                result.append('{} [{}]: {}{}'.format(name, purpose, presence, toggle))
                if name == 'MDBList':
                    result.append('Extra ratings use the MDBList API key. It is checked for presence only; '
                                  'missing key, invalid/limited service, unavailable title data or cache can omit ratings. '
                                  'Watch/list enablement is separate from the rating overlay key.')
    providers, ai = _provider_packages(ui), ui.installed_ai_status()
    result += ['', 'If a service you want is NOT CONFIGURED, connect your own account privately in LeanStream Accounts/settings. '
               'An enabled switch or saved credential does not prove valid access, available quota or playable sources.',
               'Never send account settings, API keys or tokens.',
               'Source provider setup: ' + providers, '', ai,
               '', 'Full Kodi prerequisite detail:', ui.report_rows(rows),
               '', 'Nothing installed, enabled, authorised, synced or changed. Existing credentials stayed on this device.']
    by_id = {r['id']: r for r in rows}
    trailers = all(by_id.get(i, {}).get('status') == 'OK' for i, _, _ in bundle.TRAILER_REQUIREMENTS)
    ratings = services.get('MDBList', (None, None))[0]
    playback = any(services.get(n) == (True, True) for n, _, _, p in SERVICES if p == 'playback')
    legacy = any(services.get(n, (None, None))[0] is True for n, _, _, p in SERVICES if p == 'legacy playback')
    provider_ok = providers.split(' ', 1)[0].isdigit() and int(providers.split(' ', 1)[0]) > 0
    ai_ok = ai.startswith('Potion 4M int8: verified model and AI engine files')
    summary = [
        (not required, 'Required add-ons', 'Compatible installed metadata' if not required else '{} need attention - see details'.format(len(required))),
        (trailers, 'Trailers', 'YouTube and InputStream installed/enabled' if trailers else 'YouTube / InputStream need attention'),
        (ratings is True, 'Extra ratings - MDBList', 'API key saved; online access not tested' if ratings is True else 'Connect your MDBList API key' if ratings is False else 'Configuration could not be checked'),
        (playback, 'Playback service', 'At least one enabled account has a saved credential' if playback else 'Legacy credential found; review Accounts' if legacy else 'Connect / enable one playback service'),
        (ai_ok, 'AI recommendations', 'Model and engine files verified' if ai_ok else 'AI files need attention - see details'),
        (provider_ok, 'Source providers', 'Installed package metadata found; function not tested' if provider_ok else 'Review source provider setup'),
    ]
    return {'summary': summary, 'full': '\n'.join(result)}


def report(ui):
    return collect(ui)['full']


def show(ui):
    stage = 'inventory'
    try:
        snapshot = collect(ui)
        stage = 'view-import'
        from resources.lib import setup_view
        stage = 'view-open'
        setup_view.show(ui, snapshot)
    except Exception as exc:
        # Error class and fixed phase only, never values or exception messages.
        kind = type(exc).__name__
        kind = kind if kind.isalpha() and len(kind) < 40 else 'Error'
        ui.DIALOG.ok('Setup check unavailable', 'Compatibility code: ' + stage + '/' + kind
            + '. No account values or settings were changed.')
