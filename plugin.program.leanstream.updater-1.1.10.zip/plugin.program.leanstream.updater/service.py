# -*- coding: utf-8 -*-
"""Apply queued scraping once; other presets stay optional. No code installs."""
import xbmc
from resources.lib import scrape_setup
from resources.lib import updater as ui
from resources.lib.updater import finish_skin_setup, finish_trailer_setup, finish_android_playback_setup, finish_scrape_setup

monitor = xbmc.Monitor()
# Bounded registration/busy retry, not a persistent settings-enforcement loop.
for attempt in range(12):
    try:
        if not scrape_setup.automatic_pending(ui.DATA): break
        if finish_scrape_setup(startup=True): break
    except Exception:
        xbmc.log('[LeanStream Updater] Automatic scraping setup deferred; no private diagnostics logged.', xbmc.LOGWARNING)
        break
    if monitor.waitForAbort(1): break
finish_trailer_setup(startup=True)
finish_android_playback_setup(startup=True)
finish_skin_setup(startup=True)
