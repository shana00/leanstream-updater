# -*- coding: utf-8 -*-
"""Offer only queued trailer/skin setup; never downloads or installs code."""
from resources.lib.updater import finish_skin_setup, finish_trailer_setup, finish_android_playback_setup, finish_scrape_setup

finish_trailer_setup(startup=True)
finish_android_playback_setup(startup=True)
finish_scrape_setup(startup=True)
finish_skin_setup(startup=True)
