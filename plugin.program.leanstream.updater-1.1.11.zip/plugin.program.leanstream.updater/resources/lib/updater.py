# -*- coding: utf-8 -*-
"""Manual, remote-friendly updater; no service, telemetry or automatic installs."""
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import bundle, skin_setup, self_update, prerequisites, trailer_setup, github_access, android_playback, scrape_setup, setup_check

API = "https://api.github.com/repos/" + bundle.REPO
TEST_MANIFEST = "updates/shield-test/latest.json"
LEGACY_MANIFEST = "updates/latest.json"
SELF = xbmcaddon.Addon()
DIALOG = xbmcgui.Dialog()
HOME = xbmcvfs.translatePath("special://home/")
DATA = xbmcvfs.translatePath("special://profile/addon_data/" + bundle.SELF_ID)
ADDONS = os.path.join(HOME, "addons")


class Cancelled(Exception):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Do not forward a private-repository token to a redirected origin.
        return None


def fetch(path, token, limit, cancelled=lambda: False):
    if path not in (TEST_MANIFEST, LEGACY_MANIFEST) and not re.fullmatch(
            r"updates/[A-Za-z0-9_.-]+\.zip", path):
        raise bundle.UpdateError("Unapproved repository download path.")
    encoded = "/".join(urllib.parse.quote(x, safe="") for x in path.split("/"))
    request = urllib.request.Request(API + "/contents/" + encoded, headers={
        "Accept": "application/vnd.github.raw+json",
        "Authorization": "Bearer " + token,
        "User-Agent": "LeanStream-Shield-Updater/" + bundle.VERSION,
        "X-GitHub-Api-Version": "2026-03-10",
    })
    try:
        with urllib.request.build_opener(NoRedirect()).open(request, timeout=15) as response:
            chunks = []
            received = 0
            while True:
                if cancelled():
                    raise Cancelled()
                chunk = response.read(min(65536, limit + 1 - received))
                if not chunk:
                    return b"".join(chunks)
                received += len(chunk)
                if received > limit:
                    raise bundle.UpdateError("Repository download exceeds its size limit.")
                chunks.append(chunk)
    except urllib.error.HTTPError as exc:
        if exc.code == 404 and path == TEST_MANIFEST:
            raise bundle.UpdateError(
                "No Shield test release is available, or this token cannot see it. "
                "The test release may not be published yet. The existing add-on release check "
                "can verify repository access. Nothing installed; do not reset accounts.") from None
        if exc.code in (401, 403, 429):
            detail = github_access.http_failure(exc)
            raise bundle.UpdateError("GitHub download stopped: " + github_access.describe(detail)
                + "\nRun Check GitHub access (no changes) for a safe report. "
                "No suite files were replaced; do not reset accounts.") from None
        raise bundle.UpdateError("GitHub download failed (HTTP {}). Nothing installed.".format(exc.code)) from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise bundle.UpdateError("Could not download from GitHub. Nothing installed.") from None


def rpc(method, params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    return result.get("result", {})


def read_core(path, limit):
    stream = xbmcvfs.File(path)
    try:
        return bytes(stream.readBytes(limit))
    finally:
        stream.close()


def addon_metadata(addon_id):
    if prerequisites.core_id(addon_id):
        return prerequisites.core_metadata(addon_id, read_core)
    if not re.fullmatch(r"[a-zA-Z0-9_.-]{1,128}", addon_id):
        return None
    try:
        path = xbmcaddon.Addon(addon_id).getAddonInfo("path")
        raw = read_core(os.path.join(path, "addon.xml"), bundle.MAX_DEPENDENCY_XML + 1)
        if len(raw) > bundle.MAX_DEPENDENCY_XML:
            return None
        metadata = ET.fromstring(raw)
        if metadata.tag != "addon" or metadata.get("id") != addon_id:
            return None
        bundle.dependency_compare(metadata.get("version", ""), "0")
        return metadata
    except (RuntimeError, OSError, ET.ParseError, bundle.UpdateError, TypeError, ValueError):
        return None


def lookup(addon_id):
    if prerequisites.core_id(addon_id):
        metadata = addon_metadata(addon_id)
        if metadata is None:
            return None
        try:
            abi = bundle.addon_abi(metadata)
        except bundle.UpdateError:
            abi = None
        return metadata.get("version"), True, abi
    details = rpc("Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["version", "enabled"]})
    addon = details.get("addon", {}) if isinstance(details, dict) else {}
    if addon.get("version"):
        metadata = addon_metadata(addon_id)
        abi = None
        try:
            if metadata is not None and bundle.dependency_compare(metadata.get("version"), addon["version"]) == 0:
                abi = bundle.addon_abi(metadata)
        except bundle.UpdateError:
            pass
        enabled = addon.get("enabled")
        return addon["version"], enabled if type(enabled) is bool else None, abi
    return None


def dependency_xml(addon_id):
    metadata = addon_metadata(addon_id)
    # Lookup marks registered-but-unreadable metadata as unknown ABI, so a
    # required malformed node cannot masquerade as an empty ready dependency.
    return bundle.declared_requirements(ET.tostring(metadata)) if metadata is not None else []


def expand_requirements(requirements, planned=None):
    """Read installed dependency declarations without importing their code."""
    expanded = [bundle.requirement(x) for x in requirements]
    if len(expanded) > bundle.MAX_DEPENDENCY_EDGES:
        raise bundle.UpdateError("Dependency graph exceeds the safe edge limit.")
    identities = {x.id for x in expanded}
    if len(identities) > bundle.MAX_DEPENDENCY_IDS:
        raise bundle.UpdateError("Dependency graph exceeds the safe identity limit.")
    seen = set()
    queue = list(expanded)
    while queue:
        item = bundle.requirement(queue.pop(0))
        addon_id, required = item.id, item.required
        key = (addon_id, required)
        if key in seen or (planned and addon_id in planned):
            continue
        seen.add(key)
        if len(seen) > bundle.MAX_DEPENDENCY_IDS * 2:
            raise bundle.UpdateError("Dependency declarations exceed the safe check limit.")
        if not lookup(addon_id):
            continue
        for child in dependency_xml(addon_id):
            child = bundle.requirement(child)
            child = child._replace(required=required and child.required)
            expanded.append(child)
            queue.append(child)
            identities.add(child.id)
            if len(identities) > bundle.MAX_DEPENDENCY_IDS:
                raise bundle.UpdateError("Dependency graph exceeds the safe identity limit.")
            if len(expanded) > bundle.MAX_DEPENDENCY_EDGES:
                raise bundle.UpdateError("Dependency graph exceeds the safe edge limit.")
    return expanded


def requirement_rows(requirements, planned=None, planned_abis=None):
    return prerequisites.mark_core(bundle.requirement_report(
        expand_requirements(requirements, planned), lookup, planned, planned_abis))


def report_rows(rows):
    lines = []
    def append(row):
        lines.append("{}: {} | {} | minimum {}".format(row["id"], row["status"],
            row["version"] or "not installed", row["minimum"]))
        if prerequisites.core_id(row["id"]) or row["status"] != "OK":
            lines.append("  requested interface {} | provided ABI {} | required by {}".format(
                row.get("requested", "unknown"), row.get("abi") or "unverified",
                ", ".join(row.get("sources", [])) or "unknown"))
    core = [x for x in rows if prerequisites.core_id(x["id"])]
    if core:
        lines.append("Kodi built-in interfaces (not separate downloads):")
        for row in core:
            append(row)
        lines.append("")
    for required in (True, False):
        lines.append("Required components:" if required else "Optional components (not blocking):")
        for row in rows:
            if row["required"] == required and not prerequisites.core_id(row["id"]):
                append(row)
        lines.append("")
    return "\n".join(lines)


def installed_ai_status():
    folder = os.path.join(ADDONS, bundle.PLUGIN)
    def read(name):
        with open(os.path.join(folder, *name.split("/")), "rb") as stream:
            return stream.read(bundle.MAX_PACKAGE + 1)
    try:
        message = bundle.validate_ai(read)
    except (OSError, bundle.UpdateError, KeyError, TypeError):
        return "AI files: not installed or incomplete (the new paired release supplies these)."
    try:
        addon = xbmcaddon.Addon(bundle.PLUGIN)
        semantic = addon.getSettingBool("experimental.semanticSimilarity")
        personal = addon.getSettingBool("experimental.personalizedSimilarity")
        message += "\nSemantic recommendations: {}\nPersonalized recommendations: {}".format(
            "ON" if semantic else "OFF", "ON" if personal else "OFF")
    except RuntimeError:
        message += "\nAI setting status unavailable."
    return message + "\nSettings are reported only; the updater does not enable AI automatically."


def check_services():
    requirements = dependency_xml(bundle.PLUGIN) + dependency_xml(bundle.SKIN) + list(bundle.TRAILER_REQUIREMENTS)
    rows = requirement_rows(requirements)
    build = str(xbmc.getInfoLabel("System.BuildVersion"))[:128].replace("\n", " ").replace("\r", " ")
    DIALOG.textviewer("LeanStream prerequisites (read-only)", "Updater " + bundle.VERSION + " | Kodi " + build
                      + "\n\n" + report_rows(rows) + "\n" + installed_ai_status()
                      + "\n\nAccount connections remain in LeanStream Accounts. No logins or network services were tested.")


def check_setup():
    setup_check.show(sys.modules[__name__])


def entrypoint(query=""):
    """Fixed read-only entry used by LeanStream Accounts; no install dispatch."""
    if query in ("", "?"):
        return main()
    if query not in ("?action=setupCheck", "action=setupCheck"):
        DIALOG.ok("LeanStream setup check", "Unsupported request. Nothing changed.")
        return
    try:
        check_setup()
    except Exception:
        # Never expose credential-bearing exception messages or raw metadata.
        DIALOG.ok("LeanStream setup check", "The configuration check could not finish. Nothing changed. Restart Kodi and retry; do not reset accounts.")


def check_github_access():
    # Manual only. No settings setter, diagnostic file, log or install call.
    token = SELF.getSettingString("github_token")
    progress = xbmcgui.DialogProgress()
    progress.create("Check GitHub access", "Read-only check; nothing will be installed...")
    monitor = xbmc.Monitor()
    try:
        result = github_access.check(token,
            cancelled=lambda: progress.iscanceled() or monitor.abortRequested(),
            progress=lambda index, label: progress.update(index * 33, "Checking " + label + "..."))
    finally:
        progress.close()
        token = None
    DIALOG.textviewer("LeanStream GitHub access (read-only)", github_access.render(result))


def prepare_suite(requirements, planned, cancelled=lambda: False, planned_abis=None):
    """Native prerequisite preparation before any private suite code replacement.

    Kodi chooses platform packages from its existing repository policy and owns
    install/enable dialogs, menu locks, dependency resolution and cancellation.
    The native modal call waits for Kodi/user completion, not a hard deadline.
    No raw dependency ZIPs, repositories, global updates, security or accounts.
    """
    safe_to_replace()
    if SELF.getAddonInfo("version") != bundle.VERSION:
        raise bundle.UpdateError("Restart Kodi before using the newly installed updater for suite setup.")
    for record in (bundle.last_backup(DATA), self_update.state(DATA), skin_setup.read_request(DATA)):
        if record and record.get("state") == "pending":
            raise bundle.UpdateError("Finish or restore the interrupted setup before preparing suite prerequisites.")
    if trailer_setup.interrupted(DATA):
        raise bundle.UpdateError("Restore interrupted trailer preferences before another suite setup.")
    rows = requirement_rows(requirements, planned, planned_abis)
    available = set()
    attempted = set()
    summary = []
    with bundle.update_lock(DATA):
        while True:
            if cancelled():
                raise Cancelled()
            # Optional modules are best effort only when Kodi lists them as
            # installable; absent platform-specific modules do not block a suite.
            if any(not x["required"] and x["status"] == "MISSING" for x in rows):
                result = rpc("Addons.GetAddons", {"installed": False, "properties": ["version"]})
                if isinstance(result, dict):
                    available = {x.get("addonid") for x in result.get("addons", []) if isinstance(x, dict)}
            actions, blocked = prerequisites.plan(rows, available, attempted, planned)
            if blocked:
                DIALOG.textviewer("Suite prerequisites - suite files not replaced", report_rows(rows)
                    + "\nUnverified/outdated Kodi core needs attention in Kodi itself, not a separate add-on install. "
                    "Unknown/unsupported requirements cannot be assumed safe. Already installed old add-ons "
                    "cannot be upgraded with Kodi's InstallAddon command. No global updates or uninstalls were requested. "
                    "Any completed Kodi prerequisite changes stay installed; suite code rollback does not undo them.")
                return False, summary
            if not actions:
                return True, summary
            if len(attempted) + len(actions) > prerequisites.MAX_ACTIONS:
                raise bundle.UpdateError("Suite prerequisite action limit reached; suite files not replaced.")
            description = "\n".join("{}: {}{}".format(x["id"],
                "enable" if x["status"] == "DISABLED" else "install", " (optional)" if not x["required"] else "") for x in actions)
            if not DIALOG.yesno("Prepare required suite add-ons in Kodi?", description
                    + "\n\nKodi will install platform packages from its configured repositories and may ask you to confirm. "
                    "No account setup or security changes. Optional unavailable modules may be skipped. "
                    "If cancelled, the suite stays unchanged; completed prerequisite changes may remain."):
                raise Cancelled()
            for row in actions:
                if cancelled():
                    raise Cancelled()
                safe_to_replace()
                # Earlier native installs may already have supplied this child.
                refreshed = requirement_rows(requirements, planned, planned_abis)
                current = next((x for x in refreshed if x["id"] == row["id"]), None)
                if current is None or current["status"] == "OK":
                    continue
                now_actions, now_blocked = prerequisites.plan([current], available, attempted, planned)
                if now_blocked or not now_actions:
                    rows = refreshed
                    break
                attempted.add(row["id"])
                command = "EnableAddon" if current["status"] == "DISABLED" else "InstallAddon"
                # ID has been validated and narrowly allowlisted by plan().
                xbmc.executebuiltin(command + "(" + row["id"] + ")", True)
                if cancelled():
                    raise Cancelled()
                rows = requirement_rows(requirements, planned, planned_abis)
                checked = next((x for x in rows if x["id"] == row["id"]), None)
                if checked and checked["status"] == "OK":
                    summary.append(row["id"] + ": ready")
                elif row["required"]:
                    DIALOG.textviewer("Kodi prerequisite incomplete - suite files not replaced", report_rows(rows)
                        + "\nKodi installation/enablement did not complete or was declined. Finish/close its dialog and retry "
                        "the suite installer. Completed prerequisites remain installed; no private suite code was replaced.")
                    return False, summary
                else:
                    summary.append(row["id"] + ": optional, not installed")
            rows = requirement_rows(requirements, planned, planned_abis)


def safe_to_replace():
    if scrape_setup.interrupted(DATA):
        raise bundle.UpdateError("Use Restore PC scraping preferences before changing suite code.")
    if android_playback.interrupted(DATA):
        raise bundle.UpdateError("Use Restore Android playback preferences before changing suite code.")
    match = re.match(r"(\d+)", xbmc.getInfoLabel("System.BuildVersion"))
    if not match or int(match.group(1)) != 21:
        raise bundle.UpdateError("This updater release is validated for Kodi 21 only.")
    if xbmc.Player().isPlaying():
        raise bundle.UpdateError("Stop playback/trailers and leave LeanStream before updating.")
    if xbmc.getSkinDir() == bundle.SKIN:
        raise bundle.UpdateError("Temporarily select Estuary in Kodi Interface settings before updating "
                                 "or restoring LeanStream. Skin selection is only offered after restart.")


def installed_version(addon_id):
    path = os.path.join(ADDONS, addon_id, "addon.xml")
    if not os.path.exists(path):
        return "0"
    try:
        root = ET.parse(path).getroot()
        if root.get("id") != addon_id:
            raise bundle.UpdateError("Unexpected installed add-on identity.")
        version = root.get("version", "")
        bundle.ver(version)
        return version
    except (ET.ParseError, OSError):
        raise bundle.UpdateError("Installed add-on metadata is unreadable.") from None


def check_release(paired):
    token = SELF.getSettingString("github_token").strip()
    if not token:
        DIALOG.ok("LeanStream Updater", "Existing read-only GitHub access is not configured. "
                  "No account or token has been changed.")
        return
    safe_to_replace()
    progress = xbmcgui.DialogProgress()
    progress.create("LeanStream Updater", "Checking test release..." if paired else "Checking legacy add-on release...")
    monitor = xbmc.Monitor()
    cancel = lambda: progress.iscanceled() or monitor.abortRequested()
    download = None
    try:
        packages = bundle.manifest(fetch(TEST_MANIFEST if paired else LEGACY_MANIFEST,
                                         token, 65536, cancel), paired)
        for item in packages:
            if bundle.ver(item["version"]) < bundle.ver(installed_version(item["addon_id"])):
                raise bundle.UpdateError("This release would downgrade an installed component.")
        if all(bundle.ver(x["version"]) == bundle.ver(installed_version(x["addon_id"])) for x in packages):
            progress.close()
            DIALOG.ok("LeanStream Updater", "Already on these release versions. Nothing changed.")
            return
        progress.close()
        summary = "\n".join("{}: {} -> {}".format(x["addon_id"], installed_version(x["addon_id"]), x["version"])
                            for x in packages)
        if not DIALOG.yesno("LeanStream test release" if paired else "Legacy add-on release", summary
                            + "\n\nDownload, verify prerequisites, then install? Accounts and active skin are not changed."
                            + ("\nAfter restart: one-time PC scraping setup (15-source target / 10s) with a restore backup. Existing scraping setup records are preserved." if paired else "")):
            return
        default_skin = paired and DIALOG.yesno("Make LeanStream the default skin after restart?",
            "Use the new LeanStream skin after the complete bundle is installed and Kodi restarts? "
            "Kodi will ask you to keep the skin. Accounts and credentials are not transferred; "
            "your previous skin stays installed.")
        previous_skin = xbmc.getSkinDir()
        progress.create("LeanStream Updater", "Downloading and validating all components...")
        os.makedirs(DATA, exist_ok=True)
        download = tempfile.mkdtemp(prefix="downloads-", dir=DATA)
        paths = {}
        planned_abis = {}
        requirements = list(bundle.TRAILER_REQUIREMENTS) if paired else []
        for index, item in enumerate(packages):
            progress.update(10 + index * 25, "Downloading " + item["addon_id"])
            raw = fetch("updates/" + item["filename"], token, item["size"], cancel)
            bundle.verify_bytes(raw, item)
            path = os.path.join(download, item["filename"])
            with open(path, "wb") as stream:
                stream.write(raw)
            paths[item["addon_id"]] = path
            requirements.extend(bundle.validate_package(path, item, require_ai=paired))
            planned_abis[item["addon_id"]] = bundle.package_abi(path, item)
        planned = {x["addon_id"]: x["version"] for x in packages}
        rows = requirement_rows(requirements, planned, planned_abis)
        prerequisite_summary = []
        if paired:
            progress.close()
            ready, prerequisite_summary = prepare_suite(requirements, planned, monitor.abortRequested, planned_abis)
            if not ready:
                return
            progress.create("LeanStream Updater", "Rechecking suite prerequisites...")
            rows = requirement_rows(requirements, planned, planned_abis)
        missing = [x for x in rows if x["required"] and x["status"] != "OK"]
        if missing:
            progress.close()
            DIALOG.textviewer("Prerequisites need attention - suite files not replaced", report_rows(rows)
                              + "\nRequired components are still not ready. Completed Kodi prerequisite changes may remain. "
                              "Android binary add-ons must come from the appropriate Kodi repository, not Windows files.")
            return
        if cancel():
            raise Cancelled()
        safe_to_replace()
        progress.update(80, "Verified. Saving rollback and installing components...")
        # Cancellation is honoured before the transaction, not between component renames.
        bundle.install(ADDONS, DATA, packages, paths, paired)
        trailer_note = ""
        if paired:
            try:
                trailer_setup.queue(sys.modules[__name__], packages)
                trailer_note = "\nAfter restart: one-time PC scraping setup (15-source target / 10s) with restore backup; existing setup records are preserved. Trailer/Android presets remain optional."
            except Exception:
                # Suite files are already installed; never misreport this as a
                # rolled-back code install or log raw profile exception details.
                trailer_note = "\nSuite files installed, but trailer-preference setup could not be queued. Preferences were not changed."
        if default_skin:
            skin_setup.queue(ADDONS, DATA, packages, previous_skin)
        else:
            skin_setup.cancel(DATA)
        progress.update(100, "Files installed. Restart Kodi before using LeanStream.")
        progress.close()
        xbmc.executebuiltin("UpdateLocalAddons")
        DIALOG.ok("LeanStream update complete", "All release files installed; a verified code backup is saved. "
                  "Accounts and provider data were not copied or changed.\n\n"
                  "Exit and reopen Kodi normally. " + (
                  "The approved default-skin setup will run once; choose Yes in Kodi's Keep this skin prompt. "
                  if default_skin else "Select LeanStream manually under Interface / Skin if desired. ")
                  + "If needed, enable LeanStream in My add-ons and use Finish default-skin setup. "
                  "AI options remain under LeanStream settings."
                  + ("\n\nKodi prerequisite preparation:\n" + "\n".join(prerequisite_summary) if prerequisite_summary else "")
                  + trailer_note)
    finally:
        progress.close()
        if download:
            shutil.rmtree(download)


def restore_backup():
    safe_to_replace()
    info = bundle.last_backup(DATA)
    if not info:
        DIALOG.ok("LeanStream Updater", "No updater 1.1 code backup is available yet.")
        return
    if DIALOG.yesno("Restore previous LeanStream files?", "Restore the add-on/skin code saved before the last update? "
                    "Accounts and settings are not rolled back or changed. Restart Kodi afterward."):
        skin_setup.cancel(DATA)
        trailer_setup.cancel(DATA)
        bundle.restore(ADDONS, DATA)
        xbmc.executebuiltin("UpdateLocalAddons")
        DIALOG.ok("LeanStream files restored", "Exit and reopen Kodi normally before using LeanStream.")


def finish_skin_setup(startup=False):
    try:
        if scrape_setup.interrupted(DATA):
            raise bundle.UpdateError("Restore PC scraping preferences before finishing setup.")
        if android_playback.interrupted(DATA):
            raise bundle.UpdateError("Restore Android playback preferences before finishing skin setup.")
        skin_setup.apply(sys.modules[__name__], startup=startup)
    except bundle.UpdateError as exc:
        DIALOG.ok("LeanStream default-skin setup", str(exc))
    except Exception:
        xbmc.log("[LeanStream Updater] Default-skin setup stopped; no private diagnostics logged.", xbmc.LOGERROR)
        if not startup:
            DIALOG.ok("LeanStream default-skin setup", "Could not finish setup. Use Kodi Interface / Skin "
                      "or retry after restarting. Do not reset accounts.")


def finish_trailer_setup(startup=False):
    try:
        if scrape_setup.interrupted(DATA):
            raise bundle.UpdateError("Restore PC scraping preferences before another setup.")
        if android_playback.interrupted(DATA):
            raise bundle.UpdateError("Restore Android playback preferences before another preference setup.")
        return trailer_setup.apply(sys.modules[__name__], startup=startup)
    except bundle.UpdateError as exc:
        if not startup:
            DIALOG.ok("LeanStream trailer preferences", str(exc))
    except Exception:
        xbmc.log("[LeanStream Updater] Trailer preference setup stopped; no private diagnostics logged.", xbmc.LOGERROR)
        if not startup:
            DIALOG.ok("LeanStream trailer preferences", "Setup stopped. Preferences were not confirmed ready; "
                      "use Restore trailer preferences if interrupted. Accounts were not reset.")
    return False


def restore_trailer_setup():
    return trailer_setup.restore(sys.modules[__name__])


def finish_android_playback_setup(startup=False):
    try:
        if scrape_setup.interrupted(DATA):
            raise bundle.UpdateError("Restore PC scraping preferences before another setup.")
        return android_playback.apply(sys.modules[__name__], startup=startup)
    except bundle.UpdateError as exc:
        if not startup:
            DIALOG.ok("Android playback preset", str(exc))
    except Exception:
        xbmc.log("[LeanStream Updater] Android playback setup stopped; no private diagnostics logged.", xbmc.LOGERROR)
        if not startup:
            DIALOG.ok("Android playback preset", "Setup stopped. Use Restore Android playback preferences if interrupted; do not reset accounts.")
    return False


def finish_scrape_setup(startup=False):
    try:
        return scrape_setup.apply(sys.modules[__name__], startup=startup)
    except bundle.UpdateError as exc:
        if not startup: DIALOG.ok("PC scraping preset", str(exc))
    except Exception:
        xbmc.log("[LeanStream Updater] Scraping preference setup stopped; no private diagnostics logged.", xbmc.LOGERROR)
        if not startup: DIALOG.ok("PC scraping preset", "Setup stopped. Use Restore PC scraping preferences if interrupted; do not reset accounts.")
    return False


def updater_only_preflight():
    if scrape_setup.interrupted(DATA):
        raise bundle.UpdateError("Use Restore PC scraping preferences before changing updater code.")
    if android_playback.interrupted(DATA):
        raise bundle.UpdateError("Use Restore Android playback preferences before changing updater code.")
    match = re.match(r"(\d+)", xbmc.getInfoLabel("System.BuildVersion"))
    if not match or int(match.group(1)) != 21:
        raise bundle.UpdateError("Updater self-upgrade is validated for Kodi 21 only.")
    if xbmc.Player().isPlaying():
        raise bundle.UpdateError("Stop playback/trailers before upgrading the updater.")
    if SELF.getAddonInfo("version") != bundle.VERSION:
        raise bundle.UpdateError("Restart Kodi before using the newly installed updater.")
    paired = bundle.last_backup(DATA)
    if paired and paired.get("state") == "pending":
        raise bundle.UpdateError("Restore the interrupted add-on/skin update first.")
    queued = skin_setup.read_request(DATA)
    if queued and queued.get("state") == "pending":
        raise bundle.UpdateError("Finish or decline the existing default-skin setup before upgrading the updater.")
    if trailer_setup.interrupted(DATA):
        raise bundle.UpdateError("Restore interrupted trailer preferences before upgrading the updater.")


def bridge_dependency():
    """No undeclared crypto import in the bridge, and no PC binary copying."""
    try:
        row=rpc('Addons.GetAddonDetails',{'addonid':'script.module.pycryptodome','properties':['enabled','version']})['addon']
    except Exception:
        raise bundle.UpdateError('Kodi\'s crypto dependency is missing. Install/repair script.module.pycryptodome through Kodi, then retry Update updater. No files changed.') from None
    if row.get('enabled') is not True or bundle.dependency_compare(row.get('version','0'),'3.4.3')<0:
        raise bundle.UpdateError('Kodi\'s crypto dependency is disabled or too old. Repair it through Kodi before retrying; nothing installed.')

def update_updater():
    updater_only_preflight()
    previous = self_update.state(DATA)
    if previous and previous["state"] == "pending":
        raise bundle.UpdateError("Use Restore updater backup before another updater upgrade.")
    monitor = xbmc.Monitor()
    # Legacy public feed stays on the bridge; this exact next hop is pinned.
    info = self_update.bootstrap()
    if bundle.ver(info["version"]) <= bundle.ver(bundle.VERSION):
        DIALOG.ok("LeanStream Updater", "Already on the current updater version. Nothing changed.")
        return
    bridge_dependency()
    if not DIALOG.yesno("Update LeanStream Updater?", bundle.VERSION + " -> " + info["version"]
            + "\n\nFinish the one-time compatibility step. The next core declares Kodi's crypto dependency and pins signed maintenance trust. Only updater code changes; accounts, tokens, settings, skin and LeanStream remain untouched. Restart Kodi afterward."):
        return
    progress = xbmcgui.DialogProgress()
    progress.create("Update updater", "Downloading and verifying public updater ZIP...")
    cancel = lambda: progress.iscanceled() or monitor.abortRequested()
    try:
        raw = self_update.fetch(info["filename"], info["size"], cancel)
        if cancel(): raise self_update.Cancelled()
        bridge_dependency()
        self_update.install(ADDONS, DATA, raw, info, cancel)
    finally: progress.close()
    xbmc.executebuiltin("UpdateLocalAddons")
    DIALOG.ok("Updater upgraded", "Exit and reopen Kodi normally before running the updater again. Settings and credentials were preserved.")


def restore_updater():
    updater_only_preflight()
    if not self_update.state(DATA):
        DIALOG.ok("LeanStream Updater", "No updater-only backup exists yet.")
        return
    if DIALOG.yesno("Restore updater backup?", "Restore only the updater code saved before its last self-upgrade? Accounts, settings and the private add-on/skin/AI remain untouched. Restart Kodi afterward."):
        self_update.restore(ADDONS, DATA)
        xbmc.executebuiltin("UpdateLocalAddons")
        DIALOG.ok("Updater restored", "Exit and reopen Kodi normally before using the restored updater.")


def main():
    try:
        info = bundle.last_backup(DATA)
        if info and info.get("state") == "pending":
            DIALOG.ok("Interrupted LeanStream update", "Restore the last update backup before checking another release.")
        choice = DIALOG.select("LeanStream Updater " + bundle.VERSION + " — compatibility step", [
            "Update updater (public download)",
            "Restore updater backup",
            "Setup check - add-ons and services (no changes)",
            "Check GitHub access (no changes)",
            "Restore last update backup",
            "Restore trailer preferences",
            "Restore Android playback preferences",
            "Restore PC scraping preferences",
        ])
        self_record = self_update.state(DATA)
        if self_record and self_record["state"] == "pending" and choice not in (-1, 1, 2, 3):
            raise bundle.UpdateError("Use Restore updater backup before changing other LeanStream components.")
        if trailer_setup.interrupted(DATA) and choice not in (-1, 2, 3, 5):
            raise bundle.UpdateError("Use Restore trailer preferences before another code or setup change.")
        if android_playback.interrupted(DATA) and choice not in (-1, 2, 3, 6):
            raise bundle.UpdateError("Use Restore Android playback preferences before another code or setup change.")
        if scrape_setup.interrupted(DATA) and choice not in (-1, 2, 3, 7):
            raise bundle.UpdateError("Use Restore PC scraping preferences before another code or setup change.")
        if choice == 0:
            update_updater()
        elif choice == 1:
            restore_updater()
        elif choice == 2:
            check_setup()
        elif choice == 3:
            check_github_access()
        elif choice == 4:
            restore_backup()
        elif choice == 5:
            restore_trailer_setup()
        elif choice == 6:
            android_playback.restore(sys.modules[__name__])
        elif choice == 7:
            scrape_setup.restore(sys.modules[__name__])
    except Cancelled:
        DIALOG.ok("LeanStream Updater", "Cancelled. LeanStream suite files were not replaced. "
                  "Any Kodi prerequisites already installed or enabled stay in place; accounts were not reset.")
    except bundle.UpdateError as exc:
        DIALOG.ok("LeanStream Updater", str(exc))
    except Exception:
        # Raw request/exception strings can expose private URLs or authorization data.
        xbmc.log("[LeanStream Updater] Operation failed; no private diagnostic data logged.", xbmc.LOGERROR)
        DIALOG.ok("LeanStream Updater", "Operation failed. Do not reset accounts. "
                  "If an installation was interrupted, use Restore last update backup before using LeanStream.")
