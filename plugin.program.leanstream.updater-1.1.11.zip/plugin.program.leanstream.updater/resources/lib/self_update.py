"""Manual updater-only upgrade. Public HTTPS; no credentials or profile copying."""
import ast
import hashlib
import io
import json
import os
import re
import shutil
import tempfile
import urllib.error
import urllib.request
import uuid
import xml.etree.ElementTree as ET
import zipfile

from resources.lib import bundle

BASE = 'https://shana00.github.io/leanstream-updater/'
FEED = 'updater-latest.json'
MAX_ZIP = 4 * 1024 * 1024
MAX_EXPANDED = 12 * 1024 * 1024
RECORD = 'self-update.json'
REQUIRED = {'addon.xml', 'default.py', 'service.py', 'resources/settings.xml',
            'resources/lib/__init__.py', 'resources/lib/bundle.py',
            'resources/lib/updater.py', 'resources/lib/skin_setup.py',
            'resources/lib/self_update.py'}

def bootstrap():
    """Immutable next-hop identity carried by this trusted legacy-format bridge."""
    path=os.path.join(os.path.dirname(__file__),'..','signed-bootstrap.json')
    with open(path,'rb') as stream:raw=stream.read(65537)
    if len(raw)>65536:raise bundle.UpdateError('Bridge bootstrap descriptor is oversized.')
    info=manifest(raw)
    if info['version']!='1.2.1' or info['minimum_updater']!='1.1.11':
        raise bundle.UpdateError('Unexpected bridge target. Nothing installed.')
    return info


class Cancelled(bundle.UpdateError):
    def __init__(self): super().__init__('Cancelled before updater installation. Existing files were not replaced.')


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl): return None


def fetch(name, limit, cancelled=lambda: False):
    if name != FEED and not re.fullmatch(re.escape(bundle.SELF_ID) + r'-\d+(?:\.\d+){0,3}\.zip', name):
        raise bundle.UpdateError('Unapproved public updater download.')
    if not 0 < limit <= MAX_ZIP:
        raise bundle.UpdateError('Invalid public download limit.')
    if cancelled(): raise Cancelled()
    request = urllib.request.Request(BASE + name, headers={
        'User-Agent': 'LeanStream-Public-Updater/' + bundle.VERSION})
    try:
        with urllib.request.build_opener(NoRedirect()).open(request, timeout=15) as response:
            if response.geturl() != BASE + name:
                raise bundle.UpdateError('Unexpected public updater redirect.')
            result, received = [], 0
            while True:
                if cancelled(): raise Cancelled()
                chunk = response.read(min(65536, limit + 1 - received))
                if not chunk: return b''.join(result)
                result.append(chunk); received += len(chunk)
                if received > limit:
                    raise bundle.UpdateError('Public updater download exceeds its size limit.')
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise bundle.UpdateError('No public updater release is available yet. Nothing installed.') from None
        raise bundle.UpdateError('Public updater download failed. Nothing installed.') from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise bundle.UpdateError('Could not download the public updater. Nothing installed.') from None


def manifest(raw):
    info = bundle.read_json(raw)
    expected = {'schema', 'addon_id', 'version', 'filename', 'sha256', 'size', 'kodi_major', 'minimum_updater'}
    if (not isinstance(info, dict) or set(info) != expected or type(info['schema']) is not int
            or info['schema'] != 1 or type(info['kodi_major']) is not int or info['kodi_major'] != 21
            or info['addon_id'] != bundle.SELF_ID):
        raise bundle.UpdateError('Invalid updater-only release metadata.')
    for key in ('version', 'minimum_updater'):
        if not isinstance(info[key], str) or not 0 < len(info[key]) <= 48 or not re.fullmatch(r'\d+(?:\.\d+){0,3}', info[key]):
            raise bundle.UpdateError('Invalid updater release version.')
    if bundle.ver(info['minimum_updater']) > bundle.ver(bundle.VERSION):
        raise bundle.UpdateError('This updater upgrade requires manual ZIP installation first.')
    if info['filename'] != bundle.SELF_ID + '-' + info['version'] + '.zip':
        raise bundle.UpdateError('Unexpected updater package filename.')
    if (not isinstance(info['sha256'], str) or not re.fullmatch(r'[a-f0-9]{64}', info['sha256'])
            or type(info['size']) is not int or not 0 < info['size'] <= MAX_ZIP):
        raise bundle.UpdateError('Invalid updater checksum or size.')
    return info


def validate(raw, info):
    info = manifest(json.dumps(info).encode('utf-8'))
    if info!=bootstrap():raise bundle.UpdateError('Bridge accepts only its pinned signed-core package.')
    bundle.verify_bytes(raw, info)
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            entries = archive.infolist()
            if not entries or len(entries) > 128 or sum(x.file_size for x in entries) > MAX_EXPANDED:
                raise bundle.UpdateError('Updater ZIP exceeds safe extraction limits.')
            seen, files = set(), {}
            for entry in entries:
                name = bundle._safe_member(entry, bundle.SELF_ID)
                if name in seen: raise bundle.UpdateError('Duplicate updater ZIP path.')
                seen.add(name)
                rel = entry.orig_filename[len(bundle.SELF_ID)+1:]
                if entry.is_dir(): continue
                if (rel not in ('addon.xml', 'default.py', 'service.py', 'README.txt')
                        and not rel.startswith('resources/')):
                    raise bundle.UpdateError('Unexpected updater file.')
                if (rel.lower().startswith(('resources/models/', 'resources/lib/modules/'))
                        or any(x.lower() in (bundle.PLUGIN, bundle.SKIN) for x in rel.split('/'))
                        or '/addon_data/' in rel.lower()):
                    raise bundle.UpdateError('Updater-only ZIP must not contain models or account data.')
                contents = archive.read(entry)
                key_marker = rb'BEG' + rb'IN[ \t]+(?:[A-Z]+[ \t]+)?PRIVATE[ \t]+KEY'
                if re.search(rb'github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|' + key_marker, contents):
                    raise bundle.UpdateError('Updater ZIP contains credential-like material.')
                files[rel] = contents
                if rel.endswith('.py'): ast.parse(contents, filename=rel)
                elif rel.endswith('.xml'): ET.fromstring(contents)
            if not REQUIRED <= files.keys() or archive.testzip() is not None:
                raise bundle.UpdateError('Incomplete or corrupt updater ZIP.')
            addon = ET.fromstring(files['addon.xml'])
            if addon.get('id') != bundle.SELF_ID or addon.get('version') != info['version']:
                raise bundle.UpdateError('Updater package identity or version mismatch.')
            if bundle.declared_requirements(files['addon.xml']) != [
                    bundle.Requirement('xbmc.python', '3.0.1', True, '3.0.1', bundle.SELF_ID),
                    bundle.Requirement('script.module.pycryptodome', '3.4.3', True, '3.4.3', bundle.SELF_ID)]:
                raise bundle.UpdateError('Updater ZIP requires unexpected dependencies.')
            trust=os.path.join(os.path.dirname(__file__),'..','trust-root.json')
            with open(trust,'rb') as stream:expected_root=stream.read(65537)
            if len(expected_root)>65536 or files.get('resources/trust-root.json')!=expected_root:
                raise bundle.UpdateError('Signed core trust root differs from this bridge.')
            extensions = {(x.get('point'), x.get('library')) for x in addon.findall('extension')}
            if ('xbmc.python.pluginsource', 'default.py') not in extensions or ('xbmc.service', 'service.py') not in extensions:
                raise bundle.UpdateError('Updater entry points are missing.')
            settings = ET.fromstring(files['resources/settings.xml'])
            token = settings.find(".//setting[@id='github_token']/default")
            if token is None or token.text:
                raise bundle.UpdateError('Updater package must preserve an empty credential default.')
    except (zipfile.BadZipFile, KeyError, ET.ParseError, SyntaxError, UnicodeError, OSError):
        raise bundle.UpdateError('Unreadable updater ZIP. Nothing installed.') from None


def _paths(addon_root, data):
    addon_root, data = os.path.abspath(addon_root), os.path.abspath(data)
    target = os.path.join(addon_root, bundle.SELF_ID)
    if os.path.basename(data).lower() != bundle.SELF_ID or any(bundle.is_link(x) for x in (addon_root, target, data)):
        raise bundle.UpdateError('Updater target or data directory is unexpected or linked.')
    if os.path.exists(target) and not os.path.isdir(target):
        raise bundle.UpdateError('Updater code target is not a directory.')
    try:
        if os.path.commonpath((addon_root, data)) == addon_root:
            raise bundle.UpdateError('Updater settings must remain outside its code directory.')
    except ValueError: pass  # Separate Windows volumes are allowed.
    return addon_root, data, target


def state(data):
    path = os.path.join(data, RECORD)
    if not os.path.isfile(path): return None
    if bundle.is_link(path): raise bundle.UpdateError('Updater recovery record is linked.')
    with open(path, 'rb') as stream: info = bundle.read_json(stream.read(65537))
    if (not isinstance(info, dict) or info.get('addon_id') != bundle.SELF_ID
            or info.get('state') not in ('pending', 'complete', 'failed', 'restored')
            or not isinstance(info.get('transaction'), str)
            or not re.fullmatch(r'[a-f0-9]{32}', info['transaction'])):
        raise bundle.UpdateError('Invalid updater recovery record.')
    for key in ('old_digest', 'new_digest'):
        if not isinstance(info.get(key), str) or not re.fullmatch(r'[a-f0-9]{64}', info[key]):
            raise bundle.UpdateError('Invalid updater recovery checksum.')
    for key in ('old_version', 'new_version'):
        if not isinstance(info.get(key), str) or not re.fullmatch(r'\d+(?:\.\d+){0,3}', info[key]):
            raise bundle.UpdateError('Invalid updater recovery version.')
    return info


def _backup(data, transaction):
    folder = os.path.join(data, 'self-backups', transaction, bundle.SELF_ID)
    for part in (os.path.join(data, 'self-backups'), os.path.dirname(folder), folder):
        if bundle.is_link(part): raise bundle.UpdateError('Updater backup is linked.')
    return folder


def _finish_stage(stage, addon_root, data):
    # Resolve/check the exact temporary target before any recursive cleanup.
    if (os.path.commonpath((os.path.realpath(stage), os.path.realpath(addon_root))) != os.path.realpath(addon_root)
            or not os.path.basename(stage).startswith('.leanstream-self-') or bundle.is_link(stage)):
        raise bundle.UpdateError('Unexpected updater staging directory; preserved for recovery.')
    info = state(data)
    if not info or info['state'] != 'pending':
        try: shutil.rmtree(stage)
        except OSError: pass  # Verified backup/record survive a cleanup-only failure.

def _archive_previous(data,info):
    if not info:return
    saved=_backup(data,info['transaction'])
    if bundle.tree_digest(saved)!=info['old_digest']:
        raise bundle.UpdateError('Previous updater rollback data changed or is missing. Preserve it and recover before continuing.')
    path=os.path.join(saved,'..','receipt.json')
    if bundle.is_link(path):raise bundle.UpdateError('Previous updater receipt is linked.')
    if os.path.exists(path):
        with open(path,'rb') as stream:record=bundle.read_json(stream.read(65537))
        if record!=info:raise bundle.UpdateError('Previous updater receipt conflicts; nothing installed.')
    else:bundle._write_json(path,info)


def _swap(target, payload, stage, data, info, expected_digest):
    previous, rejected = os.path.join(stage, 'previous'), os.path.join(stage, 'rejected')
    existed, moved = os.path.isdir(target), False
    before_digest = bundle.tree_digest(target) if existed else None
    info['state'] = 'pending'
    bundle._write_json(os.path.join(data, RECORD), info)
    try:
        if existed: os.rename(target, previous); moved = True
        os.rename(payload, target)
        if bundle.tree_digest(target) != expected_digest:
            raise bundle.UpdateError('Installed updater verification failed.')
        info['state'] = 'restored' if expected_digest == info['old_digest'] else 'complete'
        bundle._write_json(os.path.join(data, RECORD), info)
    except Exception:
        try:
            if moved:
                if os.path.isdir(target): os.rename(target, rejected)
                os.rename(previous, target)
            elif not existed and os.path.isdir(target): os.rename(target, rejected)
            if existed and bundle.tree_digest(target) != before_digest:
                raise bundle.UpdateError('Updater rollback verification failed.')
            info['state'] = 'failed'
            bundle._write_json(os.path.join(data, RECORD), info)
        except Exception:
            raise bundle.UpdateError('Updater upgrade interrupted. Use Restore updater backup, or reinstall the updater ZIP only. Do not clear settings.') from None
        raise bundle.UpdateError('Updater file operation failed. Original state restored; settings untouched.') from None


def install(addon_root, data, raw, info, cancelled=lambda: False):
    validate(raw, info)
    addon_root, data, target = _paths(addon_root, data)
    if not os.path.isdir(target): raise bundle.UpdateError('Existing updater code is missing; reinstall its ZIP first.')
    with bundle.update_lock(data):
        paired = bundle.last_backup(data)
        previous = state(data)
        if (paired and paired.get('state') == 'pending') or (previous and previous['state'] == 'pending'):
            raise bundle.UpdateError('Restore the interrupted update before upgrading the updater.')
        old_xml = ET.parse(os.path.join(target, 'addon.xml')).getroot()
        old_version = old_xml.get('version', '')
        if old_xml.get('id') != bundle.SELF_ID or old_version != bundle.VERSION:
            raise bundle.UpdateError('Running/installed updater versions differ. Restart Kodi first.')
        if bundle.ver(info['version']) <= bundle.ver(old_version):
            raise bundle.UpdateError('Only a newer updater version can be installed.')
        _archive_previous(data,previous)
        old_digest = bundle.tree_digest(target)
        transaction = uuid.uuid4().hex
        saved = _backup(data, transaction)
        stage = tempfile.mkdtemp(prefix='.leanstream-self-', dir=addon_root)
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive: archive.extractall(stage)
            payload = os.path.join(stage, bundle.SELF_ID)
            new_digest = bundle.tree_digest(payload)
            if cancelled(): raise Cancelled()
            shutil.copytree(target, saved, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '*.pyo'))
            if bundle.tree_digest(saved) != old_digest or bundle.tree_digest(target) != old_digest:
                raise bundle.UpdateError('Updater code changed or backup verification failed. Nothing installed.')
            if cancelled(): raise Cancelled()
            record = dict(addon_id=bundle.SELF_ID, transaction=transaction, old_version=old_version,
                          new_version=info['version'], old_digest=old_digest, new_digest=new_digest, state='pending')
            _swap(target, payload, stage, data, record, new_digest)
            return record
        finally: _finish_stage(stage, addon_root, data)


def restore(addon_root, data):
    addon_root, data, target = _paths(addon_root, data)
    with bundle.update_lock(data):
        paired = bundle.last_backup(data)
        if paired and paired.get('state') == 'pending':
            raise bundle.UpdateError('Restore the interrupted add-on/skin update first.')
        info = state(data)
        if not info: raise bundle.UpdateError('No updater backup exists yet.')
        saved = _backup(data, info['transaction'])
        if bundle.tree_digest(saved) != info['old_digest']:
            raise bundle.UpdateError('Updater backup is missing or changed. Nothing restored.')
        if os.path.isdir(target) and bundle.tree_digest(target) not in (info['old_digest'], info['new_digest']):
            raise bundle.UpdateError('Unexpected updater code changes. Nothing restored.')
        stage = tempfile.mkdtemp(prefix='.leanstream-self-', dir=addon_root)
        try:
            payload = os.path.join(stage, bundle.SELF_ID)
            shutil.copytree(saved, payload)
            if bundle.tree_digest(payload) != info['old_digest']:
                raise bundle.UpdateError('Updater restoration staging verification failed.')
            _swap(target, payload, stage, data, info, info['old_digest'])
            return info
        finally: _finish_stage(stage, addon_root, data)
