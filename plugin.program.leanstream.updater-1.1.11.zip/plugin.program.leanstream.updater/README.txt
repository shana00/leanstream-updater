LEANSTREAM UPDATER COMPATIBILITY BRIDGE 1.1.11

This is the one-time compatibility hop for the existing Update updater button
on the one friend's Shield. The public updater feed can stay on this bridge
while its exact pinned signed-core1.2.1 ZIP is already available alongside it.

1. Existing updater -> Update updater -> this bridge. Restart Kodi normally.
2. Update updater once more -> pinned signed core1.2.1. Restart normally again.
3. Enroll locally, review permitted scopes, then Update LeanStream to review
   the separately published signed cumulative content. No friend is auto-enrolled.

The bridge declares ONLY xbmc.python, matching the old package validator.
It does NOT import undeclared crypto or remove the real core's declaration.
The next core correctly declares script.module.pycryptodome>=3.4.3. The bridge
checks that Kodi has this dependency installed, enabled and sufficiently new,
both before approval and immediately before code replacement. Missing/disabled
dependency blocks the upgrade; repair it through Kodi, not by copying PC binaries.

Only the exact pinned version, full ZIP hash/size and public trust-root bytes
can cross this bridge. No arbitrary next version/feed/package is accepted.
Existing HTTPS/hash-only public delivery is the initial trust boundary, not
a retroactively signed first hop. Use the owner's authenticated release/hash.
Future updates after migration use public signed-core metadata and review.

Only updater code changes; per-device code backup and conditional restore stay
available. Same addon ID, existing tokens/settings/accounts/providers survive.
Do not uninstall, clear data, copy another person's profile or enter new tokens.
The public updater does not read/send the private repository token.

Startup is inert: no network, install, scraping/decoder/trailer/skin preset.
Read-only setup checks and existing legacy recovery remain available. Do not
restore over newer choices. Code rollback may reintroduce an old auto-preset
service; preserve preference backups and review before using old code again.
