"""Compatibility bridge startup is deliberately inert.

No scraping, trailer, decoder, active-skin preset, network or automatic install.
The owner must explicitly choose Update updater after the normal restart.
"""
