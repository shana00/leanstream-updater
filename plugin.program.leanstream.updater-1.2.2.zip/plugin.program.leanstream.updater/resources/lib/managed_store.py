"""Durable management state and single-writer lease; never stores credentials."""
import contextlib
import json
import os
import re
import uuid

from resources.lib import bundle
from resources.lib import managed_security as security

def _unique(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise security.Error('Duplicate local state field.')
        result[key]=value
    return result

def safe_path(path):
    path=os.path.abspath(path)
    current=path
    while True:
        if bundle.is_link(current):raise security.Error('Linked management path refused.')
        parent=os.path.dirname(current)
        if parent==current:break
        current=parent
    return path

def _fsync_directory(path):
    try:
        fd=os.open(path,os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)
    except OSError:pass  # Directory fsync is not supported on Windows.

def atomic_json(path,value):
    safe_path(path);safe_path(os.path.dirname(path))
    raw=security.canonical(value)
    if len(raw)>4*1024*1024:raise security.Error('Management state exceeds safe size.')
    temporary=path+'.tmp-'+uuid.uuid4().hex
    try:
        fd=os.open(temporary,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        with os.fdopen(fd,'wb') as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
        _fsync_directory(os.path.dirname(path))
    finally:
        if os.path.isfile(temporary) and not bundle.is_link(temporary):os.unlink(temporary)

class Store:
    def __init__(self,data,boot):
        if not isinstance(boot,str) or not re.fullmatch(r'[a-f0-9]{32}',boot):
            raise security.Error('Management boot identity unavailable; restart Kodi.')
        self.root=safe_path(os.path.join(data,'management-v1'))
        os.makedirs(self.root,exist_ok=True);self.boot=boot

    def path(self,name):
        if name not in ('enrollment','state','journal','preparing','lock','roots'):
            raise security.Error('Unknown management state file.')
        return safe_path(os.path.join(self.root,name+'.json'))

    def load(self,name,default=None):
        path=self.path(name)
        if not os.path.isfile(path):return default
        with open(path,'rb') as stream:raw=stream.read(4*1024*1024+1)
        if len(raw)>4*1024*1024:raise security.Error('Oversized management state; nothing changed.')
        # State may exceed network metadata bounds, but retains duplicate and
        # non-finite rejection through a bounded parser with a separate limit.
        try:
            value=json.loads(raw.decode('utf8'),object_pairs_hook=_unique)
            security.canonical(value)
            return value
        except (ValueError,UnicodeError,RecursionError):
            raise security.Error('Management state damaged; preserve backups and recover.') from None

    def write(self,name,value):
        if name=='journal':
            old=self.load('journal')
            if old:
                transaction=old.get('transaction')
                if not isinstance(transaction,str) or not re.fullmatch(r'[a-f0-9]{32}',transaction):
                    raise security.Error('Cannot replace invalid recovery history.')
                if old.get('transaction')!=value.get('transaction'):
                    self._finalized_record(old,transaction)
                    history=safe_path(os.path.join(self.root,'history'));os.makedirs(history,exist_ok=True)
                    destination=safe_path(os.path.join(history,transaction+'.json'))
                    if os.path.exists(destination):
                        archived=self._read_history(destination,transaction)
                        if self._history_progression(archived,old):atomic_json(destination,old)
                    else:atomic_json(destination,old)
                elif value.get('state') in ('complete','restored','cancelled'):
                    history=safe_path(os.path.join(self.root,'history'))
                    destination=safe_path(os.path.join(history,transaction+'.json'))
                    if os.path.isfile(destination):
                        archived=self._read_history(destination,transaction)
                        if self._history_progression(archived,value):atomic_json(destination,value)
        atomic_json(self.path(name),value)

    def clear_preparing(self,transaction):
        if not isinstance(transaction,str) or not re.fullmatch(r'[a-f0-9]{32}',transaction):
            raise security.Error('Invalid preparation identity.')
        value=self.load('preparing')
        if value is None:return
        if not isinstance(value,dict) or value.get('transaction')!=transaction:
            raise security.Error('Preparation identity changed; retain files for review.')
        path=self.path('preparing')
        if bundle.is_link(path):raise security.Error('Linked preparation state refused.')
        os.unlink(path)
        _fsync_directory(self.root)

    @staticmethod
    def _finalized_record(value,transaction):
        if not isinstance(value,dict):raise security.Error('Invalid recovery history record.')
        security.exact(value,('schema','transaction','job','sequence','channel','digest',
                              'state','steps','requires_restart'))
        if (not isinstance(transaction,str) or not re.fullmatch(r'[a-f0-9]{32}',transaction)
                or value['schema']!=1 or value['transaction']!=transaction
                or value['state'] not in ('complete','restored','cancelled')
                or not isinstance(value['steps'],list)
                or len(value['steps'])>security.MAX_OPERATIONS):
            raise security.Error('Unresolved or mismatched recovery history; retain backups.')
        return value

    @staticmethod
    def _history_progression(archived,current):
        transaction=archived.get('transaction') if isinstance(archived,dict) else None
        Store._finalized_record(archived,transaction)
        Store._finalized_record(current,transaction)
        intent=('schema','transaction','job','sequence','channel','digest','requires_restart')
        if any(type(archived.get(name)) is not type(current.get(name))
                or archived.get(name)!=current.get(name) for name in intent):
            raise security.Error('Current journal conflicts with authoritative recovery history.')
        if archived['state']==current['state']:
            if security.canonical(archived)!=security.canonical(current):
                raise security.Error('Finalized recovery history changed without an allowed transition.')
            return False
        if archived['state']!='complete' or current['state']!='restored':
            raise security.Error('Recovery history state cannot move backwards or sideways.')
        if len(archived['steps'])!=len(current['steps']):
            raise security.Error('Restored recovery history changed its operation plan.')
        for before,after in zip(archived['steps'],current['steps']):
            if not isinstance(before,dict) or not isinstance(after,dict):
                raise security.Error('Invalid recovery history step.')
            before_plan={key:value for key,value in before.items() if key!='state'}
            after_plan={key:value for key,value in after.items() if key!='state'}
            if security.canonical(before_plan)!=security.canonical(after_plan):
                raise security.Error('Restored recovery history changed its operation plan.')
            if type(before.get('skip')) is not bool:
                raise security.Error('Invalid recovery history skip state.')
            expected=('prepared','prepared') if before['skip'] else ('applied','restored')
            if (before.get('state'),after.get('state'))!=expected:
                raise security.Error('Recovery history step has an invalid restoration transition.')
        return True

    def _read_history(self,path,transaction,canonical=False):
        # The caller has already established that this is an exact, non-link
        # history filename. Content errors remain distinguishable from an
        # unsafe tree so an interrupted atomic write can be reconciled only
        # when another durable finalized record proves it is disposable.
        with open(path,'rb') as stream:raw=stream.read(4*1024*1024+1)
        if len(raw)>4*1024*1024:raise security.Error('Oversized recovery history entry.')
        try:
            value=json.loads(raw.decode('utf8'),object_pairs_hook=_unique)
            encoded=security.canonical(value)
        except (ValueError,UnicodeError,RecursionError):
            raise security.Error('Recovery history damaged; retain backups for review.') from None
        if canonical and raw!=encoded:
            raise security.Error('Interrupted recovery history is not a complete atomic record.')
        return self._finalized_record(value,transaction)

    def archived_finalized(self):
        history=safe_path(os.path.join(self.root,'history'))
        if not os.path.exists(history):return []
        if not os.path.isdir(history):raise security.Error('Recovery history is not a directory.')
        entries={}
        for name in sorted(os.listdir(history)):
            final=re.fullmatch(r'([a-f0-9]{32})\.json',name)
            temporary=re.fullmatch(r'([a-f0-9]{32})\.json\.tmp-([a-f0-9]{32})',name)
            if not final and not temporary:
                raise security.Error('Unexpected recovery history entry; retain for review.')
            path=safe_path(os.path.join(history,name))
            if not os.path.isfile(path):raise security.Error('Invalid recovery history entry.')
            transaction=(final or temporary).group(1)
            slot=entries.setdefault(transaction,{'final':None,'temporary':[]})
            if final:slot['final']=path
            else:slot['temporary'].append(path)

        current=self.load('journal')
        result=[]
        for transaction in sorted(entries):
            slot=entries[transaction];destination=slot['final'];temporaries=slot['temporary']
            if destination is not None:
                value=self._read_history(destination,transaction)
                # Store.write() creates history temps only while no final is
                # present. Once the atomic final exists it is authoritative;
                # any exact regular temp is residue from an earlier attempt.
                for path in temporaries:os.unlink(path)
                if temporaries:_fsync_directory(history)
                result.append(value);continue

            try:self._finalized_record(current,transaction)
            except security.Error:current_finalized=False
            else:current_finalized=True
            if current_finalized:
                # A crash can leave the old archive temp, then local Recovery
                # can advance the still-current journal from complete to
                # restored. The current durable journal wins; promoting the
                # older temp would resurrect stale history.
                for path in temporaries:os.unlink(path)
                if temporaries:_fsync_directory(history)
                continue

            valid=[]
            for path in temporaries:
                try:valid.append((path,self._read_history(path,transaction,canonical=True)))
                except security.Error:pass
            if valid:
                encoded=[security.canonical(value) for path,value in valid]
                if any(raw!=encoded[0] for raw in encoded[1:]):
                    raise security.Error('Conflicting interrupted recovery history; retain backups.')
                destination=safe_path(os.path.join(history,transaction+'.json'))
                os.replace(valid[0][0],destination);_fsync_directory(history)
                value=self._read_history(destination,transaction)
                for path in temporaries:
                    if path!=valid[0][0] and os.path.exists(path):os.unlink(path)
                if len(temporaries)>1:_fsync_directory(history)
                result.append(value);continue

            raise security.Error('Interrupted recovery history has no durable finalized source; retain backups.')
        return result

    def enrollment(self):
        value=self.load('enrollment',{'enabled':False,'device':uuid.uuid4().hex,
                                    'channel':'friends','scopes':[]})
        security.exact(value,('enabled','device','channel','scopes'))
        if (type(value['enabled']) is not bool or not isinstance(value['device'],str)
                or not re.fullmatch(r'[a-f0-9]{32}',value['device'])
                or value['channel'] not in ('owner-test','friends')
                or not isinstance(value['scopes'],list)
                or any(s not in security.SCOPES for s in value['scopes'])
                or len(value['scopes'])!=len(set(value['scopes']))):
            raise security.Error('Enrollment state invalid; no changes allowed.')
        return value

    def enroll(self,channel,scopes):
        value=self.enrollment()
        if channel not in ('owner-test','friends') or not scopes or any(s not in security.SCOPES for s in scopes):
            raise security.Error('Invalid enrollment permissions.')
        value.update(enabled=True,channel=channel,scopes=sorted(set(scopes)))
        self.write('enrollment',value)
        return value

    def revoke(self):
        value=self.enrollment();value['enabled']=False
        self.write('enrollment',value)  # Sequence history and backups survive revocation.

    def water(self,channel):
        state=self.load('state',{'channels':{},'last_time':0})
        security.exact(state,('channels','last_time'))
        if not isinstance(state['channels'],dict) or type(state['last_time']) is not int:
            raise security.Error('Invalid version history.')
        value=state['channels'].get(channel,{'seen_sequence':0,'seen_digest':'','applied_sequence':0})
        security.exact(value,('seen_sequence','seen_digest','applied_sequence'))
        if (any(type(value[k]) is not int or value[k]<0 for k in ('seen_sequence','applied_sequence'))
                or not isinstance(value['seen_digest'],str)):
            raise security.Error('Invalid version history.')
        return dict(value,last_time=state['last_time'])

    def seen(self,channel,sequence,digest,now,applied=False):
        value=self.water(channel)
        if sequence<value['seen_sequence'] or sequence==value['seen_sequence'] and value['seen_digest']!=digest:
            raise security.Error('Version history changed concurrently.')
        value.update(seen_sequence=sequence,seen_digest=digest)
        value.pop('last_time')
        if applied:value['applied_sequence']=max(sequence,value['applied_sequence'])
        state=self.load('state',{'channels':{},'last_time':0})
        state['channels'][channel]=value;state['last_time']=max(now,state['last_time'])
        self.write('state',state)

    def pending(self):
        preparing=self.load('preparing')
        if preparing is not None:
            if not isinstance(preparing,dict) or preparing.get('state')!='preparing':
                raise security.Error('Preparation state damaged; retain files and use Recovery.')
            return True
        journal=self.load('journal')
        return journal and journal.get('state') not in ('complete','restored','cancelled')

    @contextlib.contextmanager
    def lock(self):
        # The process-start identity is in the directory name, so power loss
        # cannot leave an empty/part-written owner record with unknown origin.
        path=safe_path(os.path.join(self.root,'lease-'+self.boot))
        if self.leases():raise security.Error('Management lease exists. Restart Kodi and use Recovery if interrupted.')
        try:os.mkdir(path,0o700)
        except FileExistsError:
            raise security.Error('Management lease exists. If interrupted, restart Kodi and use Recovery.') from None
        try:yield
        finally:
            safe_path(path)
            os.rmdir(path)

    def leases(self):
        names=[n for n in os.listdir(self.root) if re.fullmatch(r'lease-[a-f0-9]{32}',n)]
        for name in names:
            path=safe_path(os.path.join(self.root,name))
            if not os.path.isdir(path) or os.listdir(path):raise security.Error('Unexpected lease contents; retain for manual review.')
        return names

    def recover_lease(self):
        for name in self.leases():
            if name=='lease-'+self.boot:
                raise security.Error('Same Kodi session may still own this lease. Restart Kodi normally first.')
            os.rename(safe_path(os.path.join(self.root,name)),
                      safe_path(os.path.join(self.root,'recovered-'+name+'-'+uuid.uuid4().hex)))
