"""Typed Kodi/filesystem operations. Network, review and trust are separate."""
import ast
import hashlib
import io
import os
import re
import shutil
import sys
import uuid
import zipfile
import xml.etree.ElementTree as ET

from resources.lib import bundle
from resources.lib import managed_security as security
from resources.lib.managed_store import safe_path

def process_identity():
    """Stable for one Kodi process, including independent addon interpreters."""
    if os.name=='nt':
        import ctypes
        from ctypes import wintypes
        times=[wintypes.FILETIME() for _ in range(4)]
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetCurrentProcess.restype=wintypes.HANDLE
        kernel.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
        if not kernel.GetProcessTimes(kernel.GetCurrentProcess(),*[ctypes.byref(t) for t in times]):
            raise security.Error('Cannot establish process ownership; no management changes allowed.')
        started=(times[0].dwHighDateTime<<32)|times[0].dwLowDateTime
    else:
        try:
            with open('/proc/self/stat',encoding='ascii') as stream:
                started=int(stream.read().rsplit(')',1)[1].split()[19])
        except (OSError,ValueError,IndexError):
            raise security.Error('Cannot establish Kodi process ownership; no changes allowed.') from None
    return hashlib.sha256((str(os.getpid())+':'+str(started)).encode('ascii')).hexdigest()[:32]

def same(a,b):return type(a) is type(b) and a==b

def digest_file(path):
    safe_path(path)
    if not os.path.isfile(path):return None
    with open(path,'rb') as stream:return hashlib.sha256(stream.read()).hexdigest()

def _keymap_policy_v1():
    """Exact owned keymap grammar; action text is executable Kodi input."""
    information='RunScript(special://home/addons/plugin.video.leanstream/resources/lib/gui/information_shortcut.py)'
    paging='RunScript(special://home/addons/plugin.video.leanstream/resources/lib/gui/settings_paging.py,{})'
    result={'leanstream-information.xml':{
        ('global','keyboard','i'):((),information)}}
    settings={}
    for window in ('playersettings','mediasettings','interfacesettings','servicesettings','systemsettings'):
        settings[(window,'keyboard','pageup')]=((),paging.format('up'))
        settings[(window,'keyboard','pagedown')]=((),paging.format('down'))
        settings[(window,'remote','pageplus')]=((),paging.format('up'))
        settings[(window,'remote','pageminus')]=((),paging.format('down'))
    result['leanstream-settings-paging.xml']=settings
    chapters={}
    keys={
        ('FullscreenVideo','keyboard'):(('up',()),('down',()),('pageup',()),('pagedown',()),
            ('next_track',()),('prev_track',()),('f',(('mod','ctrl'),))),
        ('FullscreenVideo','remote'):(('up',()),('down',()),('pageplus',()),('pageminus',()),
            ('skipplus',()),('skipminus',())),
        ('VideoOSD','keyboard'):(('period',()),('comma',()),('pageup',()),('pagedown',()),
            ('next_track',()),('prev_track',()),('f',(('mod','ctrl'),)),('b',(('mod','ctrl'),))),
        ('VideoOSD','remote'):(('pageplus',()),('pageminus',()),('skipplus',()),('skipminus',())),
        ('FullscreenInfo','keyboard'):(('comma',()),('pageup',()),('pagedown',()),
            ('next_track',()),('prev_track',()),('f',(('mod','ctrl'),)),('b',(('mod','ctrl'),))),
        ('FullscreenInfo','remote'):(('pageplus',()),('pageminus',()),('skipplus',()),('skipminus',()))}
    for (window,device),items in keys.items():
        for key,attributes in items:chapters[(window,device,key)]=(attributes,'noop')
    result['leanstream-no-chapters.xml']=chapters
    return result

KEYMAP_POLICY_V1=_keymap_policy_v1()

class Adapter:
    def __init__(self,ui):
        self.ui=ui;self.xbmc=ui.xbmc;self.addons=safe_path(ui.ADDONS)
        self.data=safe_path(os.path.join(ui.DATA,'management-v1'))
        self.keymaps=safe_path(os.path.join(ui.HOME,'userdata','keymaps'))
        self.platform='android' if self.xbmc.getCondVisibility('System.Platform.Android') else 'windows' if os.name=='nt' else 'unsupported'
        match=re.match(r'(\d+)',self.xbmc.getInfoLabel('System.BuildVersion'))
        self.kodi_major=int(match.group(1)) if match else 0
        self.stage=None;self.transaction=None;self.requirements={};self.abis={};self.planned={}
        self.expanded_total=0

    def rpc(self,method,params):
        import json
        value=security.read_json(self.xbmc.executeJSONRPC(json.dumps(
            {'jsonrpc':'2.0','id':5048,'method':method,'params':params})).encode('utf8'),max_size=8*1024*1024)
        if value.get('id')!=5048 or 'error' in value or 'result' not in value:
            raise security.Error('Kodi rejected the requested operation. No account reset is needed.')
        return value['result']

    def assert_idle(self,operations):
        if self.kodi_major!=21 or self.platform not in ('android','windows'):
            raise security.Error('This management core supports Kodi21 on Shield/Windows only.')
        if self.xbmc.Player().isPlaying():raise security.Error('Stop playback and previews before maintenance.')
        self.planned={op['addon_id']:op['version'] for op in operations if op['op']=='package.install'}
        for op in operations:
            if op['op']=='package.install' and op['addon_id'] in (bundle.PLUGIN,bundle.SKIN):
                if self.xbmc.getSkinDir()==bundle.SKIN:
                    raise security.Error('Choose Estuary locally and leave LeanStream before a suite code update. Your personal settings are preserved.')
            if op['op']=='addon.enabled' and op['addon_id']==self.xbmc.getSkinDir():
                raise security.Error('The active skin cannot be disabled.')
        if any(test(self.ui.DATA) for test in (
                self.ui.scrape_setup.interrupted,self.ui.android_playback.interrupted,
                self.ui.trailer_setup.interrupted)):
            raise security.Error('Recover interrupted legacy preference changes before applying a managed job.')
        old=bundle.last_backup(self.ui.DATA)
        if old and old.get('state')=='pending':raise security.Error('Recover interrupted legacy suite code first.')
        old=self.ui.self_update.state(self.ui.DATA)
        if old and old.get('state')=='pending':raise security.Error('Recover interrupted legacy updater code first.')

    def begin(self,transaction):
        if not isinstance(transaction,str) or not re.fullmatch(r'[a-f0-9]{32}',transaction):
            raise security.Error('Invalid transaction identity.')
        self.transaction=transaction
        self.stage=safe_path(os.path.join(self.addons,'.leanstream-managed-'+transaction))
        os.mkdir(self.stage)
        for name in ('payload','before','previous','retired'):os.mkdir(os.path.join(self.stage,name))
        # Verified code/keymap rollback is retained for the current completed
        # job. Cancelled and superseded stages are removed only through the
        # guarded transaction lifecycle below; profile credentials are absent.

    @staticmethod
    def _record(record,states):
        security.exact(record,('schema','transaction','job','sequence','channel','digest',
                               'state','steps','requires_restart'))
        transaction=record['transaction']
        if (record['schema']!=1 or not isinstance(transaction,str)
                or not re.fullmatch(r'[a-f0-9]{32}',transaction)
                or record['state'] not in states or not isinstance(record['steps'],list)
                or len(record['steps'])>security.MAX_OPERATIONS):
            raise security.Error('Invalid managed transaction record.')
        return transaction

    def _stage_for(self,transaction):
        path=safe_path(os.path.join(self.addons,'.leanstream-managed-'+transaction))
        if (os.path.normcase(os.path.dirname(path))!=os.path.normcase(self.addons)
                or os.path.basename(path)!='.leanstream-managed-'+transaction):
            raise security.Error('Managed staging path escaped its owner directory.')
        return path

    @staticmethod
    def _guard_tree(path):
        safe_path(path)
        if not os.path.exists(path):return
        if not os.path.isdir(path) or bundle.is_link(path):
            raise security.Error('Managed staging contains a link or non-directory.')
        for root,dirs,files in os.walk(path):
            if bundle.is_link(root):raise security.Error('Managed staging contains a link.')
            for name in dirs+files:
                if bundle.is_link(os.path.join(root,name)):
                    raise security.Error('Managed staging contains a link.')

    def _remove_stage(self,transaction,preparing=False):
        path=self._stage_for(transaction)
        if not os.path.exists(path):return
        self._guard_tree(path)
        allowed={'payload','before','previous','retired'}
        entries=set(os.listdir(path))
        if not entries.issubset(allowed):
            raise security.Error('Unexpected managed staging contents; retain for review.')
        if preparing:
            for name in ('previous','retired'):
                area=os.path.join(path,name)
                if os.path.exists(area) and (not os.path.isdir(area) or os.listdir(area)):
                    raise security.Error('Preparation may already have changed live code; retain for Recovery.')
        shutil.rmtree(path)
        if os.path.exists(path):raise security.Error('Managed staging cleanup did not complete.')
        if self.transaction==transaction:self.stage=None;self.transaction=None

    def abort_prepared(self,record):
        transaction=self._record(record,('preparing',))
        for step in record['steps']:
            if not isinstance(step,dict) or step.get('state')!='prepared':
                raise security.Error('Preparation record may contain a live mutation; retain for Recovery.')
        self._remove_stage(transaction,preparing=True)

    def release_finalized(self,record):
        transaction=self._record(record,('complete','restored','cancelled'))
        self._remove_stage(transaction)

    def prune_archived(self,records,current_transaction):
        for record in records:
            if record.get('transaction')!=current_transaction:self.release_finalized(record)

    def resume(self,journal):
        security.exact(journal,('schema','transaction','job','sequence','channel','digest',
                                'state','steps','requires_restart'))
        transaction=journal['transaction']
        if journal['schema']!=1 or not isinstance(transaction,str) or not re.fullmatch(r'[a-f0-9]{32}',transaction):
            raise security.Error('Invalid recovery journal.')
        if not isinstance(journal['steps'],list) or len(journal['steps'])>security.MAX_OPERATIONS:
            raise security.Error('Invalid recovery step count.')
        self.transaction=transaction;self.stage=safe_path(os.path.join(self.addons,'.leanstream-managed-'+transaction))
        if not os.path.isdir(self.stage):raise security.Error('Recovery staging/backup missing. Preserve remaining files.')
        for step in journal['steps']:
            security.operation(step['op'])
            if step.get('state') not in ('prepared','applying','applied','restoring','restored') or type(step.get('skip')) is not bool:
                raise security.Error('Invalid recovery step state.')

    def compact_applied(self,journal):
        transaction=self._record(journal,('pending',))
        if self.transaction!=transaction or self.stage!=self._stage_for(transaction):
            raise security.Error('Managed staging identity changed before completion.')
        for step in journal['steps']:
            security.operation(step['op'])
            if step.get('skip'):
                if step.get('state')!='prepared' or not self.precondition(step):
                    raise security.Error('Skipped target changed before staged copies could be released.')
                kind=step['op']['op']
                if kind in ('package.install','keymap.install'):
                    name=step['op']['addon_id'] if kind=='package.install' else step['op']['name']
                    payload=self.area('payload',name);backup=self.area('before',name)
                    read=bundle.tree_digest if kind=='package.install' else digest_file
                    for path,expected in ((payload,step['after']),(backup,step['before'])):
                        if not os.path.lexists(path):continue
                        if kind=='package.install':
                            self._guard_tree(path)
                        else:
                            safe_path(path)
                            if not os.path.isfile(path) or bundle.is_link(path):
                                raise security.Error('Skipped staged keymap is unsafe; retain transaction for Recovery.')
                        if expected is None or read(path)!=expected:
                            raise security.Error('Skipped staged copy changed; retain transaction for Recovery.')
                        if kind=='package.install':shutil.rmtree(path)
                        else:
                            os.unlink(path)
                        if os.path.exists(path):
                            raise security.Error('Skipped staged copy cleanup did not complete.')
                    if not self.precondition(step):
                        raise security.Error('Skipped target changed during staged copy cleanup.')
                continue
            if step.get('state')!='applied' or not self.postcondition(step):
                raise security.Error('Cannot compact rollback data before verified application.')
            if step['op']['op']!='package.install':continue
            name=step['op']['addon_id'];previous=self.area('previous',name)
            if step['before'] is None:
                if os.path.exists(previous):raise security.Error('Unexpected old package tree retained.')
                continue
            backup=self.area('before',name)
            if (not os.path.isdir(backup) or bundle.tree_digest(backup)!=step['before']
                    or not os.path.isdir(previous) or bundle.tree_digest(previous)!=step['before']):
                raise security.Error('Verified rollback copy changed; retain transaction for Recovery.')
            self._guard_tree(previous);shutil.rmtree(previous)
        previous_root=os.path.join(self.stage,'previous')
        if os.path.isdir(previous_root) and os.listdir(previous_root):
            raise security.Error('Unexpected duplicate old package tree retained.')

    def target(self,addon_id):
        security.addon_id(addon_id)
        path=safe_path(os.path.join(self.addons,addon_id))
        if os.path.exists(path) and not os.path.isdir(path):raise security.Error('Addon target is not a directory.')
        return path

    def area(self,kind,name):
        if kind not in ('payload','before','previous','retired'):raise security.Error('Unknown transaction area.')
        if not self.stage:raise security.Error('Transaction staging not established.')
        security.identifier(name)
        return safe_path(os.path.join(self.stage,kind,name))

    def validate_keymap(self,op,raw):
        expected=KEYMAP_POLICY_V1.get(op['name'])
        if expected is None or not isinstance(raw,bytes) or len(raw)>65536 or b'<!DOCTYPE' in raw.upper():
            raise security.Error('Unsafe keymap XML.')
        try:root=ET.fromstring(raw)
        except ET.ParseError:raise security.Error('Invalid keymap XML.') from None
        if root.tag!='keymap' or root.attrib or (root.text or '').strip() or (root.tail or '').strip():
            raise security.Error('Keymap structure is not the reviewed LeanStream template.')
        observed={};details=[]
        for window in root:
            if (window.attrib or (window.text or '').strip() or (window.tail or '').strip()
                    or not isinstance(window.tag,str)):
                raise security.Error('Keymap structure is not the reviewed LeanStream template.')
            for device in window:
                if (device.attrib or (device.text or '').strip() or (device.tail or '').strip()
                        or not isinstance(device.tag,str)):
                    raise security.Error('Keymap structure is not the reviewed LeanStream template.')
                for key in device:
                    if list(key) or (key.tail or '').strip() or not isinstance(key.tag,str):
                        raise security.Error('Keymap structure is not the reviewed LeanStream template.')
                    path=(window.tag,device.tag,key.tag)
                    if path in observed:raise security.Error('Duplicate keymap binding.')
                    attributes=tuple(sorted(key.attrib.items()));action=key.text or ''
                    if action!=action.strip():
                        raise security.Error('Keymap action text is not an exact reviewed literal.')
                    observed[path]=(attributes,action)
                    label='/'.join(path)
                    if attributes:label+='['+','.join(k+'='+v for k,v in attributes)+']'
                    details.append(label+' -> '+action)
        if observed!=expected:
            raise security.Error('Keymap differs from the reviewed LeanStream template.')
        return details

    @staticmethod
    def _schema_integer(value):
        if not isinstance(value,str) or not re.fullmatch(r'-?(?:0|[1-9][0-9]*)',value):
            raise security.Error('Addon setting integer schema is not exact.')
        return int(value)

    def validate_kodi_setting_row(self,row,op):
        kind,policy=security.kodi_setting_policy(op['id'])
        expected='boolean' if kind=='boolean' else 'integer'
        if not isinstance(row,dict) or row.get('id')!=op['id'] or row.get('type')!=expected:
            raise security.Error('Kodi setting schema differs from reviewed policy.')
        sources=[row]
        for name in ('constraints','control'):
            value=row.get(name)
            if value is not None:
                if not isinstance(value,dict):raise security.Error('Kodi setting constraints are unreadable.')
                sources.append(value)
        for source in sources:
            if source.get('enabled') is False or any(
                    re.sub(r'[^a-z]','',str(name).lower())=='readonly' and value not in (False,0,None,'false','0')
                    for name,value in source.items()):
                raise security.Error('Disabled or read-only Kodi setting cannot be managed.')
        values={}
        for name in ('minimum','maximum','step'):
            found=[source[name] for source in sources if name in source]
            if found:
                if any(type(value) is not int for value in found) or len(set(found))!=1:
                    raise security.Error('Kodi setting constraints are not exact integers.')
                values[name]=found[0]
        if any('options' in source and source['options'] not in (None,[]) for source in sources):
            raise security.Error('Kodi setting unexpectedly exposes option values.')
        if kind=='boolean' and values:
            raise security.Error('Boolean Kodi setting unexpectedly has numeric constraints.')
        if kind=='range' and ('step' in values and values['step']<=0
                or 'minimum' in values and 'maximum' in values and values['minimum']>values['maximum']):
            raise security.Error('Kodi setting constraints are invalid.')
        return kind,policy,values

    @staticmethod
    def validate_kodi_row_value(policy,constraints,value):
        minimum,maximum,step=policy
        actual_min=constraints.get('minimum',minimum)
        actual_max=constraints.get('maximum',maximum)
        actual_step=constraints.get('step',step)
        base=constraints.get('minimum',minimum)
        if not actual_min<=value<=actual_max or (value-base)%actual_step:
            raise security.Error('Kodi setting value conflicts with installed constraints.')

    def validate_addon_setting_schema(self,node,op):
        kind,policy=security.addon_setting_policy(op['addon_id'],op['id'])
        expected_type='boolean' if kind=='boolean' else 'integer'
        if node is None or node.get('type')!=expected_type:
            raise security.Error('Addon setting schema differs from its reviewed type.')
        levels=node.findall('level');expected_level=security.ADDON_SETTING_LEVELS_V1[op['id']]
        if (len(levels)!=1 or levels[0].attrib or list(levels[0])
                or not re.fullmatch(r'(?:0|[1-9][0-9]*)',levels[0].text or '')
                or int(levels[0].text)!=expected_level):
            raise security.Error('Addon setting level differs from reviewed policy.')
        for element in node.iter():
            if (re.sub(r'[^a-z]','',str(element.tag).lower())=='readonly'
                    or any(re.sub(r'[^a-z]','',name.lower())=='readonly'
                           for name in element.attrib)):
                raise security.Error('Read-only addon settings cannot be managed.')
        if (node.findtext('enable') or '').strip().lower()=='false':
            raise security.Error('Disabled addon settings cannot be managed.')
        control=node.find('control')
        if control is None or control.findtext('hidden')=='true':
            raise security.Error('Hidden or control-less addon fields cannot be managed.')
        constraints=node.find('constraints')
        if kind=='boolean':
            if constraints is not None or control.get('type')!='toggle':
                raise security.Error('Boolean addon setting schema differs from reviewed policy.')
            return kind
        if constraints is None:
            if op['id'] not in security.VIEW_ID_SETTINGS_V1 or control.get('type')!='edit':
                raise security.Error('Integer addon setting constraints are missing.')
            return kind
        if constraints.attrib:
            raise security.Error('Integer addon setting constraints are not exact.')
        children=[child.tag for child in constraints]
        if kind=='enum':
            if children!=['options'] or control.get('type')!='spinner':
                raise security.Error('Addon setting options differ from reviewed policy.')
            options=constraints.find('options')
            if options.attrib or any(option.tag!='option' for option in options):
                raise security.Error('Addon setting options differ from reviewed policy.')
            try:actual=tuple(self._schema_integer(option.text or '') for option in options)
            except TypeError:raise security.Error('Addon setting options are unreadable.') from None
            if actual!=policy:
                raise security.Error('Addon setting options differ from reviewed policy.')
            return kind
        if op['id'] in security.VIEW_ID_SETTINGS_V1:
            raise security.Error('View ID schema unexpectedly gained constraints.')
        allowed={'minimum','maximum'}|({'step'} if op['id'] in security.EXPLICIT_RANGE_STEPS_V1 else set())
        if len(children)!=len(allowed) or set(children)!=allowed or control.get('type')!='slider':
            raise security.Error('Addon setting range differs from reviewed policy.')
        minimum=self._schema_integer(constraints.findtext('minimum'))
        maximum=self._schema_integer(constraints.findtext('maximum'))
        step=self._schema_integer(constraints.findtext('step')) if 'step' in children else 1
        if (minimum,maximum,step)!=policy:
            raise security.Error('Addon setting range differs from reviewed policy.')
        return kind

    def setting(self,op,value=None,write=False):
        security.setting_id(op['id'],op['op']=='addon.setting',op.get('addon_id'))
        proposed=op['value'] if value is None else value
        if op['op']=='kodi.setting':
            rows=self.rpc('Settings.GetSettings',{'level':'expert'}).get('settings',[])
            if not isinstance(rows,list):raise security.Error('Kodi setting schema list is unreadable.')
            row=next((r for r in rows if isinstance(r,dict) and r.get('id')==op['id']),None)
            kind,policy,constraints=self.validate_kodi_setting_row(row,op)
            security.kodi_setting_value(op['id'],proposed)
            if kind=='range':self.validate_kodi_row_value(policy,constraints,proposed)
            current=self.rpc('Settings.GetSettingValue',{'setting':op['id']})['value']
            security.kodi_setting_value(op['id'],current)
            if kind=='range':self.validate_kodi_row_value(policy,constraints,current)
            if write:
                if self.rpc('Settings.SetSettingValue',{'setting':op['id'],'value':proposed}) is not True:
                    raise security.Error('Kodi refused the setting value.')
                actual=self.rpc('Settings.GetSettingValue',{'setting':op['id']})['value']
                security.kodi_setting_value(op['id'],actual)
                if kind=='range':self.validate_kodi_row_value(policy,constraints,actual)
                if not same(actual,proposed):raise security.Error('Kodi setting readback mismatch.')
            return current
        addon=self.ui.xbmcaddon.Addon(op['addon_id'])
        path=addon.getAddonInfo('path')
        raw=self.ui.read_core(os.path.join(path,'resources','settings.xml'),bundle.MAX_DEPENDENCY_XML+1)
        if len(raw)>bundle.MAX_DEPENDENCY_XML:raise security.Error('Addon settings metadata is too large.')
        try:node=ET.fromstring(raw).find('.//setting[@id="'+op['id']+'"]')
        except ET.ParseError:raise security.Error('Addon setting schema unreadable.') from None
        kind=self.validate_addon_setting_schema(node,op)
        security.addon_setting_value(op['addon_id'],op['id'],proposed)
        settings=addon.getSettings()
        suffix='Bool' if kind=='boolean' else 'Int'
        getter=getattr(settings,'get'+suffix)
        current=getter(op['id']);security.addon_setting_value(op['addon_id'],op['id'],current)
        if write:
            # Kodi20+ Settings setters are void (None in Python), unlike the
            # deprecated Addon.setSettingBool APIs. Verify the actual value.
            getattr(settings,'set'+suffix)(op['id'],proposed)
            actual=getter(op['id']);security.addon_setting_value(op['addon_id'],op['id'],actual)
            if not same(actual,proposed):
                raise security.Error('Addon rejected the typed setting value.')
        return current

    @staticmethod
    def type_check(typ,value):
        types={'boolean':(bool,),'integer':(int,),'number':(float,int),'string':(str,)}
        security.scalar(value)
        if type(value) not in types[typ]:raise security.Error('Setting type mismatch; no implicit conversion.')

    def enabled(self,addon_id,value=None):
        security.addon_id(addon_id)
        def registered():
            rows=self.rpc('Addons.GetAddons',{'installed':True,'enabled':'all','properties':['enabled']}).get('addons',[])
            return addon_id in {r['addonid'] for r in rows}
        if not registered():
            if value is None or value is False:return False
            if addon_id not in self.planned:raise security.Error('Install the addon first, or include its signed package before enabling it.')
            self.xbmc.executebuiltin('UpdateLocalAddons',True)
            import time
            deadline=time.monotonic()+10
            while not registered():
                if time.monotonic()>deadline:raise security.Error('Kodi addon registration timed out; use Recovery.')
                self.xbmc.sleep(100)
        row=self.rpc('Addons.GetAddonDetails',{'addonid':addon_id,'properties':['enabled','path']})['addon']
        # Built-in/platform modules and external addon locations are not code
        # owned by this updater. Never disable Kodi's bundled crypto or itself.
        path=safe_path(row['path'])
        if os.path.normcase(path.rstrip('/\\'))!=os.path.normcase(self.target(addon_id)):
            raise security.Error('Built-in or externally located addons require local administration.')
        if value is not None:
            if addon_id==self.xbmc.getSkinDir() or addon_id==bundle.SELF_ID:
                raise security.Error('Cannot disable the active skin or updater.')
            result=self.rpc('Addons.SetAddonEnabled',{'addonid':addon_id,'enabled':value})
            if result!='OK':raise security.Error('Kodi refused the addon state change.')
        return row['enabled']

    def package(self,op,raw):
        addon_id=op['addon_id'];target=self.target(addon_id)
        registered=self.rpc('Addons.GetAddons',{'installed':True,'enabled':'all','properties':['enabled']}).get('addons',[])
        if addon_id in {row['addonid'] for row in registered}:
            actual=self.ui.xbmcaddon.Addon(addon_id).getAddonInfo('path')
            actual=self.ui.xbmcvfs.translatePath(actual) if hasattr(self.ui,'xbmcvfs') else actual
            if os.path.normcase(os.path.abspath(actual).rstrip('/\\'))!=os.path.normcase(target):
                raise security.Error('Do not shadow a built-in or externally located addon with a managed package.')
        payload=self.area('payload',addon_id)
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                entries=archive.infolist()
                if not entries or len(entries)>10000 or sum(e.file_size for e in entries)>bundle.MAX_EXPANDED:
                    raise security.Error('Package expanded size/count exceeds limits.')
                self.expanded_total+=sum(e.file_size for e in entries)
                if self.expanded_total>512*1024*1024:raise security.Error('Combined expanded package size exceeds limits.')
                seen=set()
                for entry in entries:
                    name=bundle._safe_member(entry,addon_id)
                    if name in seen:raise security.Error('Duplicate or case-colliding ZIP path.')
                    seen.add(name)
                    if entry.orig_filename.lower().endswith(('.dll','.pyd','.so','.dylib','.exe','.bat','.cmd','.ps1','.vbs','.sh')):
                        raise security.Error('Native binaries/shell scripts must use Kodi/platform installers.')
                    if not entry.is_dir():
                        contents=archive.read(entry)
                        if entry.orig_filename.endswith('.xml') and b'<!DOCTYPE' in contents.upper():
                            raise security.Error('XML document types/entities are not allowed in managed packages.')
                        private_marker=rb'BEG'+rb'IN [A-Z ]*PRIVATE KEY'
                        if re.search(rb'github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|'+private_marker,contents):
                            raise security.Error('Credential-like material found in package.')
                        if entry.orig_filename.endswith('.py'):ast.parse(contents,feature_version=(3,8))
                metadata=archive.read(addon_id+'/addon.xml')
                if len(metadata)>bundle.MAX_DEPENDENCY_XML:raise security.Error('Addon metadata exceeds the safe size.')
                root=ET.fromstring(metadata)
                if root.get('id')!=addon_id or root.get('version')!=op['version']:
                    raise security.Error('Signed package identity/version mismatch.')
                reqs=bundle.declared_requirements(archive.read(addon_id+'/addon.xml'))
                if addon_id==bundle.SKIN:
                    if not any(e.get('point')=='xbmc.gui.skin' for e in root.findall('extension')):
                        raise security.Error('Owned skin extension missing.')
                elif not any(r.id=='xbmc.python' for r in reqs):
                    raise security.Error('Only declared Python addons or the owned skin can be installed.')
                if addon_id==bundle.PLUGIN:bundle.validate_ai(lambda n:archive.read(addon_id+'/'+n))
                if addon_id==bundle.SELF_ID:
                    if not any(r.id=='script.module.pycryptodome' and r.required for r in reqs):
                        raise security.Error('Core upgrade lost its declared crypto dependency.')
                    if not any(n.endswith('/resources/trust-root.json') for n in seen):
                        raise security.Error('Core upgrade missing pinned trust.')
                    new_root=security.read_json(archive.read(addon_id+'/resources/trust-root.json'))
                    security.root_schema(new_root)
                    if new_root!=getattr(self,'trusted_root',None):
                        raise security.Error('Rotate trust with a cross-signed root first; a core package cannot silently reset it.')
                if archive.testzip():raise security.Error('Corrupt package.')
                archive.extractall(self.area('payload',addon_id).rsplit(os.sep,1)[0])
        except (zipfile.BadZipFile,KeyError,ET.ParseError,SyntaxError,UnicodeError):
            raise security.Error('Malformed or incompatible package; nothing installed.') from None
        self.requirements[addon_id]=reqs;self.abis[addon_id]=bundle.addon_abi(root)
        after=bundle.tree_digest(payload)
        before=bundle.tree_digest(target) if os.path.isdir(target) else None
        if before is not None:
            installed=ET.parse(os.path.join(target,'addon.xml')).getroot()
            if installed.get('id')!=addon_id or bundle.ver(installed.get('version',''))>bundle.ver(op['version']):
                raise security.Error('Package would downgrade or replace an unexpected addon.')
            if installed.get('version')==op['version'] and before!=after:
                raise security.Error('Same-version code differs; publish a new package version.')
            backup=self.area('before',addon_id)
            shutil.copytree(target,backup,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.pyo'))
            if bundle.tree_digest(backup)!=before:raise security.Error('Code backup verification failed.')
        return before,after

    def prepare(self,op,raw=None):
        security.operation(op);kind=op['op'];impact='';mappings=None
        if kind=='package.install':before,after=self.package(op,raw)
        elif kind=='keymap.install':
            mappings=self.validate_keymap(op,raw)
            target=safe_path(os.path.join(self.keymaps,op['name']))
            before=digest_file(target);after=hashlib.sha256(raw).hexdigest()
            with open(self.area('payload',op['name']),'xb') as stream:stream.write(raw)
            if before is not None:
                shutil.copy2(target,self.area('before',op['name']))
                if digest_file(self.area('before',op['name']))!=before:raise security.Error('Keymap backup failed.')
        elif kind=='addon.enabled':
            before=self.enabled(op['addon_id']);after=op['value']
            if after and not os.path.isdir(self.target(op['addon_id'])) and op['addon_id'] not in self.planned:
                raise security.Error('Enabling a missing addon requires its signed package in this job.')
            rows=self.rpc('Addons.GetAddons',{'installed':True,'enabled':True,'properties':['dependencies']}).get('addons',[])
            users=[r['addonid'] for r in rows if any(d['addonid']==op['addon_id'] and not d.get('optional',False)
                                                    for d in r.get('dependencies',[]))]
            if not after and users:impact='Dependent features may stop until re-enabled: '+', '.join(users)
        else:before=self.setting(op);after=op['value']
        matched=op.get('when','any')=='any' or any(same(before,v) for v in op['when'])
        result={'op':op,'before':before,'after':after,'skip':not matched or same(before,after),
                'state':'prepared','impact':impact}
        if mappings is not None:result['mappings']=mappings
        return result

    def validate_prepared(self,steps):
        for addon_id,requirements in self.requirements.items():
            rows=self.ui.requirement_rows(requirements,self.planned,self.abis)
            if any(row['required'] and row['status']!='OK' for row in rows):
                raise security.Error('Required Kodi dependency is missing/incompatible. Install it natively, then review this job again.')

    def current(self,step):
        op=step['op'];kind=op['op']
        if kind=='package.install':
            target=self.target(op['addon_id'])
            return bundle.tree_digest(target) if os.path.isdir(target) else None
        if kind=='keymap.install':return digest_file(safe_path(os.path.join(self.keymaps,op['name'])))
        if kind=='addon.enabled':return self.enabled(op['addon_id'])
        return self.setting(op)

    def precondition(self,step):return same(self.current(step),step['before'])
    def postcondition(self,step):return same(self.current(step),step['after'])

    def apply(self,step):
        op=step['op'];kind=op['op']
        if kind=='package.install':
            target=self.target(op['addon_id']);payload=self.area('payload',op['addon_id'])
            if bundle.tree_digest(payload)!=step['after']:raise security.Error('Staged package changed.')
            if os.path.isdir(target):os.rename(target,self.area('previous',op['addon_id']))
            os.rename(payload,target)
        elif kind=='keymap.install':
            os.makedirs(self.keymaps,exist_ok=True)
            payload=self.area('payload',op['name'])
            if digest_file(payload)!=step['after']:raise security.Error('Staged keymap changed.')
            os.replace(payload,safe_path(os.path.join(self.keymaps,op['name'])))
        elif kind=='addon.enabled':self.enabled(op['addon_id'],step['after'])
        else:self.setting(op,step['after'],write=True)

    def intermediate(self,step):
        # Proven power loss between the two directory renames. A random missing
        # target is not enough: the moved original must still match the backup.
        kind=step['op']['op']
        if self.current(step) is not None:return False
        if kind=='package.install' and step['state']=='applying':
            previous=self.area('previous',step['op']['addon_id'])
            return step['before'] is not None and os.path.isdir(previous) and bundle.tree_digest(previous)==step['before']
        if kind in ('package.install','keymap.install') and step['state']=='restoring':
            name=step['op'].get('addon_id',step['op'].get('name'))
            retired=self.area('retired','changed-'+name)
            ready=self.area('retired','restore-'+name)
            read=bundle.tree_digest if kind=='package.install' else digest_file
            if not os.path.exists(retired) or read(retired)!=step['after']:return False
            return step['before'] is None or os.path.exists(ready) and read(ready)==step['before']
        return False

    def can_restore(self,step):
        if step['skip'] or step['state']=='prepared':return True
        current=self.current(step)
        if step['op']['op'] in ('package.install','keymap.install') and step['before'] is not None and not same(current,step['before']):
            name=step['op'].get('addon_id',step['op'].get('name'));backup=self.area('before',name)
            if not os.path.exists(backup):return False
            read=bundle.tree_digest if step['op']['op']=='package.install' else digest_file
            if read(backup)!=step['before']:return False
        return same(current,step['before']) or same(current,step['after']) or self.intermediate(step)

    def restore(self,step):
        if same(self.current(step),step['before']):return
        op=step['op'];kind=op['op']
        if kind in ('package.install','keymap.install'):
            name=op['addon_id'] if kind=='package.install' else op['name']
            backup=self.area('before',name)
            if step['before'] is not None:
                actual=bundle.tree_digest(backup) if kind=='package.install' else digest_file(backup)
                if actual!=step['before']:raise security.Error('Verified rollback data changed or missing.')
            target=self.target(name) if kind=='package.install' else safe_path(os.path.join(self.keymaps,name))
            restore_path=self.area('retired','restore-'+name)
            if step['before'] is not None:
                if os.path.exists(restore_path):
                    read=bundle.tree_digest if kind=='package.install' else digest_file
                    if read(restore_path)!=step['before']:raise security.Error('Staged rollback changed.')
                elif kind=='package.install':shutil.copytree(backup,restore_path)
                else:shutil.copy2(backup,restore_path)
            if os.path.exists(target):os.rename(target,self.area('retired','changed-'+name))
            if step['before'] is not None:os.rename(restore_path,target)
        elif kind=='addon.enabled':self.enabled(op['addon_id'],step['before'])
        else:self.setting(op,step['before'],write=True)
        if not same(self.current(step),step['before']):raise security.Error('Rollback readback failed.')

    def finish(self,journal):
        if any(s['op']['op']=='package.install' for s in journal['steps']):
            self.xbmc.executebuiltin('UpdateLocalAddons')
        if any(s['op']['op']=='keymap.install' for s in journal['steps']):
            self.xbmc.executebuiltin('Action(reloadkeymaps)')
