"""Review-before-apply jobs with durable intents and conditional rollback."""
import hashlib
import time
import uuid

from resources.lib import managed_security as security

class Cancelled(security.Error):
    pass

class Manager:
    def __init__(self,store,adapter,root,verify=security.verify_pss,clock=time.time):
        self.store=store;self.adapter=adapter;self.root=root;self.verify=verify;self.clock=clock
        self.adapter.trusted_root=root

    def _abort_prepared(self,journal):
        try:self.adapter.abort_prepared(journal)
        except Exception:
            raise security.Error('Preparation cleanup needs Recovery; retained files were not trusted for deletion.') from None
        self.store.clear_preparing(journal['transaction'])

    @staticmethod
    def _same_intent(preparing,journal):
        fields=('schema','transaction','job','sequence','channel','digest')
        return all(preparing.get(name)==journal.get(name) for name in fields)

    def _prune_archived(self,current):
        self.adapter.prune_archived(self.store.archived_finalized(),current['transaction'])

    def accept(self,raw):
        if self.store.pending():raise security.Error('Recover the interrupted job before checking another update.')
        enrollment=self.store.enrollment();now=int(self.clock())
        payload=security.signed(raw,self.root,now,verify=self.verify)
        channel=enrollment['channel']
        digest,artifacts=security.validate_job(payload,enrollment,self.adapter.platform,
            self.adapter.kodi_major,now,self.store.water(channel))
        return payload,digest,artifacts

    def apply(self,raw,fetch,approve,cancelled=lambda:False):
        # Reverify inside the exclusive lease, including permissions and expiry;
        # the review dialog can remain open for an arbitrary time.
        payload,digest,artifacts=self.accept(raw)
        with self.store.lock():
            if self.store.pending():raise security.Error('Another job needs recovery.')
            transaction=uuid.uuid4().hex
            journal={'schema':1,'transaction':transaction,'job':payload['id'],
                'sequence':payload['sequence'],'channel':payload['target']['channel'],
                'digest':digest,'state':'preparing','steps':[],'requires_restart':False}
            self.adapter.assert_idle(payload['operations'])
            downloaded={}
            for name,item in artifacts.items():
                if cancelled():raise Cancelled('Cancelled before changing Kodi.')
                data=fetch(name,item['size'])
                if (not isinstance(data,bytes) or len(data)!=item['size']
                        or hashlib.sha256(data).hexdigest()!=item['sha256']):
                    raise security.Error('Signed artifact size/hash mismatch. Nothing installed.')
                downloaded[name]=data
            # Keymap text is executable Kodi input.  Its complete, filename-
            # specific grammar is validated before staging creates any files.
            for op in payload['operations']:
                if op['op']=='keymap.install':
                    self.adapter.validate_keymap(op,downloaded[op['artifact']['filename']])
            # The separate durable marker preserves the previous completed
            # rollback throughout review. It is written before begin(), so a
            # crash during even partial stage creation remains discoverable.
            self.store.write('preparing',journal)
            try:
                self.adapter.begin(transaction)
                for op in payload['operations']:
                    if cancelled():raise Cancelled('Cancelled before changing Kodi.')
                    step=self.adapter.prepare(op,downloaded.get(op.get('artifact',{}).get('filename')))
                    journal['steps'].append(step);self.store.write('preparing',journal)
                self.adapter.validate_prepared(journal['steps'])
                if not approve(payload,journal['steps']):
                    self._abort_prepared(journal);return 'cancelled'
                now=int(self.clock())
                security.signed(raw,self.root,now,verify=self.verify)
                current=self.store.enrollment()
                security.validate_job(payload,current,self.adapter.platform,self.adapter.kodi_major,
                                      now,self.store.water(current['channel']))
                for step in journal['steps']:
                    if not self.adapter.precondition(step):
                        raise security.Error('A reviewed value changed. Review a fresh plan; nothing applied.')
                if cancelled():raise Cancelled('Cancelled before changing Kodi.')
                self.store.seen(journal['channel'],payload['sequence'],digest,now)
                journal['state']='pending'
                try:self.store.write('journal',journal)
                except Exception:
                    journal['state']='preparing'
                    raise
            except Exception:
                if journal['state']=='preparing':self._abort_prepared(journal)
                raise
            try:
                # Once pending is durable, the previous rollback is archived;
                # stale finalized stages can now be removed safely.
                self.store.clear_preparing(transaction)
                self._prune_archived(journal)
                for step in journal['steps']:
                    if step['skip']:continue
                    if cancelled():raise Cancelled('Cancelled after partial changes; use Recovery.')
                    self.adapter.assert_idle(payload['operations'])
                    if not self.adapter.precondition(step):raise security.Error('Target changed during update. Use Recovery.')
                    step['state']='applying';self.store.write('journal',journal)
                    self.adapter.apply(step)
                    if not self.adapter.postcondition(step):raise security.Error('Readback failed. Use Recovery.')
                    step['state']='applied';self.store.write('journal',journal)
                    journal['requires_restart'] |= step['op']['op'] in ('package.install','keymap.install')
                self.adapter.compact_applied(journal)
                self.store.seen(journal['channel'],payload['sequence'],digest,int(self.clock()),applied=True)
                journal['state']='complete';self.store.write('journal',journal)
                self.adapter.finish(journal)
                return 'complete'
            except Exception:
                journal['state']='recovery_required';self.store.write('journal',journal)
                raise security.Error('Job interrupted. Verified backups retained; use Recovery before another job.') from None

    def restore(self,approve,cancelled=lambda:False):
        self.store.recover_lease()
        with self.store.lock():
            preparing=self.store.load('preparing')
            journal=self.store.load('journal')
            if preparing is not None:
                if not isinstance(preparing,dict) or preparing.get('state')!='preparing':
                    raise security.Error('Preparation state damaged; retain files for manual review.')
                if journal and preparing.get('transaction')==journal.get('transaction'):
                    if (not self._same_intent(preparing,journal)
                            or journal.get('state') not in ('pending','recovery_required','restoring','complete','restored')):
                        raise security.Error('Preparation and recovery records disagree; retain files for manual review.')
                    # Pending is authoritative: never delete its rollback stage.
                    self.store.clear_preparing(preparing['transaction'])
                else:
                    if journal and journal.get('state') not in ('complete','restored','cancelled'):
                        raise security.Error('Two different jobs need recovery; retain both for manual review.')
                    self._abort_prepared(preparing)
                    return 'cancelled'
            if not journal or journal.get('state') in ('restored','cancelled'):
                raise security.Error('No managed job to restore.')
            self.adapter.resume(journal)
            self.adapter.assert_idle([s['op'] for s in journal['steps']])
            conflicts=[i for i,s in enumerate(journal['steps']) if not self.adapter.can_restore(s)]
            if conflicts:raise security.Error('Newer choices or changed code conflict with rollback. Nothing overwritten; keep backups for review.')
            if not approve(journal):return 'cancelled'
            journal['state']='restoring';self.store.write('journal',journal)
            try:
                for step in reversed(journal['steps']):
                    if step['skip'] or step['state']=='prepared':continue
                    if cancelled():raise Cancelled('Restoration paused; use Recovery again.')
                    self.adapter.assert_idle([s['op'] for s in journal['steps']])
                    if not self.adapter.can_restore(step):raise security.Error('Target changed during restoration.')
                    step['state']='restoring';self.store.write('journal',journal)
                    self.adapter.restore(step)
                    step['state']='restored';self.store.write('journal',journal)
                journal['state']='restored';self.store.write('journal',journal)
                self.adapter.finish(journal)
            except Exception:
                journal['state']='recovery_required';self.store.write('journal',journal)
                raise security.Error('Restoration interrupted; preserve backups and run Recovery again.') from None
            try:
                self.adapter.release_finalized(journal)
                self._prune_archived(journal)
            except Exception:
                raise security.Error('Rollback completed, but old staging cleanup needs local review.') from None
            return 'restored'
