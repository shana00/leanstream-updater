"""Remote-friendly, manual signed-maintenance UI. No startup network polling."""
import base64
import hashlib
import os
import sys
import time
import urllib.error
import urllib.request

from resources.lib import bundle
from resources.lib import managed_security as security
from resources.lib.managed_store import Store
from resources.lib.managed_adapter import Adapter, process_identity
from resources.lib.managed_jobs import Manager

PREFIX='updates/management-v1/'
API='https://api.github.com/repos/'+bundle.REPO+'/contents/'
PUBLIC='https://shana00.github.io/leanstream-updater/'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args):return None

def public_fetch(name,limit,cancelled=lambda:False):
    """Fixed anonymous core channel. Never reads or sends a repository token."""
    import re
    if name not in ('updater-signed-friends.json','updater-signed-owner-test.json'):
        if not re.fullmatch(re.escape(bundle.SELF_ID)+r'-\d+(?:\.\d+){0,3}\.zip',name):
            raise security.Error('Unapproved public updater path.')
    if type(limit) is not int or not 0<limit<=4*1024*1024:
        raise security.Error('Public updater download exceeds its bound.')
    url=PUBLIC+name
    request=urllib.request.Request(url,headers={'User-Agent':'LeanStream-Signed-Updater/'+bundle.VERSION})
    started=time.monotonic()
    try:
        with urllib.request.build_opener(NoRedirect()).open(request,timeout=15) as response:
            if response.geturl()!=url:raise security.Error('Public updater redirect refused.')
            chunks=[];received=0
            while True:
                if cancelled() or time.monotonic()-started>120:
                    raise security.Error('Public updater download cancelled/timed out. Nothing installed.')
                chunk=response.read(min(65536,limit+1-received))
                if not chunk:return b''.join(chunks)
                received+=len(chunk)
                if received>limit:raise security.Error('Public updater download exceeded its bound.')
                chunks.append(chunk)
    except (urllib.error.URLError,TimeoutError,OSError):
        raise security.Error('Signed public updater unavailable. Nothing installed; no token/account reset is needed.') from None

def core_job(raw,root,enrollment,adapter,now):
    payload=security.signed(raw,root,now)
    operations=payload.get('operations') if isinstance(payload,dict) else None
    if (not isinstance(operations,list) or len(operations)!=1
            or not isinstance(operations[0],dict)
            or operations[0].get('op')!='package.install'
            or operations[0].get('addon_id')!=bundle.SELF_ID):
        raise security.Error('Update updater accepts one signed updater-code package only.')
    # Read-only up-to-date check; actual apply uses persistent replay history.
    security.validate_job(payload,enrollment,adapter.platform,adapter.kodi_major,now,{})
    if operations[0]['artifact']['size']>4*1024*1024:
        raise security.Error('Updater core package exceeds its public download bound.')
    return payload

def update_core(ui):
    store,adapter,root=context(ui);enrollment=store.enrollment()
    if not enrollment['enabled'] or 'packages' not in enrollment['scopes']:
        raise security.Error('Enroll this Kodi with package permission before a signed updater upgrade. No token is needed for the public updater download.')
    monitor=ui.xbmc.Monitor();cancel=monitor.abortRequested
    raw=public_fetch('updater-signed-'+enrollment['channel']+'.json',security.MAX_METADATA,cancel)
    payload=core_job(raw,root,enrollment,adapter,int(time.time()))
    version=payload['operations'][0]['version']
    if bundle.ver(version)<=bundle.ver(bundle.VERSION):
        ui.DIALOG.ok('Update updater','Already on this updater version or newer. Nothing changed.')
        return
    result=Manager(store,adapter,root).apply(raw,lambda name,size:public_fetch(name,size,cancel),
        lambda p,steps:review(ui,p,steps),cancel)
    ui.DIALOG.ok('Update updater', 'Updater code verified; exit and reopen Kodi normally. Settings and tokens were preserved.'
        if result=='complete' else 'Cancelled. Updater code and settings were not changed.')

def fetch(ui,path,limit,cancelled=lambda:False,optional=False):
    import re
    if path not in (PREFIX+'friends/latest.json',PREFIX+'owner-test/latest.json',PREFIX+'roots.json'):
        if not re.fullmatch(r'updates/[A-Za-z0-9][A-Za-z0-9_.-]{0,159}\.(?:zip|xml)',path) or '..' in path:
            raise security.Error('Unapproved signed update path.')
    if type(limit) is not int or not 0 < limit <= bundle.MAX_PACKAGE:raise security.Error('Invalid download bound.')
    token=ui.SELF.getSetting('github_token').strip()
    if not token:raise security.Error('Set your private repository read token in updater settings first. Never share its value in diagnostics.')
    request=urllib.request.Request(API+path,headers={
        'Accept':'application/vnd.github.raw+json','Authorization':'Bearer '+token,
        'User-Agent':'LeanStream-Signed-Updater/'+bundle.VERSION,
        'X-GitHub-Api-Version':'2022-11-28'})
    started=time.monotonic()
    try:
        with urllib.request.build_opener(NoRedirect()).open(request,timeout=15) as response:
            if response.geturl()!=API+path:raise security.Error('Update redirect refused.')
            chunks=[];received=0
            while True:
                if cancelled() or time.monotonic()-started>120:raise security.Error('Download cancelled or timed out; no credentials changed.')
                chunk=response.read(min(65536,limit+1-received))
                if not chunk:return b''.join(chunks)
                received+=len(chunk)
                if received>limit:raise security.Error('Download exceeded signed size limit.')
                chunks.append(chunk)
    except urllib.error.HTTPError as error:
        if optional and error.code==404:return None
        if error.code==404:raise security.Error('Signed channel not published yet, or token cannot read it. Nothing installed.') from None
        raise security.Error('Private update download refused. Use the read-only GitHub access check; do not reset accounts.') from None
    except (urllib.error.URLError,TimeoutError,OSError):
        raise security.Error('Update download unavailable. Nothing installed; try again later.') from None

def context(ui):
    store=Store(ui.DATA,process_identity());adapter=Adapter(ui)
    raw=ui.read_core(os.path.join(ui.SELF.getAddonInfo('path'),'resources','trust-root.json'),security.MAX_METADATA+1)
    root=security.read_json(raw);security.root_schema(root)
    rotations=store.load('roots',[])
    if not isinstance(rotations,list) or len(rotations)>32:raise security.Error('Invalid trust history.')
    for encoded in rotations:
        try:raw=base64.b64decode(encoded,validate=True)
        except (ValueError,TypeError):raise security.Error('Invalid trust history encoding.') from None
        candidate=security.read_json(raw).get('signed',{})
        if candidate.get('version',0)<root['version']:continue
        if candidate.get('version')==root['version']:
            if candidate!=root:raise security.Error('Trust history conflicts with the authenticated bootstrap.')
            continue
        root=security.rotate_root(raw,root,int(time.time()),historical=True)
    return store,adapter,root

def enroll(ui):
    store,adapter,root=context(ui)
    channel=ui.DIALOG.select('Enroll this Kodi only',[
        'Friends channel — reviewed signed maintenance',
        'Owner-test channel — local validation only'])
    if channel<0:return
    labels=['Pure-Python addon / owned-skin / updater code packages',
            'Supported non-security Kodi settings',
            'Supported non-account addon settings',
            'Installed addon enable/disable (visible dependency impact)',
            'Named LeanStream keyboard/remote keymaps']
    choices=ui.DIALOG.multiselect('Choose permitted maintenance scopes',labels,preselect=list(range(len(labels))))
    if not choices:return
    scopes=[security.SCOPES[i] for i in choices]
    ui.DIALOG.textviewer('Enrollment — what this means',
        'This applies only to THIS Kodi. Every job must match the pinned signing key, '
        'channel, platform and permissions. You review changes before Apply.\n\n'
        'No live remote-control session, Android root, credential/account changes, '
        'silent installs or telemetry. Jobs cannot change network/security settings '
        'or the active skin. A normal restart may be needed. Native/binary addon '
        'dependencies use Kodi\'s own installer, not Windows files copied to Shield.\n\n'
        'Package permission trusts the signing operator with executable code: '
        'installed Python runs with Kodi privileges, not in a security sandbox. '
        'Signature checks cannot protect against a malicious operator or stolen signing key.\n\n'
        'Backups and a journal stay on this device. Revoke stops future jobs but '
        'does not erase your backups/version history or undo completed jobs. '
        'Rollback refuses to overwrite newer choices.\n\n'
        'Signing root version: '+str(root['version'])+'\n'
        'Signing key fingerprints:\n'+'\n'.join(root['keys']))
    if ui.DIALOG.yesno('Enable reviewed maintenance?', 'Permit the selected scopes on this device? No Kodi settings or accounts change during enrollment.'):
        store.enroll('friends' if channel==0 else 'owner-test',scopes)
        ui.DIALOG.ok('Enrolled','Signed jobs can now be reviewed. Nothing has been installed or changed.')

def revoke(ui):
    store,adapter,root=context(ui)
    if ui.DIALOG.yesno('Revoke maintenance?', 'Stop future signed jobs on this Kodi? Installed code/settings remain as they are. Recovery backups stay available.'):
        store.revoke();ui.DIALOG.ok('Revoked','Future jobs are blocked until you enroll again.')

def review(ui,payload,steps):
    lines=[payload['title'],payload['notes'],'','Signed sequence: '+str(payload['sequence']),
           'Channel: '+payload['target']['channel'],'']
    for i,step in enumerate(steps,1):
        op=step['op'];kind=op['op']
        target=op.get('addon_id',op.get('name',op.get('id','')))
        if kind=='addon.setting':target+=' / '+op['id']
        lines.append(str(i)+'. '+kind+' — '+target)
        if kind=='package.install':lines.append('   Install version '+op['version']+'; verified code-only backup.')
        elif kind=='keymap.install':
            lines.append('   Replace named keymap; old file backed up if present.')
            for mapping in step.get('mappings',()):lines.append('   '+mapping)
        else:lines.append('   '+repr(step['before'])+' -> '+repr(step['after']))
        if step['skip']:lines.append('   SKIP: already matches, or conditional migration does not apply.')
        if step['impact']:lines.append('   '+step['impact'])
    lines+=['','No credentials, watch history or cloud library data are included.',
            'After partial failure, use Recovery. Rollback preserves newer choices.']
    ui.DIALOG.textviewer('Review signed maintenance', '\n'.join(lines))
    return ui.DIALOG.yesno('Apply these reviewed changes?',
        'Only non-skipped operations above will run. Keep Kodi idle and do not use its controls until the result. Back/No makes no Kodi changes.')

def check(ui,local=False):
    store,adapter,root=context(ui)
    if not store.enrollment()['enabled']:raise security.Error('Enroll this Kodi and choose permissions first.')
    monitor=ui.xbmc.Monitor();cancel=monitor.abortRequested
    if local:
        path=ui.DIALOG.browse(1,'Choose signed job JSON','files','.json',False,False)
        if not path:return
        raw=ui.read_core(path,security.MAX_METADATA+1)
        base=os.path.dirname(path)
        def getter(name,limit):
            return ui.read_core(os.path.join(base,name),limit+1)
    else:
        chain=fetch(ui,PREFIX+'roots.json',security.MAX_METADATA,cancel,optional=True)
        if chain is not None:
            value=security.read_json(chain);security.exact(value,('schema','rotations'))
            if value['schema']!=1 or type(value['schema']) is not int or not isinstance(value['rotations'],list) or len(value['rotations'])>32:
                raise security.Error('Invalid root update list.')
            saved=store.load('roots',[])
            changed=False
            for item in value['rotations']:
                try:rotation=base64.b64decode(item,validate=True)
                except (ValueError,TypeError):raise security.Error('Invalid root update encoding.') from None
                candidate=security.read_json(rotation).get('signed',{})
                if candidate.get('version',0)<=root['version']:continue
                root=security.rotate_root(rotation,root,int(time.time()))
                saved.append(item);changed=True
            if changed:
                if len(saved)>32:raise security.Error('Trust chain full; use an authenticated bootstrap refresh.')
                with store.lock():store.write('roots',saved)
        raw=fetch(ui,PREFIX+store.enrollment()['channel']+'/latest.json',security.MAX_METADATA,cancel)
        getter=lambda name,limit:fetch(ui,'updates/'+name,limit,cancel)
    manager=Manager(store,adapter,root)
    result=manager.apply(raw,getter,lambda payload,steps:review(ui,payload,steps),cancel)
    if result=='complete':
        journal=store.load('journal')
        ui.DIALOG.ok('Maintenance complete', 'Readback verified; rollback backups retained. '+
            ('Exit and reopen Kodi normally before using updated code.' if journal['requires_restart'] else 'No code restart is required.'))
    else:ui.DIALOG.ok('Cancelled','No Kodi code or settings were changed.')

def recover(ui):
    store,adapter,root=context(ui)
    manager=Manager(store,adapter,root)
    result=manager.restore(lambda journal:ui.DIALOG.yesno('Restore managed job?',
        'Restore '+journal['job']+'? Verified old code/settings will be restored only '
        'where current values still match this job. Newer choices are never overwritten.'))
    if result=='restored':ui.DIALOG.ok('Restored','Rollback readback verified. Exit and reopen Kodi normally if code was involved.')
    elif result=='cancelled':ui.DIALOG.ok('Preparation cleared','No live Kodi code or settings had changed; temporary staging was removed.')

def status(ui):
    store,adapter,root=context(ui);enrollment=store.enrollment();journal=store.load('journal')
    preparing=store.load('preparing')
    lines=['Updater '+bundle.VERSION,'Protocol1; Kodi'+str(adapter.kodi_major)+' / '+adapter.platform,
        'Enrollment: '+('enabled' if enrollment['enabled'] else 'revoked/not enabled'),
        'Channel: '+enrollment['channel'],'Scopes: '+', '.join(enrollment['scopes']),
        'Local device ID (not sent automatically): '+enrollment['device'],
        'Trust root version: '+str(root['version']),
        'Trust fingerprints: '+', '.join(root['keys']),
        'Preparation: '+(str(preparing.get('job','invalid'))+' / preparing' if isinstance(preparing,dict) else 'none'),
        'Last job: '+(journal['job']+' / '+journal['state'] if journal else 'none'),
        'Rollback/staging retained locally under addon .leanstream-managed-* folders.',
        'No telemetry or raw account/log export. Revoke and Recovery are local-only.']
    ui.DIALOG.textviewer('Signed updater status','\n'.join(lines))

def main(ui):
    choices=['Update LeanStream — reviewed signed maintenance','Review local signed job (USB/file)',
        'Enroll / review permitted scopes','Status and trust fingerprints (read-only)',
        'Recovery / restore last managed job','Revoke maintenance on this Kodi',
        'Setup check and legacy recovery tools','Private repository token settings',
        'Update updater (signed public download)']
    try:
        choice=ui.DIALOG.select('LeanStream signed updater '+bundle.VERSION,choices)
        if choice==0:check(ui)
        elif choice==1:check(ui,local=True)
        elif choice==2:enroll(ui)
        elif choice==3:status(ui)
        elif choice==4:recover(ui)
        elif choice==5:revoke(ui)
        elif choice==6:legacy(ui)
        elif choice==7:ui.SELF.openSettings()
        elif choice==8:ui.update_updater()
    except security.Error as error:ui.DIALOG.ok('LeanStream updater',str(error))
    except Exception:
        ui.xbmc.log('[LeanStream Updater] Managed operation failed; private details withheld.',ui.xbmc.LOGERROR)
        ui.DIALOG.ok('Maintenance stopped','No account reset is needed. If changes began, use Recovery. Preserve local backups.')

def legacy(ui):
    options=['Setup check (read-only)','Check GitHub access (read-only)',
        'Restore legacy suite code','Restore legacy updater code',
        'Restore legacy trailer preferences','Restore legacy Android preferences',
        'Restore legacy scraping preferences']
    choice=ui.DIALOG.select('Read-only checks / existing recovery only',options)
    if choice>=2:
        store,adapter,root=context(ui)
        if store.pending():
            raise security.Error('Restore/resolve the managed job before using legacy code/preference recovery.')
    if choice==0:ui.check_setup()
    elif choice==1:ui.check_github_access()
    elif choice==2:ui.restore_backup()
    elif choice==3:ui.restore_updater()
    elif choice==4:ui.restore_trailer_setup()
    elif choice==5:ui.android_playback.restore(ui)
    elif choice==6:ui.scrape_setup.restore(ui)
