"""Versioned signed-job protocol. No Kodi, network or private-key dependencies.

Not a TUF implementation. Pins an operator root, verifies RSA-PSS/SHA256 jobs,
and bounds time, target, sequence and operation schemas before any mutation.
"""
import base64
import hashlib
import json
import math
import re

from resources.lib import bundle

PROTOCOL = 1
DOMAIN = b'LeanStream signed maintenance v1\x00'
ROOT_DOMAIN = b'LeanStream trust root v1\x00'
MAX_METADATA = 128 * 1024
MAX_OPERATIONS = 64
MAX_FORWARD_JUMP = 1024
KEYMAP_NAMES_V1 = ('leanstream-information.xml','leanstream-no-chapters.xml',
                   'leanstream-settings-paging.xml')
SCOPES = ('packages', 'kodi.settings', 'addon.settings', 'addon.state', 'keymaps')
OP_SCOPE = {'package.install':'packages', 'kodi.setting':'kodi.settings',
            'addon.setting':'addon.settings', 'addon.enabled':'addon.state',
            'keymap.install':'keymaps'}
SENSITIVE = re.compile(r'password|passphrase|token|secret|credential|api[_.-]?key|'
    r'username|login|oauth|authorization|cookie|session|client[_.-]?id|account|'
    r'access[_.-]?key|refresh[_.-]?key|private[_.-]?key|pin(?:code)?$|'
    r'(?:^|[_.-])auth$|(?:^|[_.-])refresh$', re.I)
HASH = re.compile(r'[a-f0-9]{64}')
ID = re.compile(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}')

# Kodi's global setting namespace contains paths, credentials and transport
# controls with innocuous IDs.  Protocol v1 therefore grants only these two
# evidenced scalar controls; strings are never remotely writable.
KODI_BOOL_SETTINGS_V1 = frozenset(('audiooutput.passthrough',))
KODI_INT_RANGES_V1 = {'videoplayer.seekdelay':(0,5000,1)}
KODI_SETTING_ALLOWLIST_V1 = frozenset(
    set(KODI_BOOL_SETTINGS_V1).union(KODI_INT_RANGES_V1))

# Protocol-v1 addon setting authority is intentionally exact and typed.  A new
# entry or value domain is a security review decision, never inferred from a
# downloaded addon's schema.  Strings, service/account state, internally owned
# automation controls and level-4 fields are not remotely writable.
BOOL_SETTINGS_V1 = frozenset('''
anime.episodeMeta anime.fillerDetection anime.versionPreference episode.fanart
experimental.personalizedSimilarity experimental.semanticSimilarity
filter.undesirables general.autotrynext general.cloudContentVerify
general.contentVerify general.datedelay general.disableNotificationSound
general.fanart.fallback general.filmographyShowAll general.flatten.episodes
general.force.widget.refresh.playback general.hideSpecials general.hideUnAired
general.hideWatched general.lastreleasenamepriority general.menucaching
general.meta.showoriginaltitle general.meta.studiolimit general.paginatecollection
general.paginatetraktlists general.providerPerformance general.qualityColors
general.rememberfilter general.removeduplicates general.resolverHide
general.setViews general.showRemainingUnwatched general.smartSearch
general.smartSearch.anime general.smartSearch.asiandrama general.smartSearch.movies
general.smartSearch.tvshows general.titleSubs general.torrentCache
general.viewidswitch general.widget.hide_next movie.artwork.advanced movies.banner
movies.clearart movies.clearlogo movies.discart movies.landscape
movies.language_based_releases playback.watchdog preem.adaptiveSources
preem.cloudfiles preem.directSources preem.enabled preem.waitfor.cloudfiles
scraping.allTierSweep scraping.easynews scraping.orion scraping.orion.hoster
scraping.orion.torrent scraping.tier0 scraping.tier1 scraping.tier2
scraping.tier3 scraping.tier4 scraping.tier5 scraping.tier6 scraping.tier7
searchHistory season.banner season.fanart season.landscape season.poster
skin.testmenu skip.autoCredits skip.autoIntro skip.autoPreview skip.autoRecap
skip.credits skip.intro skip.preview skip.recap smartplay.clickresume
smartplay.playingnextdialog smartplay.playlistcreate smartPlay.preScrape
smartplay.stillwatching tv.artwork.advanced tvshows.banner tvshows.clearart
tvshows.clearlogo tvshows.landscape watchdog.subtitleDetection
'''.split())

# (minimum, maximum, step).  Kodi treats an omitted integer step as one.  View
# IDs have no schema bounds, so protocol v1 adds its own conservative range.
INT_RANGES_V1 = {
    'addon.view.id':(0,9999,1),
    'anime.skipFallbackDelay':(0,30,1),
    'anime.skipFallbackDuration':(0,180,5),
    'anime.skipFallbackOffset':(-10,10,1),
    'episode.view.id':(0,9999,1),
    'general.cloudMissThreshold':(1,10,1),
    'general.contentVerifyMaxMismatch':(1,10,1),
    'general.providerFailThreshold':(3,20,1),
    'general.tierThreshold':(0,50,1),
    'general.timeout':(10,180,1),
    'item.limit':(10,100,1),
    'leanstream.source.max_episode_gb':(0,100,1),
    'leanstream.source.max_movie_gb':(1,12,1),
    'movie.view.id':(0,9999,1),
    'movies.characterart_limit':(0,20,1),
    'movies.fanart_limit':(1,20,1),
    'movies.keyart_limit':(0,10,1),
    'movies.poster_limit':(1,10,1),
    'playingnext.percent':(0,100,1),
    'playingnext.time':(10,180,1),
    'preem.limit':(0,20,1),
    'season.view.id':(0,9999,1),
    'show.view.id':(0,9999,1),
    'skip.offset':(-10,10,1),
    'stillwatching.numepisodes':(1,10,1),
    'tvshows.characterart_limit':(0,20,1),
    'tvshows.fanart_limit':(1,20,1),
    'tvshows.keyart_limit':(0,10,1),
    'tvshows.poster_limit':(1,10,1),
    'watchdog.maxRetries':(1,5,1),
    'watchdog.monitorWindow':(15,60,5),
    'watchdog.stallTimeout':(5,30,1)}

VIEW_ID_SETTINGS_V1 = frozenset(('addon.view.id','movie.view.id','show.view.id',
    'episode.view.id','season.view.id'))
EXPLICIT_RANGE_STEPS_V1 = frozenset((
    'anime.skipFallbackDelay','anime.skipFallbackDuration','anime.skipFallbackOffset',
    'general.contentVerifyMaxMismatch','leanstream.source.max_episode_gb',
    'leanstream.source.max_movie_gb','movies.characterart_limit',
    'movies.fanart_limit','movies.keyart_limit','movies.poster_limit',
    'playingnext.percent','skip.offset','tvshows.characterart_limit',
    'tvshows.fanart_limit','tvshows.keyart_limit','tvshows.poster_limit',
    'watchdog.maxRetries','watchdog.monitorWindow','watchdog.stallTimeout'))

INT_ENUMS_V1 = {
    'addon.view':(0,1,2,3,4,5,6,7,8),
    'anime.dubSubPreference':(0,1,2),
    'artwork.preferredsize':(0,1,2),
    'episode.view':(0,1,2,3,4,5,6,7,8),
    'general.appendepisodegeneral':(0,1,2,3),
    'general.appendListTitles':(0,1),
    'general.appendtitles':(0,1,2,3),
    'general.bookmarkstyle':(0,1,2),
    'general.metalocation':(0,1,2),
    'general.playstyleEpisodes':(0,1),
    'general.playstyleMovie':(0,1),
    'general.resolvefailurehandling':(0,1),
    'general.scrapedisplay':(0,1,2),
    'general.sortcollection':(0,1),
    'general.threadpoolScale':(0,1,2,3),
    'leanstream.source.dv':(0,1,2),
    'leanstream.source.hdr':(0,1,2),
    'leanstream.source.language':(0,1,2,3),
    'leanstream.source.resolution':(0,1,2,3,4),
    'leanstream.sourceCardRows':(0,1),
    'leanstream.sourceLayout':(0,1),
    'leanstream.sourceSearchScreen':(0,1),
    'leanstream.sourceSelectionScreen':(0,1),
    'leanstream.titleSelectAction':(0,1),
    'movie.view':(0,1,2,3,4,5,6,7,8),
    'movies.preferedsource':(0,1),
    'nextup.sort':(0,1),
    'playingnext.defaultaction':(0,1),
    'preem.movieres':(0,1,2,3),
    'preem.tvres':(0,1,2,3),
    'preem.type':(0,1,2),
    'season.view':(0,1,2,3,4,5,6,7,8),
    'show.view':(0,1,2,3,4,5,6,7,8),
    'smartplay.displaystyle':(0,1),
    'tvshows.preferedsource':(0,1,2)}

assert BOOL_SETTINGS_V1.isdisjoint(INT_RANGES_V1)
assert BOOL_SETTINGS_V1.isdisjoint(INT_ENUMS_V1)
assert set(INT_RANGES_V1).isdisjoint(INT_ENUMS_V1)
ADDON_SETTING_ALLOWLIST_V1 = {bundle.PLUGIN:frozenset(
    set(BOOL_SETTINGS_V1).union(INT_RANGES_V1,INT_ENUMS_V1))}
LEVEL_THREE_SETTINGS_V1 = frozenset((
    'experimental.personalizedSimilarity','experimental.semanticSimilarity'))
assert LEVEL_THREE_SETTINGS_V1.issubset(ADDON_SETTING_ALLOWLIST_V1[bundle.PLUGIN])
ADDON_SETTING_LEVELS_V1 = {setting:(3 if setting in LEVEL_THREE_SETTINGS_V1 else 0)
    for setting in ADDON_SETTING_ALLOWLIST_V1[bundle.PLUGIN]}

Error = bundle.UpdateError

def canonical(value):
    try:
        return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,
                          allow_nan=False).encode('ascii')
    except (TypeError,ValueError,OverflowError):
        raise Error('Unsupported signed metadata value.') from None

def read_json(raw,max_size=MAX_METADATA):
    if not isinstance(raw,bytes) or not 0 < len(raw) <= max_size:
        raise Error('Metadata size exceeds the safe limit.')
    def unique(pairs):
        value={}
        for key,item in pairs:
            if key in value: raise Error('Duplicate signed metadata field.')
            value[key]=item
        return value
    def bad_constant(value): raise Error('Non-finite signed metadata number.')
    try:
        return json.loads(raw.decode('utf8'),object_pairs_hook=unique,parse_constant=bad_constant)
    except (ValueError,UnicodeError,RecursionError):
        raise Error('Malformed signed metadata.') from None

def exact(value,keys):
    if not isinstance(value,dict) or set(value)!=set(keys):
        raise Error('Unexpected or missing signed metadata fields.')

def text(value,limit=512):
    if (not isinstance(value,str) or not 0 < len(value) <= limit
            or any(ord(c)<32 and c not in '\n\t' for c in value)):
        raise Error('Invalid signed metadata text.')
    return value

def identifier(value):
    if not isinstance(value,str) or not ID.fullmatch(value) or '..' in value:
        raise Error('Invalid maintenance identity.')
    return value

def addon_id(value):
    identifier(value)
    if (not value.startswith(('plugin.','script.','service.','resource.','skin.'))
            or value.startswith('skin.') and value!=bundle.SKIN):
        raise Error('Core modules and external skins are not managed package targets.')
    return value

def setting_id(value,addon=False,addon_id=None):
    identifier(value)
    if SENSITIVE.search(value) or (not addon and value.startswith(
            ('services.','network.','masterlock.','profiles.','upnp.'))):
        raise Error('Credential, account or security settings require direct owner action.')
    if not addon and value=='lookandfeel.skin':
        raise Error('Choose the active skin locally; jobs cannot switch it silently.')
    if not addon and value not in KODI_SETTING_ALLOWLIST_V1:
        raise Error('Kodi setting is not in the reviewed protocol-v1 safe list.')
    if addon and value not in ADDON_SETTING_ALLOWLIST_V1.get(addon_id,()):
        raise Error('Addon setting is not in the reviewed protocol-v1 safe list.')
    return value

def addon_setting_policy(addon_id,setting):
    setting_id(setting,True,addon_id)
    if setting in BOOL_SETTINGS_V1:return 'boolean',None
    if setting in INT_RANGES_V1:return 'range',INT_RANGES_V1[setting]
    if setting in INT_ENUMS_V1:return 'enum',INT_ENUMS_V1[setting]
    raise Error('Addon setting policy is incomplete.')

def kodi_setting_policy(setting):
    setting_id(setting)
    if setting in KODI_BOOL_SETTINGS_V1:return 'boolean',None
    if setting in KODI_INT_RANGES_V1:return 'range',KODI_INT_RANGES_V1[setting]
    raise Error('Kodi setting policy is incomplete.')

def kodi_setting_value(setting,value):
    kind,policy=kodi_setting_policy(setting)
    if kind=='boolean':
        if type(value) is not bool:raise Error('Kodi setting value type is not authorized.')
    else:
        if type(value) is not int:raise Error('Kodi setting value type is not authorized.')
        minimum,maximum,step=policy
        if not minimum<=value<=maximum or (value-minimum)%step:
            raise Error('Kodi setting value is outside its reviewed range.')
    return value

def addon_setting_value(addon_id,setting,value):
    kind,policy=addon_setting_policy(addon_id,setting)
    if kind=='boolean':
        if type(value) is not bool:raise Error('Addon setting value type is not authorized.')
    else:
        if type(value) is not int:raise Error('Addon setting value type is not authorized.')
        if kind=='enum' and value not in policy:
            raise Error('Addon setting value is outside its reviewed options.')
        if kind=='range':
            minimum,maximum,step=policy
            if not minimum<=value<=maximum or (value-minimum)%step:
                raise Error('Addon setting value is outside its reviewed range.')
    return value

def scalar(value):
    if type(value) not in (bool,int,float,str): raise Error('Setting value must be scalar.')
    if isinstance(value,str) and (len(value)>512 or '\x00' in value):
        raise Error('Setting string exceeds its safe limit.')
    if type(value) is int and abs(value)>2147483647: raise Error('Setting number out of range.')
    if type(value) is float and (not math.isfinite(value) or abs(value)>1e9):
        raise Error('Setting number out of range.')
    return value

def artifact(value):
    exact(value,('filename','sha256','size'))
    if (not isinstance(value['filename'],str)
            or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,159}\.(?:zip|xml)',value['filename'])
            or '..' in value['filename']): raise Error('Unsafe artifact filename.')
    if not isinstance(value['sha256'],str) or not HASH.fullmatch(value['sha256']):
        raise Error('Invalid artifact hash.')
    if type(value['size']) is not int or not 0 < value['size'] <= bundle.MAX_PACKAGE:
        raise Error('Artifact size out of bounds.')

def operation(op):
    if not isinstance(op,dict) or op.get('op') not in OP_SCOPE:
        raise Error('Unsupported maintenance capability; upgrade the updater first.')
    kind=op['op']
    fields={'package.install':('op','addon_id','version','artifact'),
            'keymap.install':('op','name','artifact'),
            'kodi.setting':('op','id','value','when'),
            'addon.setting':('op','addon_id','id','value','when'),
            'addon.enabled':('op','addon_id','value','when')}
    exact(op,fields[kind])
    if 'addon_id' in op: addon_id(op['addon_id'])
    if kind in ('package.install','keymap.install'):
        artifact(op['artifact'])
        if kind=='package.install':
            text(op['version'],48);bundle.ver(op['version'])
            if not re.fullmatch(r'\d+(?:\.\d+){0,3}',op['version']):raise Error('Invalid package version.')
            if not op['artifact']['filename'].endswith('.zip'):raise Error('Package must be a ZIP.')
        else:
            if op['name'] not in KEYMAP_NAMES_V1:
                raise Error('Only named LeanStream keymaps can be managed.')
            if not op['artifact']['filename'].endswith('.xml') or op['artifact']['size']>65536:
                raise Error('Invalid keymap artifact.')
    else:
        if kind=='addon.setting':addon_setting_value(op['addon_id'],op['id'],op['value'])
        elif kind=='kodi.setting':kodi_setting_value(op['id'],op['value'])
        elif type(op['value']) is not bool:raise Error('Addon enabled value must be boolean.')
        if kind=='addon.enabled':scalar(op['value'])
        if op['when']!='any':
            if not isinstance(op['when'],list) or not 1 <= len(op['when']) <= 16:
                raise Error('Invalid conditional migration.')
            for value in op['when']:
                if kind=='addon.setting':addon_setting_value(op['addon_id'],op['id'],value)
                elif kind=='kodi.setting':kodi_setting_value(op['id'],value)
                else:scalar(value)
    if kind=='addon.enabled' and op['addon_id']==bundle.SELF_ID:
        raise Error('Revoke enrollment instead of disabling the updater in a job.')

def operation_key(op):
    kind=op['op']
    if kind=='package.install':return kind,op['addon_id']
    if kind=='keymap.install':return kind,op['name']
    return kind,op.get('addon_id',''),op.get('id','')

def verify_pss(public,message,signature):
    """Kodi ships the Cryptodome namespace, not Crypto. No handwritten crypto."""
    try:
        try:
            from Cryptodome.Hash import SHA256
            from Cryptodome.PublicKey import RSA
            from Cryptodome.Signature import pss
        except ModuleNotFoundError as error:
            if error.name!='Cryptodome':raise
            from Crypto.Hash import SHA256
            from Crypto.PublicKey import RSA
            from Crypto.Signature import pss
        key=RSA.import_key(public.encode('ascii'))
        if key.has_private() or not 3072 <= key.size_in_bits() <= 4096 or key.e!=65537:
            return False
        pss.new(key,salt_bytes=32).verify(SHA256.new(message),signature)
        return True
    except (ValueError,TypeError,IndexError,UnicodeError):return False
    except ImportError:raise Error('Kodi cryptographic verifier unavailable. No changes allowed.') from None

def root_schema(root):
    exact(root,('schema','version','expires','keys','threshold'))
    if (type(root['schema']) is not int or root['schema']!=1
            or type(root['version']) is not int or not 1 <= root['version'] <= 2147483647
            or type(root['expires']) is not int or root['expires']<1704067200
            or type(root['threshold']) is not int or not 1 <= root['threshold'] <= 3
            or not isinstance(root['keys'],dict) or not root['threshold'] <= len(root['keys']) <= 4):
        raise Error('Invalid trust root.')
    for keyid,public in root['keys'].items():
        if not isinstance(keyid,str) or not HASH.fullmatch(keyid):raise Error('Invalid root key identity.')
        text(public,2048)
        if (not public.startswith('-----BEGIN PUBLIC KEY-----\n')
                or hashlib.sha256(public.encode('ascii')).hexdigest()!=keyid):
            raise Error('Root key fingerprint mismatch.')

def signed(raw,root,now,domain=DOMAIN,verify=verify_pss,check_expiry=True):
    root_schema(root)
    if type(now) is not int or now<1704067200 or check_expiry and now>=root['expires']:
        raise Error('Clock or trust root expired. Check time or install an authenticated root update.')
    envelope=read_json(raw);exact(envelope,('signed','signatures'))
    signatures=envelope['signatures']
    if not isinstance(signatures,list) or not 1 <= len(signatures) <= 8:
        raise Error('Missing or excessive signatures.')
    message=domain+canonical(envelope['signed']);valid=set();seen=set()
    for item in signatures:
        exact(item,('keyid','sig'));keyid=item['keyid']
        if not isinstance(keyid,str) or not HASH.fullmatch(keyid) or keyid in seen:
            raise Error('Invalid or duplicate signature identity.')
        seen.add(keyid)
        try:
            if not isinstance(item['sig'],str) or len(item['sig'])>1024:raise ValueError()
            signature=base64.b64decode(item['sig'],validate=True)
        except (ValueError,TypeError):raise Error('Invalid signature encoding.') from None
        if keyid in root['keys'] and verify(root['keys'][keyid],message,signature):valid.add(keyid)
    if len(valid)<root['threshold']:raise Error('Signature verification failed. Nothing changed.')
    return envelope['signed']

def validate_job(payload,enrollment,platform,kodi_major,now,state):
    exact(payload,('schema','kind','id','sequence','issued','expires','minimum_updater',
                   'title','notes','target','operations'))
    if type(payload['schema']) is not int or payload['schema']!=PROTOCOL or payload['kind']!='maintenance':
        raise Error('Unsupported management protocol.')
    identifier(payload['id']);text(payload['title'],120);text(payload['notes'],2048)
    for name in ('sequence','issued','expires'):
        if type(payload[name]) is not int or not 1 <= payload[name] <= 9007199254740991:
            raise Error('Invalid signed version or timestamp.')
    if (payload['issued']>now+300 or payload['expires']<=now
            or not 0 < payload['expires']-payload['issued'] <= 30*86400):
        raise Error('Job expired or issued in the future. No changes allowed.')
    text(payload['minimum_updater'],48)
    if bundle.ver(payload['minimum_updater'])>bundle.ver(bundle.VERSION):
        raise Error('This job needs a newer authenticated updater bootstrap.')
    target=payload['target'];exact(target,('kodi_major','platforms','channel','devices'))
    if (type(target['kodi_major']) is not int or target['kodi_major']!=21
            or not isinstance(target['platforms'],list) or not target['platforms']
            or len(target['platforms'])!=len(set(target['platforms']))
            or any(p not in ('android','windows') for p in target['platforms'])
            or target['channel'] not in ('owner-test','friends')
            or not isinstance(target['devices'],list) or len(target['devices'])>128
            or any(not isinstance(d,str) or not re.fullmatch(r'[a-f0-9]{32}',d) for d in target['devices'])):
        raise Error('Invalid job target.')
    if (not enrollment.get('enabled') or enrollment.get('channel')!=target['channel']
            or kodi_major!=target['kodi_major'] or platform not in target['platforms']
            or target['devices'] and enrollment.get('device') not in target['devices']):
        raise Error('This device is not enrolled for this job target.')
    ops=payload['operations']
    if not isinstance(ops,list) or not 1 <= len(ops) <= MAX_OPERATIONS:
        raise Error('Invalid job operation count.')
    keys=set();artifacts={}
    for op in ops:
        operation(op)
        if OP_SCOPE[op['op']] not in enrollment.get('scopes',[]):
            raise Error('Job exceeds the device owner\'s enrolled permissions.')
        key=operation_key(op)
        if key in keys:raise Error('Duplicate maintenance target.')
        keys.add(key)
        if 'artifact' in op:
            item=op['artifact'];name=item['filename']
            if name in artifacts and artifacts[name]!=item:raise Error('Artifact identity collision.')
            artifacts[name]=item
    if sum(item['size'] for item in artifacts.values())>128*1024*1024:
        raise Error('Combined artifact download exceeds the memory budget.')
    if sum(op['op']=='package.install' for op in ops)>16:
        raise Error('Too many code packages in one transaction.')
    # A core replacement happens last; the running interpreter must not mix
    # old and new modules during remaining setting/package operations.
    core=[i for i,op in enumerate(ops) if op['op']=='package.install' and op['addon_id']==bundle.SELF_ID]
    if core and core!=[len(ops)-1]:raise Error('Updater replacement must be the final operation.')
    digest=hashlib.sha256(canonical(payload)).hexdigest()
    sequence=payload['sequence'];seen=state.get('seen_sequence',0)
    if sequence<seen or sequence<=state.get('applied_sequence',0):raise Error('Older or already applied job rejected.')
    if sequence==seen and state.get('seen_digest')!=digest:raise Error('Same sequence has different signed content.')
    if sequence>seen+MAX_FORWARD_JUMP:raise Error('Signed sequence advances beyond the safe review window.')
    if now+300<state.get('last_time',0):raise Error('Device clock moved backwards; no changes allowed.')
    return digest,artifacts

def rotate_root(raw,old,now,verify=verify_pss,historical=False):
    candidate=signed(raw,old,now,ROOT_DOMAIN,verify,check_expiry=False)
    root_schema(candidate)
    if candidate['version']!=old['version']+1 or not historical and candidate['expires']<=now:
        raise Error('Root rotation must advance exactly one version and remain unexpired.')
    # Both the old authorization and the new root's possession threshold must
    # verify the identical root envelope. Rotation never needs a new core.
    signed(raw,candidate,now,ROOT_DOMAIN,verify,check_expiry=not historical)
    return candidate
