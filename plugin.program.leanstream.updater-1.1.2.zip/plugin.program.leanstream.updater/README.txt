LEANSTREAM PRIVATE UPDATER 1.1.2 - LOCAL BOOTSTRAP CANDIDATE

1.1.2 SELF-UPGRADE
Adds Update updater (public download) and Restore updater backup. No token is
used for updater-only upgrades. Fixed public HTTPS host, exact updater ID/version,
ZIP size/SHA256/path/Python/XML checks, explicit consent and verified code-only
backup. Private add-on/skin/AI and account/provider settings are not upgrade targets.
Exit and reopen Kodi normally after any updater upgrade or code restore.
Install this bootstrap ZIP once manually; future updater versions use the menu.
No automatic downloads or background updater upgrades are added.

INCLUDED 1.1.1 FIX
Prerequisite checks understand Kodi dependency versions such as
1.26.16+matrix.1, revisions and prerelease suffixes. An unreadable dependency
version is reported with its add-on ID instead of aborting the entire report.
Unknown required versions still block installation; release validation remains
strict. No credential, account, default-skin or automatic-update behavior changes.

Kodi target: 21.x (PC preparation verified on Kodi 21.3).
Same add-on ID and github_token setting as updater 1.0.0.
No new token, accounts, profile data or private PC paths are shipped.

INSTALL THIS UPDATER FIRST
1. Use https://shana00.github.io/leanstream-updater/ as a Kodi File manager source,
   or transfer plugin.program.leanstream.updater-1.1.2.zip to the Shield.
2. In Kodi choose Add-ons / Add-on browser / Install from zip file.
3. Select this ZIP and allow installation over the existing updater.
   Do NOT uninstall the old updater or delete its settings.
4. Open LeanStream Private Updater. Confirm the menu says 1.1.2.
5. Choose Check installed prerequisites (no changes).
6. Send the prerequisite report, but never send tokens/account settings.
7. STOP HERE until the paired Shield test release has been prepared/published.

MENU
- Check installed prerequisites: reads declared dependencies, missing/disabled/
  old components, trailer add-ons, bundled AI file integrity and two AI toggles.
  Existing LeanStream Accounts remains responsible for account connections.
- Check Shield test release: uses updates/shield-test/latest.json, schema 2.
  Requires exactly plugin.video.leanstream + skin.leanstream and verified AI files.
  All archives/checksums/declarations are validated before code replacement.
  A missing test manifest is expected before publication; no legacy fallback.
- Check existing add-on-only release: keeps updates/latest.json schema 1 support.
  It does NOT install the skin or supply a new paired AI test release.
- Restore last update backup: restores code only, never account/settings data.
- Updater settings: retains the existing read-only GitHub token field.
- Finish LeanStream default-skin setup: retries only a full-bundle setup that the
  owner approved. It does not download or install anything.
- Update updater (public download): checks updater-latest.json on the public
  updater host, offers only a newer updater version, verifies ZIP and backs up
  updater code before replacement. It never reads the private GitHub token.
- Restore updater backup: verifies and restores only the last updater-only code
  backup. Does not use or change the private add-on/skin backup record.

SAFETY
No automatic downloads/updates, telemetry, credential reset, account migration,
remote-control setup, provider cleanup or external-skin edits.
Missing required add-ons block installation; optional tools are non-blocking.
No silent prerequisite installation. Install Android binary add-ons through Kodi.
Stop playback and use a non-LeanStream skin before updating/restoring its files.
The paired installer asks whether to make LeanStream the default after restart.
If approved, a one-shot startup helper verifies both release versions, AI files,
skin digest, add-on registration and completed transaction before enabling only
skin.leanstream and asking Kodi to select it. Choose Yes in Kodi's native Keep
this skin prompt; a decline/timeout is not overridden or retried at every start.
Previous skin stays installed. No skin selection occurs during file replacement.
Installing the updater ZIP alone does not schedule or perform this skin setup.
Exit/reopen Kodi normally after file installation; AI options remain unchanged.
AI settings remain unchanged (new package defaults are not device settings).
Both update targets have code-only verified backups. Directory renames roll back
on failure; an interrupted transaction is recorded for explicit recovery.
Old backups are not automatically deleted. Windows bytecode is never shipped.

VALIDATION LIMITS
Local automated validation is not remote-Shield runtime acceptance.
Private-repository access, Android file permissions, add-on registration/enable,
native dialogs, D-pad input and restart must still be verified on the Shield.
The queued default-skin/native Keep prompt also requires actual Shield testing.
The prerequisite report is not a provider/account/YouTube availability guarantee.

ROLLBACK UPDATER
After a self-upgrade, use Restore updater backup and restart Kodi normally.
If interruption leaves the updater unavailable, reinstall the bootstrap ZIP from
the same Kodi source without uninstalling or clearing any settings/account data.
Reinstall the preserved updater-1.0.0 ZIP through Kodi if needed, without
uninstalling or deleting addon_data. Version 1.0.0 cannot restore new paired
transactions; restore changed add-on/skin files with 1.1.2 before downgrading it.

TECHNICAL REFERENCES
https://kodi.wiki/view/Add-on_manager#Update_from_ZIP_file
https://kodi.wiki/view/List_of_built-in_functions
https://kodi.wiki/view/JSON-RPC_API/v13
https://docs.github.com/en/rest/about-the-rest-api/api-versions
