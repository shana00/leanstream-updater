LEANSTREAM PRIVATE UPDATER 1.1.6 - CONTROLLED SHIELD TEST

CHECK GITHUB ACCESS (NO CHANGES)
Manual menu check of this device's existing github_token setting: account,
private repository and exact Shield test feed. Shows HTTP status, safe account
name, expiry when GitHub reports it, quota and endpoint permission requirements.
These requirements are NOT the token's complete privileges. Missing expiry is
not proof that a token expired. Invalid/revoked credentials, insufficient access,
rate limits, hidden/missing resources and network failures are reported separately.
Downloads now distinguish HTTP401/403/429 and direct you to this safe report.

At most three GET requests, eight-second socket timeouts, bounded response sizes,
cancellation and no automatic retries. Redirects are blocked; authorization is
never forwarded. Only typed/allowlisted metadata is displayed, never raw bodies,
headers, exceptions, token values/fragments or fingerprints. No diagnostic file,
credential change, account reset or install. Safe to send a report screenshot;
never send the token value. This is manual only, not a startup/service probe.
The diagnostic is available even while an interrupted setup needs restoration;
it does not clear or bypass the setup guards. Restart after updating the updater.

Local tests do not establish native Shield acceptance or fix its unknown token.
The public update contains updater code only; suite, skin, AI and settings stay.
GitHub reference: https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api

SAFE TRAILER PREFERENCES
The verified paired suite queues a receipt-bound request, without reading or
changing YouTube preferences before a normal Kodi restart. The owner then sees
the exact differences and can approve eleven non-secret playback, cache and
timeout preferences. Already-matching values need no setters. Declining is not
repeated automatically. No request means no preference reads at startup.

Only these eleven preferences are read, backed up and changed. Tokens, API keys,
accounts, cookies, history, proxy, SSL, DRM, codec and security settings are never
copied. The installed YouTube schema, suite receipt, full code/model hashes,
registered versions and required dependencies must verify before any setter.
The preference snapshot is saved first; every setter is read back. A failed apply
attempt restores the original allowlisted values, or leaves an explicit recovery
state if restoration fails. Interrupted preference work blocks further code updates.
Restore trailer preferences is separate from code-only suite/updater restoration
and refuses changed schemas/YouTube versions or newer user preference values.

The candidate does not apply settings on this PC or any Shield. Native Kodi 21
setter/dialog behavior, normal restart, playback and cold/warm response time must
be accepted on the device. Matching PC preferences does not guarantee PC speed.

DEPENDENCY COMPATIBILITY REPAIR
Kodi checks each requested minimum against the provided version AND each requested
compiled interface against the provided backwards-compatible ABI. Both checks are
now preserved throughout dependency expansion, duplicates and verified planned
packages. A compiled interface1.1.9 with declaredminimum1.1.7 can accept provided
version1.1.8 when its provided ABI is compatible; do not recommend a Kodi upgrade
from the former false TOO OLD warning alone. Actual device metadata is still needed.

Missing minversion follows Kodi's version fallback, including canonical0.0.0.
Unknown/malformed metadata, incompatible ABI and genuinely old required components
remain blocking. Unreadable XML is not treated as an empty ready dependency list.
Reports include updater/Kodi versions, requested interface, provided ABI and the
requesting add-on. All declarations survive merging; graph/XML limits prevent
unbounded checks. Non-portable numeric components above2147483647 fail closed.
Public release/package validation remains strict and separate from dependency
version suffix/epoch comparison; no unknown version is guessed safe.

SUITE PREPARATION
Kodi built-in xbmc.* and kodi.binary.* interfaces are checked from the application
VFS addon.xml metadata, not the normal add-on JSON-RPC listing. They are never
downloaded as separate add-ons. Missing/mismatched/unreadable/old core metadata
remains blocking; versions are not guessed from the Kodi major version.

Only a verified paired add-on + skin + AI installation can prepare prerequisites.
All package identities, checksums, declarations and AI files are validated first.
After owner confirmation, required missing add-ons are requested through native
InstallAddon and disabled approved modules through EnableAddon. Kodi handles its
existing repository policy, platform binary packages, dependency resolution,
menu locks, dialogs and confirmation. No repository, unknown-source or security
settings are changed. Accounts/providers/DRM setup are never automated.

Available declared optional modules may also be requested after confirmation.
Unavailable optional modules stay optional and do not block suite installation.
Every completed action and the final required tree are rechecked before replacing
private suite files. A declined/failed required action prevents suite replacement.
Completed Kodi prerequisite changes may remain if later cancelled or failed;
they are not part of the updater's private code-only rollback.

Kodi 21 InstallAddon does not upgrade an already-installed old add-on. Old or
unknown required versions remain blockers: no uninstalls, arbitrary binary ZIPs,
global add-on updates or false success. Native modal dialogs wait for Kodi/user
completion, not a hard wall-clock timeout. At most32 requested native actions.
The read-only prerequisite menu never installs anything or reads private tokens.

UPDATER SELF-UPGRADE
Update updater uses the fixed public HTTPS updater-only feed and requires explicit
confirmation, verified size/SHA256/ZIP/code checks and a separate code backup.
No private token is read. Restore updater backup is separate from suite rollback.
Exit and reopen Kodi normally after self-upgrade or restore. No background updates.
The issued 1.1.2/1.1.3 updaters can receive this future version through Update updater
after it is tested and published. This local candidate is not a published release.

PRIVATE SUITE
Exactly plugin.video.leanstream + skin.leanstream and verified Potion 4M int8 files
are required by the paired manifest. Missing test feed has no legacy fallback.
The approved default-skin request runs only after a normal restart and verified
complete installation. Kodi's native Keep this skin confirmation is not bypassed.
Existing skin remains for recovery. Updater installation alone never changes skin.
Experimental AI switches remain unchanged; package defaults are not device settings.

SAFETY AND ACCEPTANCE
Keep existing updater settings; do not uninstall or clear Kodi/account data.
No credential transfer, telemetry, provider cleanup, remote access, external-skin
edits, model enablement or account/security changes. Dependency-version suffix
checks from1.1.1 and self-upgrade/recovery guards from1.1.2 are retained.
Local isolated/package checks do not prove actual Shield/native dialog behavior.
The actual PC XML graph and a photo-version replay are audited; replay retains
PC declarations/ABI and is not a substitute for a new report on the actual Shield.
Android VFS metadata, native install/enable dialogs, repository availability,
registration/restart and the default-skin prompt require device acceptance.

If a power interruption leaves the updater unavailable, reinstall its bootstrap
ZIP without uninstall/settings reset, then use Restore updater backup. Code-only
suite backups cover the private add-on and skin, not native prerequisite add-ons.

Kodi source: https://shana00.github.io/leanstream-updater/
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/interfaces/builtins/AddonBuiltins.cpp
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/interfaces/json-rpc/AddonsOperations.cpp
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/addons/addoninfo/AddonInfo.cpp
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/addons/addoninfo/AddonInfo.h
