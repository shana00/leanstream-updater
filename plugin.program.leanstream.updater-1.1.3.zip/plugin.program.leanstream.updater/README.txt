LEANSTREAM PRIVATE UPDATER 1.1.3 - LOCAL SUITE-PREREQUISITE CANDIDATE

SUITE PREPARATION
Kodi built-in xbmc.* and kodi.binary.* interfaces are checked from the application
VFS addon.xml metadata, not the normal add-on JSON-RPC listing. They are never
downloaded as separate add-ons. Missing/mismatched/unreadable/old core metadata
remains blocking; versions are not guessed from the Kodi major version.

Only a verified paired add-on + skin + AI installation can prepare prerequisites.
All package identities, checksums, declarations and AI files are validated first.
After owner confirmation, required missing add-ons are requested through native
InstallAddon and disabled approved modules through EnableAddon. Kodi handles its
existing repository policy, platform binary packages, dependency resolution,
menu locks, dialogs and confirmation. No repository, unknown-source or security
settings are changed. Accounts/providers/DRM setup are never automated.

Available declared optional modules may also be requested after confirmation.
Unavailable optional modules stay optional and do not block suite installation.
Every completed action and the final required tree are rechecked before replacing
private suite files. A declined/failed required action prevents suite replacement.
Completed Kodi prerequisite changes may remain if later cancelled or failed;
they are not part of the updater's private code-only rollback.

Kodi 21 InstallAddon does not upgrade an already-installed old add-on. Old or
unknown required versions remain blockers: no uninstalls, arbitrary binary ZIPs,
global add-on updates or false success. Native modal dialogs wait for Kodi/user
completion, not a hard wall-clock timeout. At most32 requested native actions.
The read-only prerequisite menu never installs anything or reads private tokens.

UPDATER SELF-UPGRADE
Update updater uses the fixed public HTTPS updater-only feed and requires explicit
confirmation, verified size/SHA256/ZIP/code checks and a separate code backup.
No private token is read. Restore updater backup is separate from suite rollback.
Exit and reopen Kodi normally after self-upgrade or restore. No background updates.
The issued 1.1.2 updater can receive this future version through Update updater
after it is tested and published. This local candidate is not a published release.

PRIVATE SUITE
Exactly plugin.video.leanstream + skin.leanstream and verified Potion 4M int8 files
are required by the paired manifest. Missing test feed has no legacy fallback.
The approved default-skin request runs only after a normal restart and verified
complete installation. Kodi's native Keep this skin confirmation is not bypassed.
Existing skin remains for recovery. Updater installation alone never changes skin.
Experimental AI switches remain unchanged; package defaults are not device settings.

SAFETY AND ACCEPTANCE
Keep existing updater settings; do not uninstall or clear Kodi/account data.
No credential transfer, telemetry, provider cleanup, remote access, external-skin
edits, model enablement or account/security changes. Dependency-version suffix
checks from1.1.1 and self-upgrade/recovery guards from1.1.2 are retained.
Local isolated/package checks do not prove actual Shield/native dialog behavior.
Android VFS metadata, native install/enable dialogs, repository availability,
registration/restart and the default-skin prompt require device acceptance.

If a power interruption leaves the updater unavailable, reinstall its bootstrap
ZIP without uninstall/settings reset, then use Restore updater backup. Code-only
suite backups cover the private add-on and skin, not native prerequisite add-ons.

Kodi source: https://shana00.github.io/leanstream-updater/
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/interfaces/builtins/AddonBuiltins.cpp
Reference: https://github.com/xbmc/xbmc/blob/Omega/xbmc/interfaces/json-rpc/AddonsOperations.cpp
